<?php

use App\Http\Controllers\Api\V1\AuthController;
use App\Http\Controllers\Api\V1\BranchController;
use App\Http\Controllers\Api\V1\BrandController;
use App\Http\Controllers\Api\V1\CategoryController;
use App\Http\Controllers\Api\V1\CurrencyController;
use App\Http\Controllers\Api\V1\CustomerController;
use App\Http\Controllers\Api\V1\DashboardController;
use App\Http\Controllers\Api\V1\ExpenseController;
use App\Http\Controllers\Api\V1\LossController;
use App\Http\Controllers\Api\V1\PaymentController;
use App\Http\Controllers\Api\V1\ProductController;
use App\Http\Controllers\Api\V1\PurchaseController;
use App\Http\Controllers\Api\V1\ReportController;
use App\Http\Controllers\Api\V1\SettingController;
use App\Http\Controllers\Api\V1\SaleController;
use App\Http\Controllers\Api\V1\SupplierController;
use App\Http\Controllers\Api\V1\UserController;
use Illuminate\Support\Facades\Route;

// ─── Public routes ────────────────────────────────────────────────────────────
Route::prefix('v1')->group(function () {

    Route::post('auth/login', [AuthController::class, 'login'])
        ->middleware('throttle:10,1');

    // Payment webhooks & callbacks — no auth (called by Xdigitex Pay servers)
    Route::post('payments/webhook',  [PaymentController::class, 'webhook']);
    Route::get('payments/callback',  [PaymentController::class, 'callback']);

    // ─── Authenticated routes ──────────────────────────────────────────────────
    Route::middleware(['auth:sanctum'])->group(function () {

        // Auth
        Route::post('auth/logout',          [AuthController::class, 'logout']);
        Route::get('auth/me',               [AuthController::class, 'me']);
        Route::post('auth/change-password', [AuthController::class, 'changePassword']);

        // Dashboard
        Route::get('dashboard/summary', [DashboardController::class, 'summary']);

        // Settings & Sync
        Route::get('settings',  [SettingController::class, 'index']);
        Route::put('settings',  [SettingController::class, 'update'])->middleware('role:super_admin');
        Route::get('sync/pull', [SettingController::class, 'pullData']);

        // ── Currency ────────────────────────────────────────────────────────────
        Route::prefix('currency')->group(function () {
            Route::get('/',         [CurrencyController::class, 'index']);
            Route::post('switch',   [CurrencyController::class, 'switch'])->middleware('role:super_admin|manager');
            Route::post('rates',    [CurrencyController::class, 'updateRates'])->middleware('role:super_admin');
            Route::post('convert',  [CurrencyController::class, 'convert']);
        });

        // ── Payments — Xdigitex Pay STK Push ───────────────────────────────────
        Route::prefix('payments')->group(function () {
            Route::post('initiate',          [PaymentController::class, 'initiateSTKPush']);
            Route::get('status/{reference}', [PaymentController::class, 'checkStatus']);
            Route::get('balance',            [PaymentController::class, 'balance']);
            Route::post('api-key',           [PaymentController::class, 'saveApiKey'])->middleware('role:super_admin|manager');
            Route::post('test-connection',   [PaymentController::class, 'testConnection'])->middleware('role:super_admin|manager');
        });

        // Products
        Route::get('products/low-stock', [ProductController::class, 'lowStock']);
        Route::post('products/scan',     [ProductController::class, 'scanBarcode']);
        Route::apiResource('products',   ProductController::class);

        // Categories, Brands, Suppliers
        Route::apiResource('categories', CategoryController::class);
        Route::apiResource('brands',     BrandController::class);
        Route::apiResource('suppliers',  SupplierController::class);

        // Customers
        Route::apiResource('customers', CustomerController::class);

        // Sales
        Route::post('sales/bulk-sync',          [SaleController::class, 'bulkSync']);
        Route::get('sales/{sale}/receipt',       [SaleController::class, 'receipt']);
        Route::post('sales/{sale}/refund',       [SaleController::class, 'refund'])->middleware('role:super_admin|manager');
        Route::apiResource('sales', SaleController::class)->except(['update', 'destroy']);

        // Purchases
        Route::apiResource('purchases', PurchaseController::class)->middleware('role:super_admin|manager');

        // Expenses
        Route::get('expenses/categories',          [ExpenseController::class, 'categories']);
        Route::post('expenses/{expense}/approve',  [ExpenseController::class, 'approve'])->middleware('role:super_admin|manager');
        Route::post('expenses/{expense}/reject',   [ExpenseController::class, 'reject'])->middleware('role:super_admin|manager');
        Route::apiResource('expenses', ExpenseController::class);

        // Losses
        Route::post('losses/{loss}/approve', [LossController::class, 'approve'])->middleware('role:super_admin|manager');
        Route::apiResource('losses', LossController::class)->middleware('role:super_admin|manager');

        // Users
        Route::get('users/activity-logs',           [UserController::class, 'activityLogs'])->middleware('role:super_admin');
        Route::post('users/{user}/toggle-active',    [UserController::class, 'toggleActive'])->middleware('role:super_admin');
        Route::apiResource('users', UserController::class)->middleware('role:super_admin');

        // Branches
        Route::apiResource('branches', BranchController::class)->middleware('role:super_admin');

        // Reports
        Route::prefix('reports')->middleware('role:super_admin|manager')->group(function () {
            Route::get('sales',       [ReportController::class, 'sales']);
            Route::get('expenses',    [ReportController::class, 'expenses']);
            Route::get('stock',       [ReportController::class, 'stock']);
            Route::get('profit-loss', [ReportController::class, 'profitLoss']);
            Route::get('export',      [ReportController::class, 'export']);
        });
    });
});
