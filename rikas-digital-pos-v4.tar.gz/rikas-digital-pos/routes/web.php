<?php

use App\Http\Controllers\LanguageController;
use Illuminate\Support\Facades\Route;

// Language switcher
Route::get('/language/{locale}', [LanguageController::class, 'switch'])
    ->name('language.switch')
    ->where('locale', 'en|fr');

// Redirect root to admin
Route::get('/', function () {
    return redirect('/admin');
});

// Health check
Route::get('/health', function () {
    return response()->json([
        'status'  => 'ok',
        'app'     => config('app.name'),
        'version' => '1.0.0',
        'time'    => now()->toISOString(),
    ]);
});
