<?php

use App\Models\ActivityLog;
use App\Models\Setting;

if (!function_exists('activity_log')) {
    function activity_log(string $action, ?int $userId, string $description, array $extras = []): void
    {
        try {
            ActivityLog::create([
                'user_id'     => $userId,
                'action'      => $action,
                'description' => $description,
                'model_type'  => $extras['model_type'] ?? null,
                'model_id'    => $extras['model_id'] ?? null,
                'old_values'  => $extras['old_values'] ?? null,
                'new_values'  => $extras['new_values'] ?? null,
                'ip_address'  => request()?->ip(),
                'user_agent'  => request()?->userAgent(),
            ]);
        } catch (\Exception $e) {
            // Silently fail — logging should never break the app
        }
    }
}

if (!function_exists('setting')) {
    function setting(string $key, mixed $default = null): mixed
    {
        return Setting::get($key, $default);
    }
}

if (!function_exists('format_currency')) {
    function format_currency(float $amount, ?string $symbol = null): string
    {
        $symbol = $symbol ?? setting('currency_symbol', 'KSh');
        return $symbol . ' ' . number_format($amount, 2);
    }
}
