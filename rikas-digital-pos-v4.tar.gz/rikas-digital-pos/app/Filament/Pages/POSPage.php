<?php

namespace App\Filament\Pages;

use Filament\Pages\Page;

class POSPage extends Page
{
    protected static ?string $navigationIcon  = 'heroicon-o-shopping-cart';
    protected static ?string $navigationLabel = 'POS Terminal';
    protected static ?string $navigationGroup = 'POS';
    protected static ?int    $navigationSort  = -10;
    protected static string  $view            = 'filament.pages.pos';

    public static function shouldRegisterNavigation(): bool
    {
        // Visible to cashiers, managers, and super admins
        return auth()->check();
    }
}
