<?php

namespace App\Filament\Pages;

use App\Filament\Widgets\RecentSalesTable;
use App\Filament\Widgets\StatsOverview;
use Filament\Pages\Dashboard as BaseDashboard;

class Dashboard extends BaseDashboard
{
    protected static ?string $navigationIcon  = 'heroicon-o-home';
    protected static ?int    $navigationSort  = -2;

    public function getTitle(): string
    {
        $hour     = now()->hour;
        $greeting = match (true) {
            $hour < 12 => 'Good Morning',
            $hour < 17 => 'Good Afternoon',
            default    => 'Good Evening',
        };

        $name = auth()->user()?->name ?? 'Admin';
        return "{$greeting}, {$name} 👋";
    }

    public function getWidgets(): array
    {
        return [
            StatsOverview::class,
            RecentSalesTable::class,
        ];
    }

    public function getColumns(): int | string | array
    {
        return 3;
    }
}
