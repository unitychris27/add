<?php

namespace App\Filament\Pages;

use App\Models\Expense;
use App\Models\Product;
use App\Models\Purchase;
use App\Models\Sale;
use App\Models\SaleItem;
use App\Services\PaymentService;
use Filament\Forms\Components\DatePicker;
use Filament\Forms\Components\Section;
use Filament\Forms\Components\Select;
use Filament\Forms\Concerns\InteractsWithForms;
use Filament\Forms\Contracts\HasForms;
use Filament\Forms\Form;
use Filament\Pages\Page;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class ReportsPage extends Page implements HasForms
{
    use InteractsWithForms;

    protected static ?string $navigationIcon  = 'heroicon-o-chart-bar';
    protected static ?string $navigationLabel = 'Reports';
    protected static ?string $navigationGroup = 'Reports';
    protected static ?int    $navigationSort  = 1;
    protected static string  $view            = 'filament.pages.reports';

    public ?array $data    = [];
    public array  $results = [];

    public function mount(): void
    {
        $this->form->fill([
            'report_type' => 'sales_summary',
            'from_date'   => now()->startOfMonth()->toDateString(),
            'to_date'     => now()->toDateString(),
        ]);
    }

    public function form(Form $form): Form
    {
        return $form->schema([
            Section::make()->schema([
                Select::make('report_type')
                    ->label('Report Type')
                    ->options([
                        'sales_summary'    => '📊 Sales Summary',
                        'sales_by_product' => '📦 Sales by Product',
                        'sales_by_cashier' => '👤 Sales by Cashier',
                        'purchase_summary' => '🛒 Purchase Summary',
                        'profit_loss'      => '💰 Profit & Loss',
                        'expense_report'   => '💸 Expense Report',
                        'stock_report'     => '📋 Stock Report',
                        'tax_report'       => '🧾 Tax Report',
                        'payment_methods'  => '💳 Payment Methods',
                    ])
                    ->required()->default('sales_summary'),
                DatePicker::make('from_date')->label('From Date')->required()->default(now()->startOfMonth()),
                DatePicker::make('to_date')->label('To Date')->required()->default(now()),
            ])->columns(3),
        ])->statePath('data');
    }

    public function generate(): void
    {
        $d        = $this->form->getState();
        $type     = $d['report_type'];
        $from     = $d['from_date'];
        $to       = $d['to_date'];
        $user     = Auth::user();
        $branchId = $user->branch_id;
        $isSuper  = $user->hasRole('super_admin');
        $sym      = PaymentService::currencySymbol();

        $salesQ = Sale::where('status', 'completed')
            ->whereBetween('created_at', [$from.' 00:00:00', $to.' 23:59:59']);
        if (!$isSuper) $salesQ->where('branch_id', $branchId);

        $this->results = match ($type) {

            'sales_summary' => [
                'title'   => 'Sales Summary',
                'headers' => ['Date', 'Transactions', 'Subtotal', 'Tax', 'Discount', 'Total'],
                'rows'    => (clone $salesQ)
                    ->selectRaw('DATE(created_at) as date, COUNT(*) as txns, SUM(subtotal) as sub, SUM(tax_amount) as tax, SUM(discount_amount) as disc, SUM(total_amount) as total')
                    ->groupByRaw('DATE(created_at)')->orderBy('date')->get()
                    ->map(fn ($r) => [$r->date, $r->txns, $sym.' '.number_format($r->sub,2), $sym.' '.number_format($r->tax,2), $sym.' '.number_format($r->disc,2), $sym.' '.number_format($r->total,2)])
                    ->toArray(),
                'totals'  => [
                    'Total Sales' => $sym.' '.number_format((clone $salesQ)->sum('total_amount'), 2),
                    'Total Tax'   => $sym.' '.number_format((clone $salesQ)->sum('tax_amount'), 2),
                    'Transactions'=> (clone $salesQ)->count(),
                ],
            ],

            'sales_by_product' => [
                'title'   => 'Sales by Product',
                'headers' => ['Product', 'Qty Sold', 'Unit Price', 'Total Revenue'],
                'rows'    => SaleItem::join('sales','sales.id','=','sale_items.sale_id')
                    ->join('products','products.id','=','sale_items.product_id')
                    ->where('sales.status','completed')
                    ->whereBetween('sales.created_at', [$from.' 00:00:00', $to.' 23:59:59'])
                    ->when(!$isSuper, fn($q) => $q->where('sales.branch_id', $branchId))
                    ->selectRaw('products.name, SUM(sale_items.quantity) as qty, AVG(sale_items.unit_price) as avg_price, SUM(sale_items.subtotal) as revenue')
                    ->groupBy('products.id','products.name')
                    ->orderByDesc('revenue')->limit(50)->get()
                    ->map(fn($r) => [$r->name, number_format($r->qty,0), $sym.' '.number_format($r->avg_price,2), $sym.' '.number_format($r->revenue,2)])
                    ->toArray(),
                'totals' => ['Total Revenue' => $sym.' '.number_format((clone $salesQ)->sum('total_amount'), 2)],
            ],

            'sales_by_cashier' => [
                'title'   => 'Sales by Cashier',
                'headers' => ['Cashier', 'Transactions', 'Total Sales', 'Avg Sale'],
                'rows'    => (clone $salesQ)
                    ->join('users','users.id','=','sales.user_id')
                    ->selectRaw('users.name, COUNT(*) as txns, SUM(total_amount) as total, AVG(total_amount) as avg')
                    ->groupBy('users.id','users.name')->orderByDesc('total')->get()
                    ->map(fn($r) => [$r->name, $r->txns, $sym.' '.number_format($r->total,2), $sym.' '.number_format($r->avg,2)])
                    ->toArray(),
                'totals' => [],
            ],

            'purchase_summary' => [
                'title'   => 'Purchase Summary',
                'headers' => ['Date', 'Supplier', 'Ref #', 'Items', 'Total', 'Status'],
                'rows'    => Purchase::with('supplier')
                    ->whereBetween('purchase_date', [$from, $to])
                    ->when(!$isSuper, fn($q) => $q->where('branch_id', $branchId))
                    ->orderBy('purchase_date','desc')->get()
                    ->map(fn($r) => [$r->purchase_date, $r->supplier->name ?? '-', $r->reference_number, $r->items()->count(), $sym.' '.number_format($r->total_amount,2), ucfirst($r->status)])
                    ->toArray(),
                'totals' => ['Total Purchases' => $sym.' '.number_format(Purchase::whereBetween('purchase_date',[$from,$to])->when(!$isSuper,fn($q)=>$q->where('branch_id',$branchId))->sum('total_amount'), 2)],
            ],

            'profit_loss' => [
                'title'   => 'Profit & Loss',
                'headers' => ['Category', 'Amount'],
                'rows'    => [
                    ['Total Revenue',       $sym.' '.number_format((clone $salesQ)->sum('total_amount'), 2)],
                    ['Cost of Goods Sold',  $sym.' '.number_format(SaleItem::join('sales','sales.id','sale_items.sale_id')->join('products','products.id','sale_items.product_id')->where('sales.status','completed')->whereBetween('sales.created_at',[$from.' 00:00:00',$to.' 23:59:59'])->when(!$isSuper,fn($q)=>$q->where('sales.branch_id',$branchId))->selectRaw('SUM(sale_items.quantity * products.cost_price)')->value(DB::raw('SUM(sale_items.quantity * products.cost_price)')), 2)],
                    ['Gross Profit',        $sym.' '.number_format((clone $salesQ)->sum('total_amount') - SaleItem::join('sales','sales.id','sale_items.sale_id')->join('products','products.id','sale_items.product_id')->where('sales.status','completed')->whereBetween('sales.created_at',[$from.' 00:00:00',$to.' 23:59:59'])->when(!$isSuper,fn($q)=>$q->where('sales.branch_id',$branchId))->sum(DB::raw('sale_items.quantity * products.cost_price')), 2)],
                    ['Total Expenses',      $sym.' '.number_format(Expense::whereBetween('created_at',[$from.' 00:00:00',$to.' 23:59:59'])->when(!$isSuper,fn($q)=>$q->where('branch_id',$branchId))->sum('amount'), 2)],
                    ['Net Profit',          $sym.' '.number_format((clone $salesQ)->sum('total_amount') - Expense::whereBetween('created_at',[$from.' 00:00:00',$to.' 23:59:59'])->when(!$isSuper,fn($q)=>$q->where('branch_id',$branchId))->sum('amount'), 2)],
                ],
                'totals' => [],
            ],

            'expense_report' => [
                'title'   => 'Expense Report',
                'headers' => ['Date', 'Category', 'Title', 'Amount', 'Added By'],
                'rows'    => Expense::with(['category','user'])
                    ->whereBetween('created_at', [$from.' 00:00:00', $to.' 23:59:59'])
                    ->when(!$isSuper, fn($q) => $q->where('branch_id', $branchId))
                    ->orderByDesc('created_at')->get()
                    ->map(fn($r) => [$r->created_at->format('d/m/Y'), $r->category->name ?? '-', $r->title, $sym.' '.number_format($r->amount,2), $r->user->name ?? '-'])
                    ->toArray(),
                'totals' => ['Total Expenses' => $sym.' '.number_format(Expense::whereBetween('created_at',[$from.' 00:00:00',$to.' 23:59:59'])->when(!$isSuper,fn($q)=>$q->where('branch_id',$branchId))->sum('amount'), 2)],
            ],

            'stock_report' => [
                'title'   => 'Stock Report',
                'headers' => ['Product', 'SKU', 'Category', 'Stock Qty', 'Alert Qty', 'Cost Price', 'Sell Price', 'Stock Value', 'Status'],
                'rows'    => Product::with('category')->get()
                    ->map(fn($p) => [
                        $p->name, $p->sku ?? '-', $p->category->name ?? '-',
                        $p->stock_quantity, $p->alert_quantity,
                        $sym.' '.number_format($p->cost_price,2),
                        $sym.' '.number_format($p->selling_price,2),
                        $sym.' '.number_format($p->stock_quantity * $p->cost_price, 2),
                        $p->stock_quantity <= 0 ? '🔴 Out of Stock' : ($p->isLowStock() ? '🟡 Low Stock' : '🟢 In Stock'),
                    ])->toArray(),
                'totals' => [
                    'Total Products'  => Product::count(),
                    'Low Stock'       => Product::lowStock()->count(),
                    'Total Stock Value' => $sym.' '.number_format(Product::sum(DB::raw('stock_quantity * cost_price')), 2),
                ],
            ],

            'tax_report' => [
                'title'   => 'Tax Report',
                'headers' => ['Date', 'Transactions', 'Taxable Sales', 'Tax Collected'],
                'rows'    => (clone $salesQ)
                    ->selectRaw('DATE(created_at) as date, COUNT(*) as txns, SUM(subtotal) as sub, SUM(tax_amount) as tax')
                    ->groupByRaw('DATE(created_at)')->orderBy('date')->get()
                    ->map(fn($r) => [$r->date, $r->txns, $sym.' '.number_format($r->sub,2), $sym.' '.number_format($r->tax,2)])
                    ->toArray(),
                'totals' => ['Total Tax Collected' => $sym.' '.number_format((clone $salesQ)->sum('tax_amount'), 2)],
            ],

            'payment_methods' => [
                'title'   => 'Payment Methods Breakdown',
                'headers' => ['Payment Method', 'Transactions', 'Total Amount', '%'],
                'rows'    => (function () use ($salesQ, $sym) {
                    $grand = (clone $salesQ)->sum('total_amount') ?: 1;
                    return (clone $salesQ)
                        ->selectRaw('payment_method, COUNT(*) as cnt, SUM(total_amount) as total')
                        ->groupBy('payment_method')->orderByDesc('total')->get()
                        ->map(fn($r) => [ucwords(str_replace('_',' ',$r->payment_method)), $r->cnt, $sym.' '.number_format($r->total,2), round($r->total/$grand*100,1).'%'])
                        ->toArray();
                })(),
                'totals' => ['Grand Total' => $sym.' '.number_format((clone $salesQ)->sum('total_amount'), 2)],
            ],

            default => ['title' => 'Report', 'headers' => [], 'rows' => [], 'totals' => []],
        };
    }
}
