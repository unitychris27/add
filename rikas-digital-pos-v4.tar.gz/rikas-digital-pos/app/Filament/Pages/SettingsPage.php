<?php

namespace App\Filament\Pages;

use App\Models\Setting;
use Filament\Actions\Action;
use Filament\Forms\Components\FileUpload;
use Filament\Forms\Components\Section;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Toggle;
use Filament\Forms\Concerns\InteractsWithForms;
use Filament\Forms\Contracts\HasForms;
use Filament\Forms\Form;
use Filament\Notifications\Notification;
use Filament\Pages\Page;

class SettingsPage extends Page implements HasForms
{
    use InteractsWithForms;

    protected static ?string $navigationIcon  = 'heroicon-o-cog-6-tooth';
    protected static ?string $navigationLabel = 'Business Settings';
    protected static ?string $navigationGroup = 'Administration';
    protected static ?int    $navigationSort  = 2;
    protected static string  $view            = 'filament.pages.settings';

    public ?array $data = [];

    public static function shouldRegisterNavigation(): bool
    {
        return auth()->check() && auth()->user()->hasAnyRole(['super_admin', 'manager']);
    }

    public function mount(): void
    {
        if (!auth()->user()->hasAnyRole(['super_admin', 'manager'])) abort(403);
        $this->form->fill([
            'business_name'      => Setting::get('business_name', 'RIKAS DIGITAL POS'),
            'business_address'   => Setting::get('business_address', ''),
            'business_phone'     => Setting::get('business_phone', ''),
            'business_email'     => Setting::get('business_email', ''),
            'business_website'   => Setting::get('business_website', ''),
            'tax_rate'           => Setting::get('tax_rate', 16),
            'receipt_footer'     => Setting::get('receipt_footer', 'Thank you for shopping with us!'),
            'low_stock_alert'    => Setting::get('low_stock_alert', 10),
            'default_currency'   => Setting::get('currency', 'KES'),
        ]);
    }

    public function form(Form $form): Form
    {
        return $form->schema([
            Section::make('Business Information')
                ->description('This information appears on receipts and reports.')
                ->schema([
                    TextInput::make('business_name')->label('Business Name')->required(),
                    TextInput::make('business_phone')->label('Phone Number'),
                    TextInput::make('business_email')->label('Email')->email(),
                    TextInput::make('business_website')->label('Website'),
                    Textarea::make('business_address')->label('Address')->rows(2)->columnSpanFull(),
                ])->columns(2),

            Section::make('Tax & Currency')
                ->schema([
                    TextInput::make('tax_rate')->label('Default Tax Rate (%)')->numeric()->default(16)->suffix('%'),
                    Select::make('default_currency')->label('Default Currency')
                        ->options(['KES' => '🇰🇪 KES — Kenya Shilling', 'CDF' => '🇨🇩 CDF — Congolese Franc', 'USD' => '🌐 USD — US Dollar']),
                ])->columns(2),

            Section::make('POS & Inventory')
                ->schema([
                    TextInput::make('low_stock_alert')->label('Low Stock Alert Threshold')->numeric()->default(10)
                        ->helperText('Notify when stock falls below this number'),
                    Textarea::make('receipt_footer')->label('Receipt Footer Message')->rows(2)
                        ->default('Thank you for shopping with us!'),
                ])->columns(2),
        ])->statePath('data');
    }

    public function save(): void
    {
        $d = $this->form->getState();
        foreach (['business_name','business_address','business_phone','business_email','business_website','tax_rate','receipt_footer','low_stock_alert'] as $key) {
            Setting::set($key, $d[$key] ?? '');
        }
        Setting::set('currency', $d['default_currency']);
        Notification::make()->title('Settings saved!')->success()->send();
    }

    protected function getHeaderActions(): array
    {
        return [Action::make('save')->label('Save Settings')->action('save')->color('primary')->icon('heroicon-o-check')];
    }
}
