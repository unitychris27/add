<?php

namespace App\Filament\Pages;

use App\Models\Branch;
use App\Models\Setting;
use App\Services\PaymentService;
use Filament\Actions\Action;
use Filament\Forms\Components\Section;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Toggle;
use Filament\Forms\Concerns\InteractsWithForms;
use Filament\Forms\Contracts\HasForms;
use Filament\Forms\Form;
use Filament\Notifications\Notification;
use Filament\Pages\Page;

class PaymentSettings extends Page implements HasForms
{
    use InteractsWithForms;

    protected static ?string $navigationIcon  = 'heroicon-o-credit-card';
    protected static ?string $navigationLabel = 'Payment Settings';
    protected static ?string $navigationGroup = 'Administration';
    protected static ?int    $navigationSort  = 5;
    protected static string  $view            = 'filament.pages.payment-settings';

    public ?array $data = [];

    public function mount(): void
    {
        $branches = Branch::where('is_active', true)->get();
        $formData = [
            'currency' => Setting::get('currency', 'KES'),
            'rate_kes' => Setting::get('rate_kes', 130),
            'rate_cdf' => Setting::get('rate_cdf', 2350),
        ];

        foreach ($branches as $branch) {
            $formData["api_key_branch_{$branch->id}"] = Setting::get("xdigitex_api_key_branch_{$branch->id}", '');
        }

        $this->form->fill($formData);
    }

    public function form(Form $form): Form
    {
        $branches   = Branch::where('is_active', true)->get();
        $apiFields  = [];

        foreach ($branches as $branch) {
            $apiFields[] = TextInput::make("api_key_branch_{$branch->id}")
                ->label("🏪 {$branch->name} — Xdigitex Pay API Key")
                ->placeholder('pg_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx')
                ->password()
                ->revealable()
                ->helperText('Get this from your Xdigitex Pay dashboard → API Keys');
        }

        return $form->schema([
            Section::make('Currency Settings')
                ->description('Choose which currency this store operates in. All prices and receipts will use this currency.')
                ->schema([
                    Select::make('currency')
                        ->label('Active Currency')
                        ->options([
                            'KES' => '🇰🇪 Kenya Shilling (KSh)',
                            'CDF' => '🇨🇩 Congolese Franc (FC)',
                            'USD' => '🇺🇸 US Dollar ($)',
                        ])
                        ->required()
                        ->live()
                        ->helperText('Switch between KES, CDF, and USD instantly.'),
                ])->columns(1),

            Section::make('Exchange Rates')
                ->description('Set how many units equal 1 USD. These are used to convert prices when switching currencies.')
                ->schema([
                    TextInput::make('rate_kes')
                        ->label('KES per 1 USD')
                        ->numeric()
                        ->default(130)
                        ->suffix('KSh = $1')
                        ->helperText('e.g. 130 means 130 KSh = 1 USD'),
                    TextInput::make('rate_cdf')
                        ->label('CDF per 1 USD')
                        ->numeric()
                        ->default(2350)
                        ->suffix('FC = $1')
                        ->helperText('e.g. 2350 means 2350 FC = 1 USD'),
                ])->columns(2),

            Section::make('Xdigitex Pay — API Keys Per Store')
                ->description('Each store/branch needs its own API key from Xdigitex Pay (pay.xdigitex.space). This enables STK push payments for Kenya (M-Pesa/Airtel) and DRC (Airtel/Orange/Vodacom).')
                ->schema($apiFields),
        ])->statePath('data');
    }

    public function save(): void
    {
        $data = $this->form->getState();

        // Save currency
        Setting::set('currency', $data['currency']);
        Setting::set('currency_symbol', PaymentService::currencySymbol($data['currency']));

        // Save rates
        Setting::set('rate_kes', $data['rate_kes']);
        Setting::set('rate_cdf', $data['rate_cdf']);
        Setting::set('rate_usd', 1);

        // Save per-branch API keys
        $branches = Branch::where('is_active', true)->get();
        foreach ($branches as $branch) {
            $key = "api_key_branch_{$branch->id}";
            if (!empty($data[$key])) {
                Setting::set("xdigitex_api_key_branch_{$branch->id}", $data[$key]);
            }
        }

        activity_log('payment_settings_saved', auth()->id(), 'Payment settings updated');

        Notification::make()
            ->title('Settings saved successfully!')
            ->success()
            ->send();
    }

    protected function getHeaderActions(): array
    {
        return [
            Action::make('save')
                ->label('Save Settings')
                ->action('save')
                ->color('primary'),
        ];
    }
}
