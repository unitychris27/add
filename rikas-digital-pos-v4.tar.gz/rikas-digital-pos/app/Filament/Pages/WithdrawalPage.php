<?php

namespace App\Filament\Pages;

use App\Models\Setting;
use App\Services\PaymentService;
use Filament\Actions\Action;
use Filament\Forms\Components\Section;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Concerns\InteractsWithForms;
use Filament\Forms\Contracts\HasForms;
use Filament\Forms\Form;
use Filament\Notifications\Notification;
use Filament\Pages\Page;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Http;

class WithdrawalPage extends Page implements HasForms
{
    use InteractsWithForms;

    protected static ?string $navigationIcon  = 'heroicon-o-arrow-down-tray';
    protected static ?string $navigationLabel = 'Withdraw Funds';
    protected static ?string $navigationGroup = 'Finance';
    protected static ?int    $navigationSort  = 3;
    protected static string  $view            = 'filament.pages.withdrawal';

    public ?array  $data         = [];
    public ?array  $balance      = null;
    public string  $balanceError = '';
    public array   $history      = [];

    public static function shouldRegisterNavigation(): bool
    {
        return auth()->check() && auth()->user()->hasAnyRole(['super_admin', 'manager']);
    }

    public function mount(): void
    {
        if (!Auth::user()->hasAnyRole(['super_admin', 'manager'])) abort(403);
        $this->loadBalance();
        $this->form->fill(['currency' => Setting::get('currency', 'KES'), 'method' => 'mobile_money']);
    }

    public function loadBalance(): void
    {
        try {
            $this->balance      = app(PaymentService::class)->getBalance(Auth::user()->branch_id);
            $this->balanceError = '';
        } catch (\Exception $e) {
            $this->balanceError = $e->getMessage();
            $this->balance      = null;
        }
    }

    public function form(Form $form): Form
    {
        $symbol = PaymentService::currencySymbol();

        return $form->schema([
            Section::make('Request Withdrawal')
                ->description('Withdraw funds from your Xdigitex Pay wallet to mobile money. A 2.5% fee is deducted.')
                ->schema([
                    TextInput::make('amount')
                        ->label('Amount to Withdraw')
                        ->numeric()->required()->minValue(1)
                        ->prefix($symbol),
                    Select::make('currency')
                        ->label('Currency')
                        ->options(['KES' => '🇰🇪 KES — Kenyan Shilling', 'CDF' => '🇨🇩 CDF — Congolese Franc', 'USD' => '🌐 USD — US Dollar'])
                        ->required(),
                    Select::make('method')
                        ->label('Method')
                        ->options(['mobile_money' => '📱 Mobile Money'])
                        ->default('mobile_money')
                        ->required(),
                    TextInput::make('account_number')
                        ->label('Mobile Money Number')
                        ->placeholder('+254712345678 or +243812345678')
                        ->required()
                        ->helperText('Use international format. Kenya: +254... | DRC: +243...'),
                ])->columns(2),
        ])->statePath('data');
    }

    public function withdraw(): void
    {
        $data = $this->form->getState();

        try {
            $apiKey = Setting::get('xdigitex_api_key_branch_' . Auth::user()->branch_id)
                   ?? Setting::get('xdigitex_api_key');

            if (!$apiKey) {
                Notification::make()->title('No API key configured')->body('Go to Payment Settings to add your Xdigitex Pay API key.')->danger()->send();
                return;
            }

            $response = Http::withHeaders(['X-API-Key' => $apiKey, 'Accept' => 'application/json'])
                ->post('https://pay.xdigitex.space/api/withdrawals', [
                    'amount'         => (float) $data['amount'],
                    'currency'       => $data['currency'],
                    'method'         => $data['method'],
                    'account_number' => $data['account_number'],
                ]);

            $result = $response->json();

            if ($result['success'] ?? false) {
                Notification::make()
                    ->title('Withdrawal submitted!')
                    ->body("Reference: {$result['reference']} | Status: {$result['status']} | Amount: {$result['amount']} | Fee: {$result['fee']}")
                    ->success()->persistent()->send();
                $this->loadBalance();
                $this->form->fill(['currency' => $data['currency'], 'method' => 'mobile_money']);
            } else {
                Notification::make()->title('Withdrawal failed')->body($result['message'] ?? 'Unknown error from payment gateway.')->danger()->send();
            }
        } catch (\Exception $e) {
            Notification::make()->title('Error')->body($e->getMessage())->danger()->send();
        }
    }

    protected function getHeaderActions(): array
    {
        return [
            Action::make('withdraw')->label('Submit Withdrawal')->action('withdraw')->color('warning')->icon('heroicon-o-arrow-down-tray'),
            Action::make('refresh')->label('Refresh Balance')->action('loadBalance')->color('gray')->icon('heroicon-o-arrow-path'),
        ];
    }
}
