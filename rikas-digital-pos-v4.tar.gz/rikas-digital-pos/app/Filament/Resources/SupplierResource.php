<?php

namespace App\Filament\Resources;

use App\Filament\Resources\SupplierResource\Pages;
use App\Models\Supplier;
use Filament\Forms\Components\Section;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Table;

class SupplierResource extends Resource
{
    protected static ?string $model           = Supplier::class;
    protected static ?string $navigationIcon  = 'heroicon-o-truck';
    protected static ?string $navigationGroup = 'Contacts';
    protected static ?string $navigationLabel = 'Suppliers';
    protected static ?int    $navigationSort  = 2;

    public static function form(Form $form): Form
    {
        return $form->schema([
            Section::make()->schema([
                TextInput::make('name')->required()->maxLength(191),
                TextInput::make('company')->maxLength(191),
                TextInput::make('email')->email()->maxLength(191),
                TextInput::make('phone')->maxLength(50),
                TextInput::make('tax_number')->label('Tax / VAT Number')->maxLength(100),
                TextInput::make('bank_account')->maxLength(191)->toggleable(),
                Textarea::make('address')->rows(2)->columnSpanFull(),
                TextInput::make('city')->maxLength(100),
                TextInput::make('country')->maxLength(100),
                Textarea::make('notes')->rows(2)->columnSpanFull(),
            ])->columns(2),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                TextColumn::make('name')->searchable()->sortable(),
                TextColumn::make('company')->searchable()->toggleable(),
                TextColumn::make('phone')->searchable(),
                TextColumn::make('email')->searchable()->toggleable(),
                TextColumn::make('city')->toggleable(),
                TextColumn::make('total_purchases')
                    ->label('Total Purchased')
                    ->getStateUsing(fn ($record) => 'KSh ' . number_format($record->purchases()->sum('total_amount'), 2))
                    ->toggleable(),
                TextColumn::make('created_at')->dateTime('d/m/Y')->sortable()->toggleable(),
            ])
            ->actions([Tables\Actions\EditAction::make(), Tables\Actions\DeleteAction::make()])
            ->bulkActions([Tables\Actions\BulkActionGroup::make([Tables\Actions\DeleteBulkAction::make()])]);
    }

    public static function getPages(): array
    {
        return [
            'index'  => Pages\ListSuppliers::route('/'),
            'create' => Pages\CreateSupplier::route('/create'),
            'edit'   => Pages\EditSupplier::route('/{record}/edit'),
        ];
    }
}
