<?php

namespace App\Filament\Resources;

use App\Filament\Resources\StockAdjustmentResource\Pages;
use App\Models\StockAdjustment;
use App\Models\Product;
use App\Models\Branch;
use Filament\Forms\Components\Section;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Table;
use Illuminate\Support\Facades\Auth;

class StockAdjustmentResource extends Resource
{
    protected static ?string $model           = StockAdjustment::class;
    protected static ?string $navigationIcon  = 'heroicon-o-adjustments-horizontal';
    protected static ?string $navigationGroup = 'Inventory';
    protected static ?string $navigationLabel = 'Stock Adjustment';
    protected static ?int    $navigationSort  = 4;

    public static function form(Form $form): Form
    {
        return $form->schema([
            Section::make()->schema([
                Select::make('branch_id')->label('Branch')
                    ->relationship('branch', 'name')
                    ->default(fn () => Auth::user()->branch_id)
                    ->required(),
                Select::make('product_id')->label('Product')
                    ->options(Product::active()->pluck('name', 'id'))
                    ->searchable()->required(),
                Select::make('type')->label('Adjustment Type')
                    ->options(['add' => '➕ Add Stock', 'remove' => '➖ Remove Stock', 'set' => '🔄 Set Exact Quantity'])
                    ->required(),
                TextInput::make('quantity')->numeric()->required()->minValue(1)
                    ->helperText('For "Set Exact", enter the new total quantity'),
                Textarea::make('reason')->label('Reason / Notes')->required()->rows(2)->columnSpanFull(),
            ])->columns(2),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                TextColumn::make('created_at')->label('Date')->dateTime('d/m/Y H:i')->sortable(),
                TextColumn::make('product.name')->searchable()->sortable(),
                TextColumn::make('branch.name')->toggleable(),
                TextColumn::make('type')->badge()
                    ->color(fn ($state) => match($state) { 'add' => 'success', 'remove' => 'danger', 'set' => 'info', default => 'gray' }),
                TextColumn::make('quantity_before')->label('Before'),
                TextColumn::make('quantity')->label('Adjusted By'),
                TextColumn::make('quantity_after')->label('After'),
                TextColumn::make('user.name')->label('Adjusted By')->toggleable(),
                TextColumn::make('reason')->limit(40)->toggleable(),
            ])
            ->defaultSort('created_at', 'desc')
            ->actions([Tables\Actions\ViewAction::make()])
            ->bulkActions([]);
    }

    public static function getPages(): array
    {
        return [
            'index'  => Pages\ListStockAdjustments::route('/'),
            'create' => Pages\CreateStockAdjustment::route('/create'),
        ];
    }
}
