<?php

namespace App\Filament\Resources;

use App\Filament\Resources\CustomerResource\Pages;
use App\Models\Customer;
use Filament\Forms\Components\Section;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\Select;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Table;

class CustomerResource extends Resource
{
    protected static ?string $model            = Customer::class;
    protected static ?string $navigationIcon   = 'heroicon-o-users';
    protected static ?string $navigationGroup  = 'Contacts';
    protected static ?string $navigationLabel  = 'Customers';
    protected static ?int    $navigationSort   = 1;

    public static function form(Form $form): Form
    {
        return $form->schema([
            Section::make()->schema([
                TextInput::make('name')->required()->maxLength(191),
                TextInput::make('email')->email()->maxLength(191),
                TextInput::make('phone')->maxLength(50),
                TextInput::make('company')->maxLength(191),
                TextInput::make('tax_number')->label('Tax / VAT Number')->maxLength(100),
                Select::make('type')->options(['retail' => 'Retail', 'wholesale' => 'Wholesale'])->default('retail'),
                Textarea::make('address')->rows(2)->columnSpanFull(),
                TextInput::make('city')->maxLength(100),
                TextInput::make('country')->maxLength(100),
                TextInput::make('credit_limit')->numeric()->prefix('KSh')->default(0),
            ])->columns(2),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                TextColumn::make('name')->searchable()->sortable(),
                TextColumn::make('phone')->searchable(),
                TextColumn::make('email')->searchable()->toggleable(),
                TextColumn::make('type')->badge()->color(fn ($state) => $state === 'wholesale' ? 'warning' : 'info'),
                TextColumn::make('city')->toggleable(),
                TextColumn::make('total_purchases')
                    ->label('Total Purchases')
                    ->getStateUsing(fn ($record) => 'KSh ' . number_format($record->sales()->sum('total_amount'), 2))
                    ->toggleable(),
                TextColumn::make('created_at')->dateTime('d/m/Y')->sortable()->toggleable(),
            ])
            ->filters([
                Tables\Filters\SelectFilter::make('type')->options(['retail' => 'Retail', 'wholesale' => 'Wholesale']),
            ])
            ->actions([Tables\Actions\EditAction::make(), Tables\Actions\DeleteAction::make()])
            ->bulkActions([Tables\Actions\BulkActionGroup::make([Tables\Actions\DeleteBulkAction::make()])]);
    }

    public static function getPages(): array
    {
        return [
            'index'  => Pages\ListCustomers::route('/'),
            'create' => Pages\CreateCustomer::route('/create'),
            'edit'   => Pages\EditCustomer::route('/{record}/edit'),
        ];
    }
}
