<?php

namespace App\Filament\Resources;

use App\Filament\Resources\SaleResource\Pages;
use App\Models\Sale;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;

class SaleResource extends Resource
{
    protected static ?string $model = Sale::class;
    protected static ?string $navigationIcon = 'heroicon-o-banknotes';
    protected static ?string $navigationGroup = 'Sales';
    protected static ?int $navigationSort = 1;

    public static function form(Form $form): Form
    {
        return $form->schema([
            Forms\Components\Section::make()->schema([
                Forms\Components\TextInput::make('invoice_number')->disabled(),
                Forms\Components\Select::make('status')
                    ->options(['completed' => 'Completed', 'draft' => 'Draft', 'refunded' => 'Refunded'])
                    ->required(),
                Forms\Components\TextInput::make('total_amount')->numeric()->prefix('KSh')->disabled(),
                Forms\Components\Select::make('payment_method')
                    ->options(['cash' => 'Cash', 'mpesa' => 'M-Pesa', 'card' => 'Card', 'bank_transfer' => 'Bank Transfer'])
                    ->disabled(),
                Forms\Components\Textarea::make('notes'),
            ])->columns(2),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\TextColumn::make('invoice_number')->searchable()->sortable(),
                Tables\Columns\TextColumn::make('user.name')->label('Cashier')->sortable(),
                Tables\Columns\TextColumn::make('customer.name')->label('Customer')->default('Walk-in'),
                Tables\Columns\TextColumn::make('total_amount')->money('KES')->sortable(),
                Tables\Columns\BadgeColumn::make('payment_method')
                    ->colors(['primary' => 'cash', 'success' => 'mpesa', 'info' => 'card']),
                Tables\Columns\BadgeColumn::make('status')
                    ->colors(['success' => 'completed', 'warning' => 'draft', 'danger' => 'refunded']),
                Tables\Columns\TextColumn::make('created_at')->dateTime('d/m/Y H:i')->sortable(),
            ])
            ->filters([
                Tables\Filters\SelectFilter::make('status')
                    ->options(['completed' => 'Completed', 'draft' => 'Draft', 'refunded' => 'Refunded']),
                Tables\Filters\SelectFilter::make('payment_method')
                    ->options(['cash' => 'Cash', 'mpesa' => 'M-Pesa', 'card' => 'Card']),
                Tables\Filters\Filter::make('created_at')
                    ->form([
                        Forms\Components\DatePicker::make('from'),
                        Forms\Components\DatePicker::make('until'),
                    ])
                    ->query(fn ($query, array $data) => $query
                        ->when($data['from'], fn ($q) => $q->whereDate('created_at', '>=', $data['from']))
                        ->when($data['until'], fn ($q) => $q->whereDate('created_at', '<=', $data['until']))
                    ),
            ])
            ->defaultSort('created_at', 'desc')
            ->actions([Tables\Actions\ViewAction::make()])
            ->bulkActions([]);
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListSales::route('/'),
            'view'  => Pages\ViewSale::route('/{record}'),
        ];
    }
}
