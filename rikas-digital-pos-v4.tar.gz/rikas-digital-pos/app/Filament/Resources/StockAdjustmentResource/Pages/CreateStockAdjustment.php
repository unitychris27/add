<?php
namespace App\Filament\Resources\StockAdjustmentResource\Pages;
use App\Filament\Resources\StockAdjustmentResource;
use App\Models\Product;
use Filament\Resources\Pages\CreateRecord;
use Illuminate\Support\Facades\Auth;
class CreateStockAdjustment extends CreateRecord {
    protected static string $resource = StockAdjustmentResource::class;
    protected function mutateFormDataBeforeCreate(array $data): array {
        $product = Product::find($data['product_id']);
        $before = $product ? $product->stock_quantity : 0;
        $data['quantity_before'] = $before;
        $data['user_id'] = Auth::id();
        $data['quantity_after'] = match($data['type']) {
            'add'    => $before + $data['quantity'],
            'remove' => max(0, $before - $data['quantity']),
            'set'    => $data['quantity'],
            default  => $before,
        };
        return $data;
    }
    protected function afterCreate(): void {
        $record = $this->record;
        Product::where('id', $record->product_id)->update(['stock_quantity' => $record->quantity_after]);
    }
}
