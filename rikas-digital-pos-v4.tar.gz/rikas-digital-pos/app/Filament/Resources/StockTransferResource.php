<?php

namespace App\Filament\Resources;

use App\Filament\Resources\StockTransferResource\Pages;
use App\Models\StockTransfer;
use App\Models\Product;
use App\Models\Branch;
use Filament\Forms\Components\Section;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Table;

class StockTransferResource extends Resource
{
    protected static ?string $model           = StockTransfer::class;
    protected static ?string $navigationIcon  = 'heroicon-o-arrows-right-left';
    protected static ?string $navigationGroup = 'Inventory';
    protected static ?string $navigationLabel = 'Stock Transfers';
    protected static ?int    $navigationSort  = 5;

    public static function form(Form $form): Form
    {
        return $form->schema([
            Section::make()->schema([
                Select::make('from_branch_id')->label('From Branch')
                    ->relationship('fromBranch', 'name')->required(),
                Select::make('to_branch_id')->label('To Branch')
                    ->relationship('toBranch', 'name')->required(),
                Select::make('product_id')->label('Product')
                    ->options(Product::active()->pluck('name', 'id'))
                    ->searchable()->required(),
                TextInput::make('quantity')->numeric()->required()->minValue(1),
                Select::make('status')->options(['pending' => 'Pending', 'completed' => 'Completed', 'cancelled' => 'Cancelled'])->default('pending'),
                Textarea::make('notes')->rows(2)->columnSpanFull(),
            ])->columns(2),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                TextColumn::make('created_at')->label('Date')->dateTime('d/m/Y')->sortable(),
                TextColumn::make('fromBranch.name')->label('From'),
                TextColumn::make('toBranch.name')->label('To'),
                TextColumn::make('product.name')->searchable(),
                TextColumn::make('quantity'),
                TextColumn::make('status')->badge()
                    ->color(fn ($state) => match($state) { 'completed' => 'success', 'pending' => 'warning', 'cancelled' => 'danger', default => 'gray' }),
                TextColumn::make('user.name')->label('Initiated By')->toggleable(),
            ])
            ->defaultSort('created_at', 'desc')
            ->actions([Tables\Actions\EditAction::make()])
            ->bulkActions([]);
    }

    public static function getPages(): array
    {
        return [
            'index'  => Pages\ListStockTransfers::route('/'),
            'create' => Pages\CreateStockTransfer::route('/create'),
            'edit'   => Pages\EditStockTransfer::route('/{record}/edit'),
        ];
    }
}
