<?php

namespace App\Filament\Resources;

use App\Filament\Resources\BranchResource\Pages;
use App\Models\Branch;
use Filament\Forms\Components\Section;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\Toggle;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Columns\IconColumn;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Table;

class BranchResource extends Resource
{
    protected static ?string $model           = Branch::class;
    protected static ?string $navigationIcon  = 'heroicon-o-building-storefront';
    protected static ?string $navigationGroup = 'Administration';
    protected static ?string $navigationLabel = 'Branches / Locations';
    protected static ?int    $navigationSort  = 1;

    public static function shouldRegisterNavigation(): bool
    {
        return auth()->check() && auth()->user()->hasRole('super_admin');
    }

    public static function form(Form $form): Form
    {
        return $form->schema([
            Section::make()->schema([
                TextInput::make('name')->required()->maxLength(191),
                TextInput::make('code')->label('Branch Code')->maxLength(20)->unique(ignoreRecord: true),
                TextInput::make('phone')->maxLength(50),
                TextInput::make('email')->email()->maxLength(191),
                TextInput::make('city')->maxLength(100),
                TextInput::make('country')->maxLength(100),
                Textarea::make('address')->rows(2)->columnSpanFull(),
                TextInput::make('xdigitex_api_key')->label('Xdigitex Pay API Key')
                    ->helperText('Get your API key from pay.xdigitex.space → Dashboard → API Keys')
                    ->password()->revealable()->columnSpanFull(),
                Toggle::make('is_active')->default(true)->label('Active'),
            ])->columns(2),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                TextColumn::make('name')->searchable()->sortable(),
                TextColumn::make('code')->badge()->color('gray'),
                TextColumn::make('city')->toggleable(),
                TextColumn::make('phone'),
                TextColumn::make('staff_count')->label('Staff')
                    ->getStateUsing(fn ($record) => $record->users()->count()),
                IconColumn::make('is_active')->boolean()->label('Active'),
                TextColumn::make('created_at')->dateTime('d/m/Y')->sortable()->toggleable(),
            ])
            ->actions([Tables\Actions\EditAction::make(), Tables\Actions\DeleteAction::make()])
            ->bulkActions([Tables\Actions\BulkActionGroup::make([Tables\Actions\DeleteBulkAction::make()])]);
    }

    public static function getPages(): array
    {
        return [
            'index'  => Pages\ListBranches::route('/'),
            'create' => Pages\CreateBranch::route('/create'),
            'edit'   => Pages\EditBranch::route('/{record}/edit'),
        ];
    }
}
