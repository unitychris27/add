<?php

namespace App\Filament\Resources;

use App\Filament\Resources\ExpenseCategoryResource\Pages;
use App\Models\ExpenseCategory;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Table;

class ExpenseCategoryResource extends Resource
{
    protected static ?string $model           = ExpenseCategory::class;
    protected static ?string $navigationIcon  = 'heroicon-o-folder';
    protected static ?string $navigationGroup = 'Finance';
    protected static ?string $navigationLabel = 'Expense Categories';
    protected static ?int    $navigationSort  = 2;

    public static function form(Form $form): Form
    {
        return $form->schema([
            TextInput::make('name')->required()->maxLength(191),
            TextInput::make('code')->label('Code / Short Name')->maxLength(20),
            Textarea::make('description')->rows(2)->columnSpanFull(),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table->columns([
            TextColumn::make('name')->searchable()->sortable(),
            TextColumn::make('code')->badge()->color('gray'),
            TextColumn::make('expenses_count')->label('Expenses')
                ->getStateUsing(fn ($r) => $r->expenses()->count()),
            TextColumn::make('total_amount')->label('Total Spent')
                ->getStateUsing(fn ($r) => 'KSh '.number_format($r->expenses()->sum('amount'), 2)),
        ])
        ->actions([Tables\Actions\EditAction::make(), Tables\Actions\DeleteAction::make()])
        ->bulkActions([Tables\Actions\BulkActionGroup::make([Tables\Actions\DeleteBulkAction::make()])]);
    }

    public static function getPages(): array
    {
        return [
            'index'  => Pages\ListExpenseCategories::route('/'),
            'create' => Pages\CreateExpenseCategory::route('/create'),
            'edit'   => Pages\EditExpenseCategory::route('/{record}/edit'),
        ];
    }
}
