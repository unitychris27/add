<?php

namespace App\Filament\Resources;

use App\Filament\Resources\PurchaseResource\Pages;
use App\Models\Purchase;
use App\Models\Product;
use App\Models\Supplier;
use App\Models\Branch;
use Filament\Forms\Components\DatePicker;
use Filament\Forms\Components\Repeater;
use Filament\Forms\Components\Section;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Columns\BadgeColumn;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Filters\SelectFilter;
use Filament\Tables\Table;

class PurchaseResource extends Resource
{
    protected static ?string $model           = Purchase::class;
    protected static ?string $navigationIcon  = 'heroicon-o-shopping-bag';
    protected static ?string $navigationGroup = 'Inventory';
    protected static ?string $navigationLabel = 'Purchases';
    protected static ?int    $navigationSort  = 3;

    public static function form(Form $form): Form
    {
        return $form->schema([
            Section::make('Purchase Details')->schema([
                Select::make('supplier_id')->label('Supplier')->relationship('supplier', 'name')->searchable()->preload()->required(),
                Select::make('branch_id')->label('Branch')->relationship('branch', 'name')->searchable()->preload()->required(),
                TextInput::make('reference_number')->label('Reference No')->maxLength(100)->default(fn () => 'PO-' . now()->format('Ymd') . '-' . strtoupper(substr(uniqid(), -4))),
                DatePicker::make('purchase_date')->default(now())->required(),
                Select::make('status')->options(['ordered' => 'Ordered', 'received' => 'Received', 'pending' => 'Pending', 'cancelled' => 'Cancelled'])->default('received')->required(),
                Select::make('payment_status')->options(['paid' => 'Paid', 'due' => 'Due', 'partial' => 'Partial'])->default('paid')->required(),
                TextInput::make('discount_amount')->numeric()->default(0)->prefix('KSh'),
                TextInput::make('tax_amount')->numeric()->default(0)->prefix('KSh'),
                TextInput::make('shipping_cost')->numeric()->default(0)->prefix('KSh'),
                Textarea::make('notes')->rows(2)->columnSpanFull(),
            ])->columns(2),

            Section::make('Items')->schema([
                Repeater::make('items')
                    ->relationship()
                    ->schema([
                        Select::make('product_id')->label('Product')
                            ->options(Product::pluck('name', 'id'))
                            ->searchable()->required()->columnSpan(4),
                        TextInput::make('quantity')->numeric()->required()->default(1)->columnSpan(2),
                        TextInput::make('unit_cost')->label('Unit Cost')->numeric()->required()->prefix('KSh')->columnSpan(3),
                        TextInput::make('subtotal')->numeric()->prefix('KSh')->disabled()->columnSpan(3),
                    ])
                    ->columns(12)
                    ->addActionLabel('Add Item')
                    ->reorderable(false),
            ]),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                TextColumn::make('reference_number')->label('Ref #')->searchable()->sortable(),
                TextColumn::make('supplier.name')->searchable()->sortable(),
                TextColumn::make('branch.name')->searchable()->toggleable(),
                TextColumn::make('purchase_date')->date('d/m/Y')->sortable(),
                TextColumn::make('total_amount')->money('kes')->sortable(),
                TextColumn::make('status')->badge()
                    ->color(fn ($state) => match($state) { 'received' => 'success', 'ordered' => 'info', 'pending' => 'warning', 'cancelled' => 'danger', default => 'gray' }),
                TextColumn::make('payment_status')->badge()
                    ->color(fn ($state) => match($state) { 'paid' => 'success', 'due' => 'danger', 'partial' => 'warning', default => 'gray' }),
            ])
            ->filters([
                SelectFilter::make('status')->options(['ordered' => 'Ordered', 'received' => 'Received', 'pending' => 'Pending', 'cancelled' => 'Cancelled']),
                SelectFilter::make('payment_status')->options(['paid' => 'Paid', 'due' => 'Due', 'partial' => 'Partial']),
            ])
            ->defaultSort('purchase_date', 'desc')
            ->actions([Tables\Actions\ViewAction::make(), Tables\Actions\EditAction::make()])
            ->bulkActions([Tables\Actions\BulkActionGroup::make([Tables\Actions\DeleteBulkAction::make()])]);
    }

    public static function getPages(): array
    {
        return [
            'index'  => Pages\ListPurchases::route('/'),
            'create' => Pages\CreatePurchase::route('/create'),
            'edit'   => Pages\EditPurchase::route('/{record}/edit'),
            'view'   => Pages\ViewPurchase::route('/{record}'),
        ];
    }
}
