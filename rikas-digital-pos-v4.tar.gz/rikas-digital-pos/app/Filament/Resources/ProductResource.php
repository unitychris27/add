<?php

namespace App\Filament\Resources;

use App\Filament\Resources\ProductResource\Pages;
use App\Models\Brand;
use App\Models\Category;
use App\Models\Product;
use App\Models\Supplier;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;
use Illuminate\Support\Str;

class ProductResource extends Resource
{
    protected static ?string $model = Product::class;
    protected static ?string $navigationIcon = 'heroicon-o-shopping-bag';
    protected static ?string $navigationGroup = 'Inventory';
    protected static ?int $navigationSort = 1;

    public static function form(Form $form): Form
    {
        return $form->schema([
            Forms\Components\Section::make('Basic Information')->schema([
                Forms\Components\TextInput::make('name')
                    ->required()
                    ->maxLength(255)
                    ->live(onBlur: true)
                    ->afterStateUpdated(fn ($state, Forms\Set $set) => $set('slug', Str::slug($state))),
                Forms\Components\TextInput::make('slug')->required()->maxLength(255),
                Forms\Components\Select::make('category_id')
                    ->label('Category')
                    ->options(Category::where('is_active', true)->pluck('name', 'id'))
                    ->searchable(),
                Forms\Components\Select::make('brand_id')
                    ->label('Brand')
                    ->options(Brand::where('is_active', true)->pluck('name', 'id'))
                    ->searchable(),
                Forms\Components\Select::make('supplier_id')
                    ->label('Supplier')
                    ->options(Supplier::where('is_active', true)->pluck('name', 'id'))
                    ->searchable(),
                Forms\Components\Textarea::make('description')->columnSpanFull(),
                Forms\Components\FileUpload::make('image')
                    ->image()
                    ->directory('products')
                    ->columnSpanFull(),
            ])->columns(2),

            Forms\Components\Section::make('Identifiers')->schema([
                Forms\Components\TextInput::make('sku')->label('SKU')->unique(ignoreRecord: true),
                Forms\Components\TextInput::make('barcode')->unique(ignoreRecord: true),
                Forms\Components\Select::make('unit')
                    ->options(['pcs' => 'Pieces', 'kg' => 'Kilograms', 'litre' => 'Litres', 'metre' => 'Metres', 'box' => 'Box'])
                    ->default('pcs')
                    ->required(),
            ])->columns(3),

            Forms\Components\Section::make('Pricing')->schema([
                Forms\Components\TextInput::make('cost_price')
                    ->numeric()->prefix('KSh')->required(),
                Forms\Components\TextInput::make('selling_price')
                    ->numeric()->prefix('KSh')->required(),
                Forms\Components\TextInput::make('wholesale_price')
                    ->numeric()->prefix('KSh'),
                Forms\Components\TextInput::make('tax_rate')
                    ->numeric()->suffix('%')->default(0),
                Forms\Components\Toggle::make('tax_inclusive')->label('Tax Inclusive Price'),
            ])->columns(3),

            Forms\Components\Section::make('Inventory')->schema([
                Forms\Components\TextInput::make('stock_quantity')
                    ->integer()->required()->default(0),
                Forms\Components\TextInput::make('alert_quantity')
                    ->integer()->required()->default(5)->label('Low Stock Alert At'),
                Forms\Components\Toggle::make('track_inventory')->default(true),
                Forms\Components\Toggle::make('is_active')->default(true),
                Forms\Components\Toggle::make('is_featured'),
            ])->columns(3),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\ImageColumn::make('image')->square()->size(40),
                Tables\Columns\TextColumn::make('name')->searchable()->sortable(),
                Tables\Columns\TextColumn::make('sku')->searchable()->toggleable(),
                Tables\Columns\TextColumn::make('barcode')->searchable()->toggleable(),
                Tables\Columns\TextColumn::make('category.name')->sortable(),
                Tables\Columns\TextColumn::make('selling_price')
                    ->money('KES')->sortable(),
                Tables\Columns\TextColumn::make('stock_quantity')
                    ->sortable()
                    ->color(fn ($record) => $record->isLowStock() ? 'danger' : 'success')
                    ->badge(),
                Tables\Columns\IconColumn::make('is_active')->boolean(),
            ])
            ->filters([
                Tables\Filters\SelectFilter::make('category_id')
                    ->label('Category')
                    ->options(Category::pluck('name', 'id')),
                Tables\Filters\TernaryFilter::make('is_active')->label('Active'),
                Tables\Filters\Filter::make('low_stock')
                    ->label('Low Stock Only')
                    ->query(fn ($query) => $query->lowStock()),
            ])
            ->actions([
                Tables\Actions\EditAction::make(),
                Tables\Actions\DeleteAction::make(),
            ])
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\DeleteBulkAction::make(),
                ]),
            ]);
    }

    public static function getPages(): array
    {
        return [
            'index'  => Pages\ListProducts::route('/'),
            'create' => Pages\CreateProduct::route('/create'),
            'edit'   => Pages\EditProduct::route('/{record}/edit'),
        ];
    }
}
