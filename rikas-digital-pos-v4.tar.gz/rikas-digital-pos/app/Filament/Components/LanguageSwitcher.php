<?php

namespace App\Filament\Components;

use Filament\Actions\Action;
use Filament\Actions\ActionGroup;
use Filament\Navigation\NavigationItem;
use Illuminate\Support\Facades\Session;
use Livewire\Component;

class LanguageSwitcher extends Component
{
    public function switchLanguage(string $locale): void
    {
        if (!in_array($locale, ['en', 'fr'])) return;

        Session::put('locale', $locale);
        app()->setLocale($locale);

        $this->dispatch('locale-changed', locale: $locale);
        $this->redirect(request()->header('Referer', '/admin'));
    }

    public function render(): \Illuminate\View\View
    {
        return view('filament.components.language-switcher');
    }
}
