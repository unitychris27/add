<?php

namespace App\Filament\Widgets;

use App\Models\Product;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Table;
use Filament\Widgets\TableWidget as BaseWidget;

class StockAlertWidget extends BaseWidget
{
    protected static ?int    $sort    = 3;
    protected static ?string $heading = '⚠ Stock Alerts';
    protected int | string | array $columnSpan = 'full';

    public function table(Table $table): Table
    {
        return $table
            ->query(
                Product::query()
                    ->where('track_inventory', true)
                    ->where(function ($q) {
                        $q->whereColumn('stock_quantity', '<=', 'alert_quantity')
                          ->orWhere('stock_quantity', '<=', 0);
                    })
                    ->orderBy('stock_quantity')
            )
            ->columns([
                TextColumn::make('name')->label('Product')->searchable()->weight('bold'),
                TextColumn::make('sku')->label('SKU')->toggleable()->badge()->color('gray'),
                TextColumn::make('category.name')->label('Category')->toggleable(),
                TextColumn::make('stock_quantity')->label('Current Stock')
                    ->badge()
                    ->color(fn ($state) => $state <= 0 ? 'danger' : 'warning'),
                TextColumn::make('alert_quantity')->label('Alert Level')->badge()->color('gray'),
                TextColumn::make('selling_price')->label('Sell Price')
                    ->money('kes')->toggleable(),
                TextColumn::make('status_label')
                    ->label('Status')
                    ->badge()
                    ->getStateUsing(fn ($r) => $r->stock_quantity <= 0 ? 'Out of Stock' : 'Low Stock')
                    ->color(fn ($state) => $state === 'Out of Stock' ? 'danger' : 'warning'),
            ])
            ->defaultSort('stock_quantity')
            ->paginated([10, 25])
            ->emptyStateHeading('All products are well stocked! ✅')
            ->emptyStateDescription('No products are below their alert quantity.');
    }
}
