<?php

namespace App\Filament\Widgets;

use App\Models\Sale;
use App\Services\PaymentService;
use Filament\Tables\Columns\BadgeColumn;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Table;
use Filament\Widgets\TableWidget as BaseWidget;
use Illuminate\Support\Facades\Auth;

class RecentSalesTable extends BaseWidget
{
    protected static ?int $sort = 2;
    protected int | string | array $columnSpan = 'full';
    protected static ?string $heading = null;

    public function getHeading(): string
    {
        return __('Recent Transactions');
    }

    public function table(Table $table): Table
    {
        $user    = Auth::user();
        $symbol  = PaymentService::currencySymbol();
        $query   = Sale::query()->with(['customer', 'cashier', 'branch'])->latest()->limit(15);

        if ($user && $user->hasRole('manager')) {
            $query->where('branch_id', $user->branch_id);
        } elseif ($user && $user->hasRole('cashier')) {
            $query->where('cashier_id', $user->id);
        }

        return $table
            ->query($query)
            ->columns([
                TextColumn::make('invoice_no')
                    ->label(__('Invoice'))
                    ->searchable()
                    ->copyable()
                    ->weight('bold')
                    ->color('warning'),

                TextColumn::make('customer.name')
                    ->label(__('Customer'))
                    ->default('Walk-in')
                    ->searchable(),

                TextColumn::make('cashier.name')
                    ->label(__('Cashier'))
                    ->default('-'),

                TextColumn::make('branch.name')
                    ->label(__('Branch'))
                    ->default('-'),

                TextColumn::make('total_amount')
                    ->label(__('Total'))
                    ->formatStateUsing(fn ($state) => $symbol . ' ' . number_format($state, 2))
                    ->weight('bold')
                    ->color('success'),

                TextColumn::make('payment_method')
                    ->label(__('Payment Method'))
                    ->badge()
                    ->color(fn (string $state): string => match ($state) {
                        'cash'         => 'success',
                        'mobile_money' => 'warning',
                        'card'         => 'info',
                        default        => 'gray',
                    })
                    ->formatStateUsing(fn (string $state): string => match ($state) {
                        'cash'         => '💵 ' . __('Cash'),
                        'mobile_money' => '📱 ' . __('Mobile Money'),
                        'card'         => '💳 ' . __('Card'),
                        default        => $state,
                    }),

                TextColumn::make('status')
                    ->label(__('Status'))
                    ->badge()
                    ->color(fn (string $state): string => match ($state) {
                        'completed' => 'success',
                        'refunded'  => 'warning',
                        'cancelled' => 'danger',
                        default     => 'gray',
                    }),

                TextColumn::make('created_at')
                    ->label(__('Date'))
                    ->dateTime('d M Y, H:i')
                    ->sortable(),
            ])
            ->defaultSort('created_at', 'desc')
            ->paginated(false);
    }
}
