<?php

namespace App\Filament\Widgets;

use App\Models\Customer;
use App\Models\Expense;
use App\Models\Product;
use App\Models\Sale;
use App\Models\User;
use App\Services\PaymentService;
use Filament\Widgets\StatsOverviewWidget as BaseWidget;
use Filament\Widgets\StatsOverviewWidget\Stat;
use Illuminate\Support\Facades\Auth;

class StatsOverview extends BaseWidget
{
    protected static ?int $sort = 1;

    protected function getStats(): array
    {
        $user     = Auth::user();
        $symbol   = PaymentService::currencySymbol();
        $currency = \App\Models\Setting::get('currency', 'KES');

        $salesQuery    = Sale::query();
        $expenseQuery  = Expense::query();

        // Managers only see their branch
        if ($user && $user->hasRole('manager')) {
            $salesQuery->where('branch_id', $user->branch_id);
            $expenseQuery->where('branch_id', $user->branch_id);
        }

        $todaySales   = (clone $salesQuery)->whereDate('created_at', today())->sum('total_amount');
        $weeklySales  = (clone $salesQuery)->whereBetween('created_at', [now()->startOfWeek(), now()->endOfWeek()])->sum('total_amount');
        $monthlySales = (clone $salesQuery)->whereMonth('created_at', now()->month)->sum('total_amount');
        $totalExpenses= (clone $expenseQuery)->whereMonth('created_at', now()->month)->sum('amount');
        $netProfit    = $monthlySales - $totalExpenses;

        $totalProducts = Product::count();
        $lowStock      = Product::where('stock_quantity', '<=', 10)->where('stock_quantity', '>', 0)->count();
        $outOfStock    = Product::where('stock_quantity', 0)->count();
        $totalCustomers= Customer::count();

        $stats = [
            Stat::make(__('Total Sales Today'), $symbol . ' ' . number_format($todaySales, 2))
                ->description(__('Today\'s revenue'))
                ->descriptionIcon('heroicon-m-arrow-trending-up')
                ->color('warning')
                ->chart([7, 3, 4, 5, 6, $todaySales > 0 ? min(10, $todaySales / 1000) : 3, 5]),

            Stat::make(__('Weekly Sales'), $symbol . ' ' . number_format($weeklySales, 2))
                ->description(__('This week'))
                ->descriptionIcon('heroicon-m-calendar-days')
                ->color('warning'),

            Stat::make(__('Monthly Revenue'), $symbol . ' ' . number_format($monthlySales, 2))
                ->description(now()->format('F Y'))
                ->descriptionIcon('heroicon-m-banknotes')
                ->color('warning'),

            Stat::make(__('Net Profit'), $symbol . ' ' . number_format($netProfit, 2))
                ->description(__('Revenue minus expenses'))
                ->descriptionIcon($netProfit >= 0 ? 'heroicon-m-arrow-trending-up' : 'heroicon-m-arrow-trending-down')
                ->color($netProfit >= 0 ? 'success' : 'danger'),

            Stat::make(__('Total Expenses'), $symbol . ' ' . number_format($totalExpenses, 2))
                ->description(__('This month'))
                ->descriptionIcon('heroicon-m-receipt-percent')
                ->color('danger'),

            Stat::make(__('Total Products'), number_format($totalProducts))
                ->description(__('In system'))
                ->descriptionIcon('heroicon-m-cube')
                ->color('info'),

            Stat::make(__('Low Stock'), number_format($lowStock))
                ->description(__('Need restocking'))
                ->descriptionIcon('heroicon-m-exclamation-triangle')
                ->color('warning'),

            Stat::make(__('Out of Stock'), number_format($outOfStock))
                ->description(__('Zero stock'))
                ->descriptionIcon('heroicon-m-x-circle')
                ->color('danger'),

            Stat::make(__('Total Customers'), number_format($totalCustomers))
                ->description(__('Registered'))
                ->descriptionIcon('heroicon-m-users')
                ->color('info'),
        ];

        // Super admin extra stats
        if ($user && $user->hasRole('super_admin')) {
            $stats[] = Stat::make(__('Total Staff'), number_format(User::count()))
                ->description(__('All users'))
                ->descriptionIcon('heroicon-m-identification')
                ->color('info');
        }

        return $stats;
    }
}
