<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Models\Expense;
use App\Models\Product;
use App\Models\Purchase;
use App\Models\Sale;
use App\Models\User;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class DashboardController extends Controller
{
    public function summary(Request $request): JsonResponse
    {
        $user     = $request->user();
        $branchId = $user->hasRole('super_admin') ? null : $user->branch_id;

        $today         = today();
        $startOfMonth  = now()->startOfMonth();
        $startOfWeek   = now()->startOfWeek();

        $salesQuery = Sale::completed()
            ->when($branchId, fn ($q) => $q->where('branch_id', $branchId));

        $todaySales   = (clone $salesQuery)->whereDate('created_at', $today);
        $monthlySales = (clone $salesQuery)->where('created_at', '>=', $startOfMonth);
        $weeklySales  = (clone $salesQuery)->where('created_at', '>=', $startOfWeek);

        $expenseQuery   = Expense::where('status', 'approved')
            ->when($branchId, fn ($q) => $q->where('branch_id', $branchId));
        $todayExpenses  = (clone $expenseQuery)->whereDate('expense_date', $today)->sum('amount');
        $monthExpenses  = (clone $expenseQuery)->where('expense_date', '>=', $startOfMonth)->sum('amount');

        $lowStockCount  = Product::lowStock()->active()->count();

        $salesChartData = Sale::completed()
            ->when($branchId, fn ($q) => $q->where('branch_id', $branchId))
            ->where('created_at', '>=', now()->subDays(30))
            ->select(DB::raw('DATE(created_at) as date'), DB::raw('SUM(total_amount) as total'), DB::raw('COUNT(*) as count'))
            ->groupBy('date')
            ->orderBy('date')
            ->get();

        $topProducts = DB::table('sale_items')
            ->join('sales', 'sales.id', '=', 'sale_items.sale_id')
            ->join('products', 'products.id', '=', 'sale_items.product_id')
            ->where('sales.status', 'completed')
            ->when($branchId, fn ($q) => $q->where('sales.branch_id', $branchId))
            ->whereDate('sales.created_at', '>=', $startOfMonth)
            ->select('products.name', DB::raw('SUM(sale_items.quantity) as total_quantity'), DB::raw('SUM(sale_items.subtotal) as total_revenue'))
            ->groupBy('products.id', 'products.name')
            ->orderByDesc('total_revenue')
            ->limit(5)
            ->get();

        $topCashiers = User::withCount(['sales as sales_count' => fn ($q) => $q->completed()->whereDate('created_at', $today)])
            ->withSum(['sales as today_revenue' => fn ($q) => $q->completed()->whereDate('created_at', $today)], 'total_amount')
            ->when($branchId, fn ($q) => $q->where('branch_id', $branchId))
            ->having('sales_count', '>', 0)
            ->orderByDesc('today_revenue')
            ->limit(5)
            ->get(['id', 'name', 'avatar', 'sales_count', 'today_revenue']);

        return response()->json([
            'success' => true,
            'data'    => [
                'today' => [
                    'revenue'       => $todaySales->sum('total_amount'),
                    'transactions'  => $todaySales->count(),
                    'expenses'      => $todayExpenses,
                    'profit'        => $todaySales->sum('total_amount') - $todaySales->sum(DB::raw('(SELECT SUM(si.cost_price * si.quantity) FROM sale_items si WHERE si.sale_id = sales.id)')) - $todayExpenses,
                ],
                'week' => [
                    'revenue'      => $weeklySales->sum('total_amount'),
                    'transactions' => $weeklySales->count(),
                ],
                'month' => [
                    'revenue'      => $monthlySales->sum('total_amount'),
                    'transactions' => $monthlySales->count(),
                    'expenses'     => $monthExpenses,
                ],
                'low_stock_count' => $lowStockCount,
                'chart_data'      => $salesChartData,
                'top_products'    => $topProducts,
                'top_cashiers'    => $topCashiers,
            ],
        ]);
    }
}
