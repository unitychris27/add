<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Models\Product;
use App\Models\Purchase;
use App\Models\PurchaseItem;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class PurchaseController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $user = $request->user();

        $purchases = Purchase::with(['supplier:id,name', 'user:id,name'])
            ->when(!$user->hasRole('super_admin'), fn ($q) => $q->where('branch_id', $user->branch_id))
            ->when($request->supplier_id, fn ($q) => $q->where('supplier_id', $request->supplier_id))
            ->when($request->status, fn ($q) => $q->where('status', $request->status))
            ->when($request->date_from, fn ($q) => $q->whereDate('purchase_date', '>=', $request->date_from))
            ->when($request->date_to, fn ($q) => $q->whereDate('purchase_date', '<=', $request->date_to))
            ->orderByDesc('created_at')
            ->paginate($request->per_page ?? 20);

        return response()->json(['success' => true, 'data' => $purchases]);
    }

    public function store(Request $request): JsonResponse
    {
        $data = $request->validate([
            'supplier_id'            => 'nullable|exists:suppliers,id',
            'invoice_number'         => 'nullable|string|max:100',
            'purchase_date'          => 'required|date',
            'items'                  => 'required|array|min:1',
            'items.*.product_id'     => 'required|exists:products,id',
            'items.*.quantity'       => 'required|integer|min:1',
            'items.*.unit_cost'      => 'required|numeric|min:0',
            'items.*.discount_amount' => 'nullable|numeric|min:0',
            'items.*.tax_amount'     => 'nullable|numeric|min:0',
            'items.*.expiry_date'    => 'nullable|date',
            'items.*.batch_number'   => 'nullable|string',
            'discount_amount'        => 'nullable|numeric|min:0',
            'tax_amount'             => 'nullable|numeric|min:0',
            'shipping_cost'          => 'nullable|numeric|min:0',
            'paid_amount'            => 'nullable|numeric|min:0',
            'notes'                  => 'nullable|string',
        ]);

        DB::beginTransaction();
        try {
            $subtotal = collect($data['items'])->sum(fn ($i) => $i['unit_cost'] * $i['quantity'] - ($i['discount_amount'] ?? 0));
            $total    = $subtotal + ($data['tax_amount'] ?? 0) + ($data['shipping_cost'] ?? 0) - ($data['discount_amount'] ?? 0);

            $purchase = Purchase::create([
                'branch_id'       => $request->user()->branch_id,
                'user_id'         => $request->user()->id,
                'supplier_id'     => $data['supplier_id'] ?? null,
                'invoice_number'  => $data['invoice_number'] ?? null,
                'purchase_date'   => $data['purchase_date'],
                'status'          => 'received',
                'subtotal'        => $subtotal,
                'tax_amount'      => $data['tax_amount'] ?? 0,
                'discount_amount' => $data['discount_amount'] ?? 0,
                'shipping_cost'   => $data['shipping_cost'] ?? 0,
                'total_amount'    => $total,
                'paid_amount'     => $data['paid_amount'] ?? $total,
                'payment_status'  => ($data['paid_amount'] ?? $total) >= $total ? 'paid' : (($data['paid_amount'] ?? 0) > 0 ? 'partial' : 'unpaid'),
                'notes'           => $data['notes'] ?? null,
            ]);

            foreach ($data['items'] as $item) {
                $subtotal = $item['unit_cost'] * $item['quantity'] - ($item['discount_amount'] ?? 0);
                PurchaseItem::create([
                    'purchase_id'       => $purchase->id,
                    'product_id'        => $item['product_id'],
                    'product_name'      => Product::find($item['product_id'])->name,
                    'unit_cost'         => $item['unit_cost'],
                    'quantity'          => $item['quantity'],
                    'quantity_received' => $item['quantity'],
                    'discount_amount'   => $item['discount_amount'] ?? 0,
                    'tax_amount'        => $item['tax_amount'] ?? 0,
                    'subtotal'          => $subtotal,
                    'expiry_date'       => $item['expiry_date'] ?? null,
                    'batch_number'      => $item['batch_number'] ?? null,
                ]);

                // Update stock
                Product::where('id', $item['product_id'])
                    ->increment('stock_quantity', $item['quantity']);
            }

            DB::commit();
            activity_log('purchase_created', $request->user()->id, "Purchase #{$purchase->reference_number} created");

            return response()->json(['success' => true, 'data' => $purchase->load(['items', 'supplier'])], 201);
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json(['success' => false, 'message' => 'Failed to create purchase: ' . $e->getMessage()], 500);
        }
    }

    public function show(Purchase $purchase): JsonResponse
    {
        return response()->json([
            'success' => true,
            'data'    => $purchase->load(['items.product', 'supplier', 'user:id,name']),
        ]);
    }
}
