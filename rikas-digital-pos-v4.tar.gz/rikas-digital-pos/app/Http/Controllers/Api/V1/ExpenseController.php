<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Models\Expense;
use App\Models\ExpenseCategory;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class ExpenseController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $user = $request->user();

        $expenses = Expense::with(['category:id,name,color', 'user:id,name'])
            ->when(!$user->hasRole('super_admin'), fn ($q) => $q->where('branch_id', $user->branch_id))
            ->when($user->hasRole('associate'), fn ($q) => $q->where('user_id', $user->id))
            ->when($request->status, fn ($q) => $q->where('status', $request->status))
            ->when($request->category_id, fn ($q) => $q->where('expense_category_id', $request->category_id))
            ->when($request->date_from, fn ($q) => $q->whereDate('expense_date', '>=', $request->date_from))
            ->when($request->date_to, fn ($q) => $q->whereDate('expense_date', '<=', $request->date_to))
            ->orderByDesc('expense_date')
            ->paginate($request->per_page ?? 20);

        return response()->json(['success' => true, 'data' => $expenses]);
    }

    public function store(Request $request): JsonResponse
    {
        $data = $request->validate([
            'expense_category_id' => 'required|exists:expense_categories,id',
            'title'               => 'required|string|max:255',
            'description'         => 'nullable|string',
            'amount'              => 'required|numeric|min:0.01',
            'payment_method'      => 'required|in:cash,mpesa,card,bank_transfer',
            'reference'           => 'nullable|string|max:100',
            'expense_date'        => 'required|date',
            'notes'               => 'nullable|string',
        ]);

        $expense = Expense::create(array_merge($data, [
            'branch_id' => $request->user()->branch_id,
            'user_id'   => $request->user()->id,
            'status'    => $request->user()->hasRole('associate') ? 'pending' : 'approved',
            'approved_by'  => !$request->user()->hasRole('associate') ? $request->user()->id : null,
            'approved_at'  => !$request->user()->hasRole('associate') ? now() : null,
        ]));

        activity_log('expense_created', $request->user()->id, "Expense '{$expense->title}' created - KSh {$expense->amount}");

        return response()->json(['success' => true, 'data' => $expense->load('category')], 201);
    }

    public function approve(Request $request, Expense $expense): JsonResponse
    {
        $this->authorize('approve', $expense);

        if ($expense->status !== 'pending') {
            return response()->json(['success' => false, 'message' => 'Expense is not pending approval.'], 422);
        }

        $expense->update([
            'status'      => 'approved',
            'approved_by' => $request->user()->id,
            'approved_at' => now(),
        ]);

        return response()->json(['success' => true, 'data' => $expense->fresh()]);
    }

    public function reject(Request $request, Expense $expense): JsonResponse
    {
        $this->authorize('approve', $expense);
        $expense->update(['status' => 'rejected']);
        return response()->json(['success' => true, 'message' => 'Expense rejected.']);
    }

    public function categories(): JsonResponse
    {
        $categories = ExpenseCategory::where('is_active', true)->orderBy('name')->get();
        return response()->json(['success' => true, 'data' => $categories]);
    }
}
