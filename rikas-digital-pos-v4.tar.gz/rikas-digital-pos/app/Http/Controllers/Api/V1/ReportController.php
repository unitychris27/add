<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Services\ReportService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Response;

class ReportController extends Controller
{
    public function __construct(private ReportService $reportService) {}

    public function sales(Request $request): JsonResponse
    {
        $request->validate([
            'date_from' => 'required|date',
            'date_to'   => 'required|date|after_or_equal:date_from',
            'branch_id' => 'nullable|exists:branches,id',
            'group_by'  => 'nullable|in:day,week,month',
        ]);

        $data = $this->reportService->salesReport($request->all(), $request->user());
        return response()->json(['success' => true, 'data' => $data]);
    }

    public function expenses(Request $request): JsonResponse
    {
        $request->validate([
            'date_from' => 'required|date',
            'date_to'   => 'required|date|after_or_equal:date_from',
            'branch_id' => 'nullable|exists:branches,id',
        ]);

        $data = $this->reportService->expensesReport($request->all(), $request->user());
        return response()->json(['success' => true, 'data' => $data]);
    }

    public function stock(Request $request): JsonResponse
    {
        $data = $this->reportService->stockReport($request->all());
        return response()->json(['success' => true, 'data' => $data]);
    }

    public function profitLoss(Request $request): JsonResponse
    {
        $request->validate([
            'date_from' => 'required|date',
            'date_to'   => 'required|date|after_or_equal:date_from',
        ]);

        $data = $this->reportService->profitLossReport($request->all(), $request->user());
        return response()->json(['success' => true, 'data' => $data]);
    }

    public function export(Request $request): Response
    {
        $request->validate([
            'type'      => 'required|in:sales,expenses,stock,profit_loss',
            'format'    => 'required|in:pdf,excel,csv',
            'date_from' => 'nullable|date',
            'date_to'   => 'nullable|date',
        ]);

        return $this->reportService->export(
            $request->type,
            $request->format,
            $request->all(),
            $request->user()
        );
    }
}
