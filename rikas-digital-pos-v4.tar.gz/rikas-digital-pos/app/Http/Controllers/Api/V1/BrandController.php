<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Models\Brand;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class BrandController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $brands = Brand::when($request->search, fn ($q) => $q->where('name', 'like', "%{$request->search}%"))
            ->withCount('products')
            ->orderBy('name')
            ->get();

        return response()->json(['success' => true, 'data' => $brands]);
    }

    public function store(Request $request): JsonResponse
    {
        $data = $request->validate([
            'name'        => 'required|string|max:255|unique:brands',
            'description' => 'nullable|string',
            'is_active'   => 'boolean',
        ]);

        $data['slug'] = Str::slug($data['name']);
        $brand = Brand::create($data);

        return response()->json(['success' => true, 'data' => $brand], 201);
    }

    public function show(Brand $brand): JsonResponse
    {
        return response()->json(['success' => true, 'data' => $brand->loadCount('products')]);
    }

    public function update(Request $request, Brand $brand): JsonResponse
    {
        $data = $request->validate([
            'name'        => 'sometimes|string|max:255|unique:brands,name,' . $brand->id,
            'description' => 'nullable|string',
            'is_active'   => 'boolean',
        ]);

        $brand->update($data);
        return response()->json(['success' => true, 'data' => $brand->fresh()]);
    }

    public function destroy(Brand $brand): JsonResponse
    {
        $brand->delete();
        return response()->json(['success' => true, 'message' => 'Brand deleted.']);
    }
}
