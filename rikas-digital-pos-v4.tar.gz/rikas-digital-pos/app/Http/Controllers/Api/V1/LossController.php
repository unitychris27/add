<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Models\Loss;
use App\Models\Product;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class LossController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $user = $request->user();

        $losses = Loss::with(['product:id,name,sku', 'user:id,name'])
            ->when(!$user->hasRole('super_admin'), fn ($q) => $q->where('branch_id', $user->branch_id))
            ->when($request->type, fn ($q) => $q->where('type', $request->type))
            ->when($request->status, fn ($q) => $q->where('status', $request->status))
            ->when($request->date_from, fn ($q) => $q->whereDate('loss_date', '>=', $request->date_from))
            ->when($request->date_to, fn ($q) => $q->whereDate('loss_date', '<=', $request->date_to))
            ->orderByDesc('loss_date')
            ->paginate($request->per_page ?? 20);

        return response()->json(['success' => true, 'data' => $losses]);
    }

    public function store(Request $request): JsonResponse
    {
        $data = $request->validate([
            'product_id' => 'required|exists:products,id',
            'type'       => 'required|in:damaged,missing,expired,theft',
            'quantity'   => 'required|integer|min:1',
            'reason'     => 'nullable|string|max:500',
            'loss_date'  => 'required|date',
        ]);

        $product = Product::findOrFail($data['product_id']);

        DB::beginTransaction();
        try {
            $loss = Loss::create(array_merge($data, [
                'branch_id'  => $request->user()->branch_id,
                'user_id'    => $request->user()->id,
                'unit_cost'  => $product->cost_price,
                'total_loss' => $product->cost_price * $data['quantity'],
                'status'     => 'pending',
            ]));

            // Deduct stock immediately on report
            if ($product->track_inventory) {
                $product->decrement('stock_quantity', $data['quantity']);
            }

            DB::commit();
            activity_log('loss_reported', $request->user()->id, "Loss reported for {$product->name}: {$data['quantity']} {$data['type']}");

            return response()->json(['success' => true, 'data' => $loss->load('product')], 201);
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json(['success' => false, 'message' => $e->getMessage()], 500);
        }
    }

    public function show(Loss $loss): JsonResponse
    {
        return response()->json([
            'success' => true,
            'data'    => $loss->load(['product', 'user:id,name', 'approvedBy:id,name']),
        ]);
    }

    public function approve(Request $request, Loss $loss): JsonResponse
    {
        $loss->update([
            'status'      => 'approved',
            'approved_by' => $request->user()->id,
            'approved_at' => now(),
        ]);

        return response()->json(['success' => true, 'message' => 'Loss approved.']);
    }
}
