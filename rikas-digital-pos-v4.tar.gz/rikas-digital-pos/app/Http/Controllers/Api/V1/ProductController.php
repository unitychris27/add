<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Models\Product;
use App\Services\InventoryService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class ProductController extends Controller
{
    public function __construct(private InventoryService $inventoryService) {}

    public function index(Request $request): JsonResponse
    {
        $products = Product::with(['category:id,name', 'brand:id,name'])
            ->when($request->search, fn ($q) => $q->where(function ($q) use ($request) {
                $q->where('name', 'like', "%{$request->search}%")
                  ->orWhere('barcode', $request->search)
                  ->orWhere('sku', 'like', "%{$request->search}%");
            }))
            ->when($request->category_id, fn ($q) => $q->where('category_id', $request->category_id))
            ->when($request->is_active !== null, fn ($q) => $q->where('is_active', $request->boolean('is_active')))
            ->when($request->low_stock, fn ($q) => $q->lowStock())
            ->orderBy($request->sort_by ?? 'name', $request->sort_dir ?? 'asc')
            ->paginate($request->per_page ?? 20);

        return response()->json(['success' => true, 'data' => $products]);
    }

    public function store(Request $request): JsonResponse
    {
        $data = $request->validate([
            'name'             => 'required|string|max:255',
            'category_id'      => 'nullable|exists:categories,id',
            'brand_id'         => 'nullable|exists:brands,id',
            'supplier_id'      => 'nullable|exists:suppliers,id',
            'barcode'          => 'nullable|string|unique:products',
            'sku'              => 'nullable|string|unique:products',
            'description'      => 'nullable|string',
            'unit'             => 'required|string|max:20',
            'cost_price'       => 'required|numeric|min:0',
            'selling_price'    => 'required|numeric|min:0',
            'wholesale_price'  => 'nullable|numeric|min:0',
            'tax_rate'         => 'nullable|numeric|min:0|max:100',
            'tax_inclusive'    => 'boolean',
            'stock_quantity'   => 'required|integer|min:0',
            'alert_quantity'   => 'required|integer|min:0',
            'track_inventory'  => 'boolean',
            'is_active'        => 'boolean',
            'is_featured'      => 'boolean',
        ]);

        $data['slug'] = Str::slug($data['name']) . '-' . Str::random(6);

        $product = Product::create($data);

        activity_log('product_created', auth()->id(), "Created product: {$product->name}");

        return response()->json(['success' => true, 'data' => $product->load(['category', 'brand'])], 201);
    }

    public function show(Product $product): JsonResponse
    {
        return response()->json([
            'success' => true,
            'data'    => $product->load(['category', 'brand', 'supplier']),
        ]);
    }

    public function update(Request $request, Product $product): JsonResponse
    {
        $data = $request->validate([
            'name'            => 'sometimes|string|max:255',
            'category_id'     => 'nullable|exists:categories,id',
            'brand_id'        => 'nullable|exists:brands,id',
            'supplier_id'     => 'nullable|exists:suppliers,id',
            'barcode'         => 'nullable|string|unique:products,barcode,' . $product->id,
            'sku'             => 'nullable|string|unique:products,sku,' . $product->id,
            'description'     => 'nullable|string',
            'unit'            => 'sometimes|string|max:20',
            'cost_price'      => 'sometimes|numeric|min:0',
            'selling_price'   => 'sometimes|numeric|min:0',
            'wholesale_price' => 'nullable|numeric|min:0',
            'tax_rate'        => 'nullable|numeric|min:0|max:100',
            'tax_inclusive'   => 'boolean',
            'stock_quantity'  => 'sometimes|integer|min:0',
            'alert_quantity'  => 'sometimes|integer|min:0',
            'track_inventory' => 'boolean',
            'is_active'       => 'boolean',
            'is_featured'     => 'boolean',
        ]);

        $product->update($data);
        activity_log('product_updated', auth()->id(), "Updated product: {$product->name}");

        return response()->json(['success' => true, 'data' => $product->fresh(['category', 'brand'])]);
    }

    public function destroy(Product $product): JsonResponse
    {
        $product->delete();
        activity_log('product_deleted', auth()->id(), "Deleted product: {$product->name}");
        return response()->json(['success' => true, 'message' => 'Product deleted.']);
    }

    public function lowStock(Request $request): JsonResponse
    {
        $products = Product::with(['category:id,name'])
            ->lowStock()
            ->active()
            ->paginate($request->per_page ?? 20);

        return response()->json(['success' => true, 'data' => $products]);
    }

    public function scanBarcode(Request $request): JsonResponse
    {
        $request->validate(['barcode' => 'required|string']);

        $product = Product::where('barcode', $request->barcode)
            ->where('is_active', true)
            ->with(['category:id,name'])
            ->first();

        if (!$product) {
            return response()->json(['success' => false, 'message' => 'Product not found.'], 404);
        }

        return response()->json(['success' => true, 'data' => $product]);
    }
}
