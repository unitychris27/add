<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Models\Setting;
use App\Services\PaymentService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class CurrencyController extends Controller
{
    /**
     * Get current currency settings and exchange rates
     */
    public function index(): JsonResponse
    {
        $currency = Setting::get('currency', 'KES');

        return response()->json([
            'success' => true,
            'data'    => [
                'active_currency' => $currency,
                'symbol'          => PaymentService::currencySymbol($currency),
                'currencies'      => [
                    [
                        'code'    => 'KES',
                        'name'    => 'Kenyan Shilling',
                        'symbol'  => 'KSh',
                        'flag'    => '🇰🇪',
                        'rate'    => (float) Setting::get('rate_kes', 130),
                        'country' => 'Kenya',
                    ],
                    [
                        'code'    => 'CDF',
                        'name'    => 'Congolese Franc',
                        'symbol'  => 'FC',
                        'flag'    => '🇨🇩',
                        'rate'    => (float) Setting::get('rate_cdf', 2350),
                        'country' => 'DR Congo',
                    ],
                    [
                        'code'    => 'USD',
                        'name'    => 'US Dollar',
                        'symbol'  => '$',
                        'flag'    => '🇺🇸',
                        'rate'    => 1.0,
                        'country' => 'International',
                    ],
                ],
            ],
        ]);
    }

    /**
     * Switch the store's active currency
     * Admin or manager can do this
     */
    public function switch(Request $request): JsonResponse
    {
        $request->validate([
            'currency' => 'required|in:KES,CDF,USD',
        ]);

        Setting::set('currency', $request->currency);
        Setting::set('currency_symbol', PaymentService::currencySymbol($request->currency));

        activity_log('currency_changed', $request->user()->id, "Currency changed to {$request->currency}");

        return response()->json([
            'success'  => true,
            'message'  => 'Currency switched to ' . $request->currency,
            'currency' => $request->currency,
            'symbol'   => PaymentService::currencySymbol($request->currency),
        ]);
    }

    /**
     * Update exchange rates
     */
    public function updateRates(Request $request): JsonResponse
    {
        $request->validate([
            'rate_kes' => 'required|numeric|min:1',
            'rate_cdf' => 'required|numeric|min:1',
        ]);

        Setting::set('rate_kes', $request->rate_kes);
        Setting::set('rate_cdf', $request->rate_cdf);
        Setting::set('rate_usd', 1);

        return response()->json([
            'success' => true,
            'message' => 'Exchange rates updated.',
            'rates'   => [
                'USD' => 1,
                'KES' => $request->rate_kes,
                'CDF' => $request->rate_cdf,
            ],
        ]);
    }

    /**
     * Convert an amount between currencies
     */
    public function convert(Request $request): JsonResponse
    {
        $request->validate([
            'amount' => 'required|numeric|min:0',
            'from'   => 'required|in:KES,CDF,USD',
            'to'     => 'required|in:KES,CDF,USD',
        ]);

        $converted = PaymentService::convertCurrency(
            $request->amount,
            $request->from,
            $request->to
        );

        return response()->json([
            'success'   => true,
            'from'      => $request->from,
            'to'        => $request->to,
            'original'  => $request->amount,
            'converted' => $converted,
            'formatted' => PaymentService::formatAmount($converted, $request->to),
        ]);
    }
}
