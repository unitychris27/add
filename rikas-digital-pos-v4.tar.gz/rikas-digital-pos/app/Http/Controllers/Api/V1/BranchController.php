<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Models\Branch;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class BranchController extends Controller
{
    public function index(): JsonResponse
    {
        $branches = Branch::withCount(['users', 'sales'])->orderBy('name')->get();
        return response()->json(['success' => true, 'data' => $branches]);
    }

    public function store(Request $request): JsonResponse
    {
        $data = $request->validate([
            'name'         => 'required|string|max:255',
            'code'         => 'required|string|max:20|unique:branches',
            'address'      => 'nullable|string',
            'phone'        => 'nullable|string|max:20',
            'email'        => 'nullable|email',
            'manager_name' => 'nullable|string|max:255',
            'is_active'    => 'boolean',
        ]);

        $branch = Branch::create($data);
        return response()->json(['success' => true, 'data' => $branch], 201);
    }

    public function show(Branch $branch): JsonResponse
    {
        return response()->json([
            'success' => true,
            'data'    => $branch->loadCount(['users', 'sales']),
        ]);
    }

    public function update(Request $request, Branch $branch): JsonResponse
    {
        $data = $request->validate([
            'name'         => 'sometimes|string|max:255',
            'code'         => 'sometimes|string|max:20|unique:branches,code,' . $branch->id,
            'address'      => 'nullable|string',
            'phone'        => 'nullable|string|max:20',
            'email'        => 'nullable|email',
            'manager_name' => 'nullable|string|max:255',
            'is_active'    => 'boolean',
        ]);

        $branch->update($data);
        return response()->json(['success' => true, 'data' => $branch->fresh()]);
    }

    public function destroy(Branch $branch): JsonResponse
    {
        if ($branch->users()->count() > 0) {
            return response()->json(['success' => false, 'message' => 'Cannot delete branch with users.'], 422);
        }
        $branch->delete();
        return response()->json(['success' => true, 'message' => 'Branch deleted.']);
    }
}
