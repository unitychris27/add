<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Models\Branch;
use App\Models\Category;
use App\Models\Product;
use App\Models\Setting;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class SettingController extends Controller
{
    public function index(): JsonResponse
    {
        $settings = Setting::orderBy('group')->get()
            ->groupBy('group')
            ->map(fn ($group) => $group->pluck('value', 'key'));

        return response()->json(['success' => true, 'data' => $settings]);
    }

    public function update(Request $request): JsonResponse
    {
        $this->authorize('manage-settings');

        $data = $request->validate([
            'settings'   => 'required|array',
            'settings.*' => 'nullable',
        ]);

        foreach ($data['settings'] as $key => $value) {
            Setting::set($key, $value);
        }

        return response()->json(['success' => true, 'message' => 'Settings updated.']);
    }

    public function pullData(Request $request): JsonResponse
    {
        // Endpoint for Flutter app to pull latest reference data
        $since = $request->since ? \Carbon\Carbon::parse($request->since) : null;

        $products = Product::active()
            ->when($since, fn ($q) => $q->where('updated_at', '>', $since))
            ->with(['category:id,name', 'brand:id,name'])
            ->get(['id', 'name', 'sku', 'barcode', 'selling_price', 'wholesale_price',
                   'cost_price', 'stock_quantity', 'unit', 'category_id', 'updated_at']);

        $categories = Category::where('is_active', true)
            ->when($since, fn ($q) => $q->where('updated_at', '>', $since))
            ->get(['id', 'name', 'updated_at']);

        $settings = Setting::where('group', 'business')->pluck('value', 'key');

        return response()->json([
            'success' => true,
            'data'    => [
                'products'    => $products,
                'categories'  => $categories,
                'settings'    => $settings,
                'pulled_at'   => now()->toISOString(),
            ],
        ]);
    }
}
