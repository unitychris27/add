<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Models\Sale;
use App\Services\SaleService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class SaleController extends Controller
{
    public function __construct(private SaleService $saleService) {}

    public function index(Request $request): JsonResponse
    {
        $user = $request->user();

        $sales = Sale::with(['user:id,name', 'customer:id,name,phone', 'items'])
            ->when(!$user->hasRole('super_admin'), fn ($q) => $q->where('branch_id', $user->branch_id))
            ->when($user->hasRole('associate'), fn ($q) => $q->where('user_id', $user->id))
            ->when($request->status, fn ($q) => $q->where('status', $request->status))
            ->when($request->date_from, fn ($q) => $q->whereDate('created_at', '>=', $request->date_from))
            ->when($request->date_to, fn ($q) => $q->whereDate('created_at', '<=', $request->date_to))
            ->when($request->search, fn ($q) => $q->where('invoice_number', 'like', "%{$request->search}%"))
            ->orderByDesc('created_at')
            ->paginate($request->per_page ?? 20);

        return response()->json(['success' => true, 'data' => $sales]);
    }

    public function store(Request $request): JsonResponse
    {
        $data = $request->validate([
            'uuid'             => 'required|uuid',
            'customer_id'      => 'nullable|exists:customers,id',
            'items'            => 'required|array|min:1',
            'items.*.product_id' => 'required|exists:products,id',
            'items.*.quantity'   => 'required|integer|min:1',
            'items.*.unit_price' => 'required|numeric|min:0',
            'items.*.discount_amount' => 'nullable|numeric|min:0',
            'discount_amount'  => 'nullable|numeric|min:0',
            'discount_type'    => 'nullable|in:fixed,percentage',
            'payment_method'   => 'required|in:cash,mpesa,card,bank_transfer,mixed',
            'paid_amount'      => 'required|numeric|min:0',
            'notes'            => 'nullable|string',
            'payments'         => 'sometimes|array',
            'payments.*.method' => 'required|in:cash,mpesa,card,bank_transfer',
            'payments.*.amount' => 'required|numeric|min:0',
            'payments.*.reference' => 'nullable|string',
        ]);

        // Idempotency — return existing if already synced
        $existing = Sale::where('uuid', $data['uuid'])->first();
        if ($existing) {
            return response()->json([
                'success'  => true,
                'data'     => $existing->load(['items', 'payments']),
                'message'  => 'Sale already processed.',
            ]);
        }

        $sale = $this->saleService->create($data, $request->user());

        return response()->json(['success' => true, 'data' => $sale->load(['items', 'payments', 'customer'])], 201);
    }

    public function show(Sale $sale): JsonResponse
    {
        $this->authorize('view', $sale);
        return response()->json([
            'success' => true,
            'data'    => $sale->load(['items.product', 'payments', 'customer', 'user:id,name']),
        ]);
    }

    public function bulkSync(Request $request): JsonResponse
    {
        $request->validate([
            'sales'   => 'required|array|max:100',
            'sales.*' => 'array',
        ]);

        $results = $this->saleService->bulkSync($request->sales, $request->user());

        return response()->json([
            'success'   => true,
            'synced'    => $results['synced'],
            'skipped'   => $results['skipped'],
            'failed'    => $results['failed'],
        ]);
    }

    public function refund(Request $request, Sale $sale): JsonResponse
    {
        $request->validate([
            'reason' => 'required|string|max:500',
            'items'  => 'sometimes|array',
        ]);

        $refundedSale = $this->saleService->refund($sale, $request->all(), $request->user());

        return response()->json(['success' => true, 'data' => $refundedSale]);
    }

    public function receipt(Sale $sale): JsonResponse
    {
        return response()->json([
            'success' => true,
            'data'    => $this->saleService->generateReceiptData($sale),
        ]);
    }
}
