<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Models\Supplier;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class SupplierController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $suppliers = Supplier::when($request->search, fn ($q) => $q->where(function ($q) use ($request) {
                $q->where('name', 'like', "%{$request->search}%")
                  ->orWhere('phone', 'like', "%{$request->search}%");
            }))
            ->withCount('products')
            ->orderBy('name')
            ->paginate($request->per_page ?? 20);

        return response()->json(['success' => true, 'data' => $suppliers]);
    }

    public function store(Request $request): JsonResponse
    {
        $data = $request->validate([
            'name'            => 'required|string|max:255',
            'company'         => 'nullable|string|max:255',
            'email'           => 'nullable|email',
            'phone'           => 'required|string|max:20',
            'phone_alt'       => 'nullable|string|max:20',
            'address'         => 'nullable|string',
            'city'            => 'nullable|string|max:100',
            'country'         => 'nullable|string|max:100',
            'tax_number'      => 'nullable|string|max:50',
            'opening_balance' => 'nullable|numeric|min:0',
        ]);

        $supplier = Supplier::create($data);
        return response()->json(['success' => true, 'data' => $supplier], 201);
    }

    public function show(Supplier $supplier): JsonResponse
    {
        return response()->json([
            'success' => true,
            'data'    => $supplier->load(['products:id,name,sku,stock_quantity', 'purchases' => fn ($q) => $q->latest()->limit(10)]),
        ]);
    }

    public function update(Request $request, Supplier $supplier): JsonResponse
    {
        $data = $request->validate([
            'name'       => 'sometimes|string|max:255',
            'company'    => 'nullable|string|max:255',
            'email'      => 'nullable|email',
            'phone'      => 'sometimes|string|max:20',
            'address'    => 'nullable|string',
            'city'       => 'nullable|string|max:100',
            'is_active'  => 'boolean',
        ]);

        $supplier->update($data);
        return response()->json(['success' => true, 'data' => $supplier->fresh()]);
    }

    public function destroy(Supplier $supplier): JsonResponse
    {
        $supplier->delete();
        return response()->json(['success' => true, 'message' => 'Supplier deleted.']);
    }
}
