<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Models\Payment;
use App\Models\Sale;
use App\Models\Setting;
use App\Services\PaymentService;
use App\Services\SaleService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class PaymentController extends Controller
{
    public function __construct(
        private PaymentService $paymentService,
        private SaleService $saleService
    ) {}

    /**
     * Step 1: Cashier enters customer phone → send STK push
     */
    public function initiateSTKPush(Request $request): JsonResponse
    {
        $request->validate([
            'phone'       => 'required|string|min:10',
            'amount'      => 'required|numeric|min:1',
            'currency'    => 'required|in:KES,CDF,USD',
            'invoice_no'  => 'required|string',
            'description' => 'nullable|string',
        ]);

        $user = $request->user();

        try {
            $result = $this->paymentService->initiateSTKPush(
                phone:       $request->phone,
                amount:      $request->amount,
                currency:    $request->currency,
                description: $request->description ?? "Payment for {$request->invoice_no}",
                branchId:    $user->branch_id,
                invoiceNo:   $request->invoice_no
            );

            return response()->json([
                'success'   => true,
                'reference' => $result['reference'],
                'message'   => $result['message'] ?? 'STK push sent. Ask customer to check their phone.',
                'amount'    => $result['amount'],
                'fee'       => $result['fee'] ?? 0,
                'currency'  => $request->currency,
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => $e->getMessage(),
            ], 422);
        }
    }

    /**
     * Step 2: POS app polls this every 3 seconds to check if customer paid
     */
    public function checkStatus(Request $request, string $reference): JsonResponse
    {
        $user = $request->user();

        try {
            $status = $this->paymentService->checkStatus($reference, $user->branch_id);

            return response()->json([
                'success'   => true,
                'reference' => $reference,
                'status'    => $status['status'],         // pending / processing / completed / failed
                'amount'    => $status['amount'] ?? null,
                'currency'  => $status['currency'] ?? null,
                'paid'      => $status['status'] === 'completed',
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => $e->getMessage(),
            ], 422);
        }
    }

    /**
     * Webhook — Xdigitex Pay calls this automatically when payment completes/fails.
     * Updates the payment record in our database.
     */
    public function webhook(Request $request): JsonResponse
    {
        $data = $request->all();

        $reference = $data['reference'] ?? null;
        $event     = $data['event'] ?? null;
        $status    = $data['status'] ?? null;

        if (!$reference) {
            return response()->json(['received' => true]);
        }

        // Find the payment record by reference and update it
        $payment = Payment::where('reference', $reference)->first();
        if ($payment) {
            $payment->update([
                'status'   => $status === 'completed' ? 'success' : 'failed',
                'metadata' => $data,
                'paid_at'  => $status === 'completed' ? now() : null,
            ]);
        }

        activity_log('payment_webhook', null, "Webhook received: {$event} for {$reference} — {$status}");

        return response()->json(['received' => true]);
    }

    /**
     * Callback URL — browser redirect after card payment (not used for mobile money)
     */
    public function callback(Request $request): JsonResponse
    {
        return response()->json([
            'success' => true,
            'message' => 'Payment callback received.',
            'invoice' => $request->invoice,
        ]);
    }

    /**
     * Get wallet balance for this store
     */
    public function balance(Request $request): JsonResponse
    {
        try {
            $balance = $this->paymentService->getBalance($request->user()->branch_id);
            return response()->json(['success' => true, 'data' => $balance]);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()], 422);
        }
    }

    /**
     * Save the Xdigitex Pay API key for this branch/store
     * Called by admin when setting up a new store
     */
    public function saveApiKey(Request $request): JsonResponse
    {
        $request->validate([
            'api_key' => 'required|string|starts_with:pg_',
        ]);

        $user = $request->user();
        $key  = "xdigitex_api_key_branch_{$user->branch_id}";

        Setting::set($key, $request->api_key);

        activity_log('api_key_saved', $user->id, "Xdigitex Pay API key saved for branch {$user->branch_id}");

        return response()->json(['success' => true, 'message' => 'Payment API key saved successfully.']);
    }

    /**
     * Test the API key connection
     */
    public function testConnection(Request $request): JsonResponse
    {
        try {
            $balance = $this->paymentService->getBalance($request->user()->branch_id);
            return response()->json([
                'success' => true,
                'message' => 'Connection successful!',
                'balance' => $balance,
            ]);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()], 422);
        }
    }
}
