<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Models\Customer;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class CustomerController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $customers = Customer::when($request->search, fn ($q) => $q->where(function ($q) use ($request) {
                $q->where('name', 'like', "%{$request->search}%")
                  ->orWhere('phone', 'like', "%{$request->search}%")
                  ->orWhere('email', 'like', "%{$request->search}%");
            }))
            ->when($request->customer_group, fn ($q) => $q->where('customer_group', $request->customer_group))
            ->orderBy('name')
            ->paginate($request->per_page ?? 20);

        return response()->json(['success' => true, 'data' => $customers]);
    }

    public function store(Request $request): JsonResponse
    {
        $data = $request->validate([
            'name'           => 'required|string|max:255',
            'email'          => 'nullable|email|unique:customers',
            'phone'          => 'nullable|string|max:20',
            'address'        => 'nullable|string',
            'city'           => 'nullable|string|max:100',
            'id_number'      => 'nullable|string|max:50',
            'customer_group' => 'nullable|in:regular,vip,wholesale',
            'credit_limit'   => 'nullable|numeric|min:0',
        ]);

        $customer = Customer::create(array_merge($data, [
            'branch_id' => $request->user()->branch_id,
        ]));

        return response()->json(['success' => true, 'data' => $customer], 201);
    }

    public function show(Customer $customer): JsonResponse
    {
        return response()->json([
            'success' => true,
            'data'    => $customer->load(['sales' => fn ($q) => $q->latest()->limit(10)]),
        ]);
    }

    public function update(Request $request, Customer $customer): JsonResponse
    {
        $data = $request->validate([
            'name'           => 'sometimes|string|max:255',
            'email'          => 'nullable|email|unique:customers,email,' . $customer->id,
            'phone'          => 'nullable|string|max:20',
            'address'        => 'nullable|string',
            'city'           => 'nullable|string|max:100',
            'customer_group' => 'nullable|in:regular,vip,wholesale',
            'credit_limit'   => 'nullable|numeric|min:0',
        ]);

        $customer->update($data);
        return response()->json(['success' => true, 'data' => $customer->fresh()]);
    }

    public function destroy(Customer $customer): JsonResponse
    {
        $customer->delete();
        return response()->json(['success' => true, 'message' => 'Customer deleted.']);
    }
}
