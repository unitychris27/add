<?php

namespace App\Livewire;

use App\Models\Product;
use App\Models\Sale;
use App\Models\SaleItem;
use App\Models\Setting;
use App\Services\PaymentService;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Livewire\Component;

class POSTerminal extends Component
{
    public string $search        = '';
    public array  $searchResults = [];
    public array  $cart          = [];

    public float  $subtotal       = 0;
    public float  $taxRate        = 16;
    public float  $taxAmount      = 0;
    public float  $discountAmount = 0;
    public float  $total          = 0;

    public string $paymentMethod  = 'cash';
    public float  $cashReceived   = 0;
    public float  $change         = 0;
    public string $customerPhone  = '';
    public string $customerName   = '';
    public string $stkReference   = '';
    public string $paymentStatus  = '';
    public string $paymentMessage = '';
    public bool   $showPayment    = false;
    public bool   $paymentDone    = false;
    public bool   $showReceipt    = false;
    public array  $receiptData    = [];

    public string $currency = 'KES';
    public string $symbol   = 'KSh';

    public function mount(): void
    {
        $this->currency = Setting::get('currency', 'KES');
        $this->symbol   = PaymentService::currencySymbol($this->currency);
        $this->taxRate  = (float) Setting::get('tax_rate', 16);
    }

    public function updatedSearch(): void
    {
        if (strlen($this->search) < 1) { $this->searchResults = []; return; }

        $q = Product::where(function ($q) {
            $q->where('name', 'like', '%'.$this->search.'%')
              ->orWhere('barcode', $this->search)
              ->orWhere('sku', 'like', '%'.$this->search.'%');
        })->where('is_active', true)->limit(12);

        if (Auth::user()->branch_id) $q->where('branch_id', Auth::user()->branch_id);

        $this->searchResults = $q->get(['id','name','selling_price','stock_quantity','barcode','unit'])->toArray();

        // Exact barcode → auto-add
        if (count($this->searchResults) === 1 && $this->search === ($this->searchResults[0]['barcode'] ?? null)) {
            $this->addToCart($this->searchResults[0]['id']);
        }
    }

    public function addToCart(int $productId): void
    {
        $p = Product::find($productId);
        if (!$p) return;
        $key = 'p_'.$productId;
        if (isset($this->cart[$key])) {
            if ($this->cart[$key]['qty'] < $p->stock_quantity) {
                $this->cart[$key]['qty']++;
                $this->cart[$key]['subtotal'] = round($this->cart[$key]['qty'] * $this->cart[$key]['price'], 2);
            }
        } else {
            $this->cart[$key] = ['id' => $p->id, 'name' => $p->name, 'price' => (float)$p->selling_price,
                'qty' => 1, 'subtotal' => (float)$p->selling_price, 'unit' => $p->unit ?? 'pcs', 'stock' => $p->stock_quantity];
        }
        $this->search = ''; $this->searchResults = [];
        $this->calculateTotals();
    }

    public function removeFromCart(string $key): void { unset($this->cart[$key]); $this->calculateTotals(); }

    public function increaseQty(string $key): void
    {
        if (isset($this->cart[$key]) && $this->cart[$key]['qty'] < $this->cart[$key]['stock']) {
            $this->cart[$key]['qty']++;
            $this->cart[$key]['subtotal'] = round($this->cart[$key]['qty'] * $this->cart[$key]['price'], 2);
            $this->calculateTotals();
        }
    }

    public function decreaseQty(string $key): void
    {
        if (!isset($this->cart[$key])) return;
        if ($this->cart[$key]['qty'] <= 1) { $this->removeFromCart($key); return; }
        $this->cart[$key]['qty']--;
        $this->cart[$key]['subtotal'] = round($this->cart[$key]['qty'] * $this->cart[$key]['price'], 2);
        $this->calculateTotals();
    }

    public function calculateTotals(): void
    {
        $this->subtotal  = round(collect($this->cart)->sum('subtotal'), 2);
        $this->taxAmount = round($this->subtotal * ($this->taxRate / 100), 2);
        $this->total     = round($this->subtotal + $this->taxAmount - $this->discountAmount, 2);
    }

    public function openPayment(): void
    {
        if (empty($this->cart)) return;
        $this->showPayment    = true;
        $this->paymentStatus  = '';
        $this->paymentMessage = '';
        $this->cashReceived   = $this->total;
        $this->change         = 0;
    }

    public function updatedCashReceived(): void
    {
        $this->change = max(0, round($this->cashReceived - $this->total, 2));
    }

    public function processCash(): void
    {
        if ($this->cashReceived < $this->total) { $this->paymentMessage = 'Cash received is less than total.'; return; }
        $this->change = round($this->cashReceived - $this->total, 2);
        $this->completeSale('cash');
    }

    public function sendSTKPush(): void
    {
        if (empty(trim($this->customerPhone))) { $this->paymentMessage = 'Enter the customer phone number.'; return; }
        $this->paymentStatus = 'processing'; $this->paymentMessage = 'Sending STK push...';
        try {
            $svc  = app(PaymentService::class);
            $inv  = Sale::generateInvoiceNumber(Auth::user()->branch_id ?? 1);
            $res  = $svc->initiateSTKPush(
                phone:       $this->formatPhone($this->customerPhone),
                amount:      $this->total,
                currency:    $this->currency,
                description: 'Purchase at '.(Auth::user()->branch->name ?? 'RIKAS POS'),
                branchId:    Auth::user()->branch_id,
                invoiceNo:   $inv
            );
            $this->stkReference  = $res['reference'];
            $this->paymentStatus = 'pending';
            $this->paymentMessage= $res['message'] ?? 'STK sent! Customer should check phone and enter PIN.';
        } catch (\Exception $e) {
            $this->paymentStatus  = 'failed';
            $this->paymentMessage = $e->getMessage();
        }
    }

    public function pollPaymentStatus(): void
    {
        if (empty($this->stkReference) || in_array($this->paymentStatus, ['completed','failed',''])) return;
        try {
            $status = app(PaymentService::class)->checkStatus($this->stkReference, Auth::user()->branch_id);
            if ($status['status'] === 'completed') {
                $this->paymentStatus = 'completed';
                $this->paymentMessage = 'Payment confirmed! ✓';
                $this->completeSale('mobile_money', $this->stkReference);
            } elseif ($status['status'] === 'failed') {
                $this->paymentStatus = 'failed';
                $this->paymentMessage = 'Payment failed or cancelled.';
            }
        } catch (\Exception) {}
    }

    private function completeSale(string $method, ?string $reference = null): void
    {
        DB::transaction(function () use ($method, $reference) {
            $user   = Auth::user();
            $branch = $user->branch;

            $sale = Sale::create([
                'branch_id'         => $user->branch_id,
                'user_id'           => $user->id,
                'customer_id'       => null,
                'subtotal'          => $this->subtotal,
                'tax_amount'        => $this->taxAmount,
                'discount_amount'   => $this->discountAmount,
                'total_amount'      => $this->total,
                'paid_amount'       => $this->cashReceived ?: $this->total,
                'change_amount'     => $this->change,
                'payment_method'    => $method,
                'payment_status'    => 'paid',
                'status'            => 'completed',
                'notes'             => $reference ? "Ref: {$reference}" : null,
            ]);

            foreach ($this->cart as $item) {
                SaleItem::create([
                    'sale_id'    => $sale->id,
                    'product_id' => $item['id'],
                    'quantity'   => $item['qty'],
                    'unit_price' => $item['price'],
                    'subtotal'   => $item['subtotal'],
                ]);
                Product::where('id', $item['id'])->decrement('stock_quantity', $item['qty']);
            }

            $this->receiptData = [
                'invoice_no'     => $sale->invoice_number,
                'cashier'        => $user->name,
                'branch'         => $branch->name ?? 'RIKAS DIGITAL POS',
                'branch_address' => $branch->address ?? '',
                'date'           => now()->format('d/m/Y H:i'),
                'items'          => array_values($this->cart),
                'subtotal'       => $this->subtotal,
                'tax_rate'       => $this->taxRate,
                'tax_amount'     => $this->taxAmount,
                'discount'       => $this->discountAmount,
                'total'          => $this->total,
                'payment_method' => $method,
                'reference'      => $reference,
                'cash_received'  => $this->cashReceived,
                'change'         => $this->change,
                'symbol'         => $this->symbol,
                'customer'       => $this->customerName ?: 'Walk-in Customer',
                'phone'          => $this->customerPhone,
            ];
        });

        $this->showPayment = false;
        $this->showReceipt = true;
        $this->paymentDone = true;
    }

    private function formatPhone(string $p): string
    {
        $p = preg_replace('/[^0-9+]/', '', $p);
        if (preg_match('/^07\d{8}$/', $p))  return '+254'.substr($p, 1);
        if (preg_match('/^7\d{8}$/', $p))   return '+254'.$p;
        if (preg_match('/^08\d{8}$/', $p))  return '+243'.substr($p, 1);
        if (str_starts_with($p, '+'))        return $p;
        return '+'.$p;
    }

    public function newSale(): void
    {
        $this->cart = []; $this->subtotal = 0; $this->taxAmount = 0;
        $this->total = 0; $this->discountAmount = 0; $this->customerPhone = '';
        $this->customerName = ''; $this->stkReference = ''; $this->paymentStatus = '';
        $this->paymentMessage = ''; $this->showReceipt = false; $this->showPayment = false;
        $this->paymentDone = false; $this->cashReceived = 0; $this->change = 0;
    }

    public function render(): \Illuminate\View\View
    {
        return view('livewire.pos-terminal');
    }
}
