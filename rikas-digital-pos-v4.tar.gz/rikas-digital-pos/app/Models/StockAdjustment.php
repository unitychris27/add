<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class StockAdjustment extends Model
{
    protected $fillable = [
        'branch_id', 'product_id', 'user_id',
        'type', 'quantity', 'quantity_before', 'quantity_after', 'reason',
    ];

    public function branch()  { return $this->belongsTo(Branch::class); }
    public function product() { return $this->belongsTo(Product::class); }
    public function user()    { return $this->belongsTo(User::class); }
}
