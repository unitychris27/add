<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Customer extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'branch_id', 'name', 'email', 'phone', 'address',
        'city', 'id_number', 'loyalty_points', 'credit_limit',
        'outstanding_balance', 'customer_group', 'is_active',
    ];

    protected $casts = [
        'is_active'           => 'boolean',
        'loyalty_points'      => 'decimal:2',
        'credit_limit'        => 'decimal:2',
        'outstanding_balance' => 'decimal:2',
    ];

    public function branch()
    {
        return $this->belongsTo(Branch::class);
    }

    public function sales()
    {
        return $this->hasMany(Sale::class);
    }
}
