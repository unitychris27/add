<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Payment extends Model
{
    protected $fillable = [
        'sale_id', 'method', 'amount', 'reference', 'status', 'metadata', 'paid_at',
    ];

    protected $casts = [
        'amount'   => 'decimal:2',
        'metadata' => 'array',
        'paid_at'  => 'datetime',
    ];

    public function sale()
    {
        return $this->belongsTo(Sale::class);
    }
}
