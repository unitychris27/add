<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Loss extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'branch_id', 'user_id', 'product_id', 'approved_by', 'type',
        'quantity', 'unit_cost', 'total_loss', 'reason', 'attachment',
        'status', 'loss_date', 'approved_at',
    ];

    protected $casts = [
        'unit_cost'   => 'decimal:2',
        'total_loss'  => 'decimal:2',
        'loss_date'   => 'date',
        'approved_at' => 'datetime',
    ];

    public function branch()
    {
        return $this->belongsTo(Branch::class);
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function product()
    {
        return $this->belongsTo(Product::class);
    }

    public function approvedBy()
    {
        return $this->belongsTo(User::class, 'approved_by');
    }
}
