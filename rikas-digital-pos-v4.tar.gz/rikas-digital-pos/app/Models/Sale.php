<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Sale extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'uuid', 'branch_id', 'user_id', 'customer_id', 'invoice_number',
        'status', 'subtotal', 'tax_amount', 'discount_amount', 'discount_type',
        'total_amount', 'paid_amount', 'change_amount', 'payment_method',
        'payment_status', 'notes', 'is_synced', 'synced_at',
    ];

    protected $casts = [
        'subtotal'        => 'decimal:2',
        'tax_amount'      => 'decimal:2',
        'discount_amount' => 'decimal:2',
        'total_amount'    => 'decimal:2',
        'paid_amount'     => 'decimal:2',
        'change_amount'   => 'decimal:2',
        'is_synced'       => 'boolean',
        'synced_at'       => 'datetime',
    ];

    protected static function boot()
    {
        parent::boot();
        static::creating(function ($sale) {
            if (empty($sale->uuid)) {
                $sale->uuid = (string) \Illuminate\Support\Str::uuid();
            }
            if (empty($sale->invoice_number)) {
                $sale->invoice_number = self::generateInvoiceNumber($sale->branch_id);
            }
        });
    }

    public static function generateInvoiceNumber(int $branchId): string
    {
        $prefix = 'INV';
        $date   = now()->format('Ymd');
        $last   = self::where('branch_id', $branchId)->whereDate('created_at', today())->count() + 1;
        return sprintf('%s-%s-%04d', $prefix, $date, $last);
    }

    public function branch()
    {
        return $this->belongsTo(Branch::class);
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function customer()
    {
        return $this->belongsTo(Customer::class);
    }

    public function items()
    {
        return $this->hasMany(SaleItem::class);
    }

    public function payments()
    {
        return $this->hasMany(Payment::class);
    }

    public function scopeToday($query)
    {
        return $query->whereDate('created_at', today());
    }

    public function scopeCompleted($query)
    {
        return $query->where('status', 'completed');
    }
}
