<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Purchase extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'branch_id', 'user_id', 'supplier_id', 'reference_number',
        'invoice_number', 'status', 'subtotal', 'tax_amount',
        'discount_amount', 'shipping_cost', 'total_amount', 'paid_amount',
        'payment_status', 'purchase_date', 'notes',
    ];

    protected $casts = [
        'subtotal'        => 'decimal:2',
        'tax_amount'      => 'decimal:2',
        'discount_amount' => 'decimal:2',
        'shipping_cost'   => 'decimal:2',
        'total_amount'    => 'decimal:2',
        'paid_amount'     => 'decimal:2',
        'purchase_date'   => 'date',
    ];

    protected static function boot()
    {
        parent::boot();
        static::creating(function ($purchase) {
            if (empty($purchase->reference_number)) {
                $purchase->reference_number = 'PO-' . now()->format('Ymd') . '-' . str_pad(
                    self::whereDate('created_at', today())->count() + 1, 4, '0', STR_PAD_LEFT
                );
            }
        });
    }

    public function branch()
    {
        return $this->belongsTo(Branch::class);
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function supplier()
    {
        return $this->belongsTo(Supplier::class);
    }

    public function items()
    {
        return $this->hasMany(PurchaseItem::class);
    }
}
