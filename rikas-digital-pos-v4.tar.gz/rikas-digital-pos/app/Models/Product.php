<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Product extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'category_id', 'brand_id', 'supplier_id', 'name', 'slug',
        'sku', 'barcode', 'description', 'image', 'images', 'unit',
        'cost_price', 'selling_price', 'wholesale_price', 'tax_rate',
        'tax_inclusive', 'stock_quantity', 'alert_quantity',
        'min_order_quantity', 'track_inventory', 'is_active', 'is_featured',
    ];

    protected $casts = [
        'images'          => 'array',
        'cost_price'      => 'decimal:2',
        'selling_price'   => 'decimal:2',
        'wholesale_price' => 'decimal:2',
        'tax_rate'        => 'decimal:2',
        'tax_inclusive'   => 'boolean',
        'track_inventory' => 'boolean',
        'is_active'       => 'boolean',
        'is_featured'     => 'boolean',
    ];

    public function category()
    {
        return $this->belongsTo(Category::class);
    }

    public function brand()
    {
        return $this->belongsTo(Brand::class);
    }

    public function supplier()
    {
        return $this->belongsTo(Supplier::class);
    }

    public function saleItems()
    {
        return $this->hasMany(SaleItem::class);
    }

    public function purchaseItems()
    {
        return $this->hasMany(PurchaseItem::class);
    }

    public function scopeActive($query)
    {
        return $query->where('is_active', true);
    }

    public function scopeLowStock($query)
    {
        return $query->whereColumn('stock_quantity', '<=', 'alert_quantity')
                     ->where('track_inventory', true);
    }

    public function isLowStock(): bool
    {
        return $this->track_inventory && $this->stock_quantity <= $this->alert_quantity;
    }
}
