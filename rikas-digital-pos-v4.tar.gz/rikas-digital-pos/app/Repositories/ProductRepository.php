<?php

namespace App\Repositories;

use App\Models\Product;
use App\Repositories\Contracts\ProductRepositoryInterface;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Illuminate\Support\Str;

class ProductRepository implements ProductRepositoryInterface
{
    public function all(array $filters = []): LengthAwarePaginator
    {
        return Product::with(['category:id,name', 'brand:id,name'])
            ->when($filters['search'] ?? null, fn ($q) => $q->where(function ($q) use ($filters) {
                $q->where('name', 'like', "%{$filters['search']}%")
                  ->orWhere('barcode', $filters['search'])
                  ->orWhere('sku', 'like', "%{$filters['search']}%");
            }))
            ->when($filters['category_id'] ?? null, fn ($q) => $q->where('category_id', $filters['category_id']))
            ->when(isset($filters['is_active']), fn ($q) => $q->where('is_active', $filters['is_active']))
            ->orderBy($filters['sort_by'] ?? 'name', $filters['sort_dir'] ?? 'asc')
            ->paginate($filters['per_page'] ?? 20);
    }

    public function findById(int $id): ?Product
    {
        return Product::with(['category', 'brand', 'supplier'])->find($id);
    }

    public function findByBarcode(string $barcode): ?Product
    {
        return Product::where('barcode', $barcode)->where('is_active', true)->first();
    }

    public function create(array $data): Product
    {
        $data['slug'] = Str::slug($data['name']) . '-' . Str::random(6);
        return Product::create($data);
    }

    public function update(Product $product, array $data): Product
    {
        $product->update($data);
        return $product->fresh(['category', 'brand']);
    }

    public function delete(Product $product): bool
    {
        return $product->delete();
    }

    public function getLowStock(): \Illuminate\Database\Eloquent\Collection
    {
        return Product::with(['category:id,name'])->lowStock()->active()->get();
    }
}
