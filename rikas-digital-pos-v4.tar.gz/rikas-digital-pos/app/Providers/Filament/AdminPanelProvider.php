<?php

namespace App\Providers\Filament;

use App\Filament\Pages\Dashboard;
use App\Filament\Pages\PaymentSettings;
use App\Filament\Pages\POSPage;
use App\Filament\Pages\ReportsPage;
use App\Filament\Pages\SettingsPage;
use App\Filament\Pages\WithdrawalPage;
use App\Filament\Resources\BranchResource;
use App\Filament\Resources\BrandResource;
use App\Filament\Resources\CategoryResource;
use App\Filament\Resources\CustomerResource;
use App\Filament\Resources\ExpenseCategoryResource;
use App\Filament\Resources\ExpenseResource;
use App\Filament\Resources\ProductResource;
use App\Filament\Resources\PurchaseResource;
use App\Filament\Resources\SaleResource;
use App\Filament\Resources\StockAdjustmentResource;
use App\Filament\Resources\StockTransferResource;
use App\Filament\Resources\SupplierResource;
use App\Filament\Resources\UserResource;
use App\Filament\Widgets\RecentSalesTable;
use App\Filament\Widgets\StatsOverview;
use App\Filament\Widgets\StockAlertWidget;
use Filament\Http\Middleware\Authenticate;
use Filament\Http\Middleware\AuthenticateSession;
use Filament\Http\Middleware\DisableBladeIconComponents;
use Filament\Http\Middleware\DispatchServingFilamentEvent;
use Filament\Navigation\NavigationGroup;
use Filament\Panel;
use Filament\PanelProvider;
use Filament\Support\Colors\Color;
use Filament\View\PanelsRenderHook;
use Illuminate\Cookie\Middleware\AddQueuedCookiesToResponse;
use Illuminate\Cookie\Middleware\EncryptCookies;
use Illuminate\Foundation\Http\Middleware\VerifyCsrfToken;
use Illuminate\Routing\Middleware\SubstituteBindings;
use Illuminate\Session\Middleware\StartSession;
use Illuminate\View\Middleware\ShareErrorsFromSession;

class AdminPanelProvider extends PanelProvider
{
    public function panel(Panel $panel): Panel
    {
        return $panel
            ->default()
            ->id('admin')
            ->path('admin')
            ->login()
            ->colors([
                'primary' => Color::hex('#d4af37'),
                'danger'  => Color::Red,
                'gray'    => Color::Zinc,
                'info'    => Color::Sky,
                'success' => Color::Emerald,
                'warning' => Color::Amber,
            ])
            ->brandName('RIKAS DIGITAL POS')
            ->darkMode(true)
            ->sidebarCollapsibleOnDesktop()
            ->navigationGroups([
                NavigationGroup::make('POS'),
                NavigationGroup::make('Contacts'),
                NavigationGroup::make('Inventory'),
                NavigationGroup::make('Finance'),
                NavigationGroup::make('Reports'),
                NavigationGroup::make('Administration')->collapsed(),
            ])
            ->resources([
                // POS & Sales
                SaleResource::class,
                // Contacts
                CustomerResource::class,
                SupplierResource::class,
                // Inventory
                ProductResource::class,
                CategoryResource::class,
                BrandResource::class,
                PurchaseResource::class,
                StockAdjustmentResource::class,
                StockTransferResource::class,
                // Finance
                ExpenseResource::class,
                ExpenseCategoryResource::class,
                // Administration
                UserResource::class,
                BranchResource::class,
            ])
            ->pages([
                Dashboard::class,
                POSPage::class,
                ReportsPage::class,
                WithdrawalPage::class,
                PaymentSettings::class,
                SettingsPage::class,
            ])
            ->widgets([
                StatsOverview::class,
                StockAlertWidget::class,
                RecentSalesTable::class,
            ])
            ->renderHook(
                PanelsRenderHook::TOPBAR_END,
                fn (): string => view('filament.components.language-switcher')->render(),
            )
            ->middleware([
                EncryptCookies::class,
                AddQueuedCookiesToResponse::class,
                StartSession::class,
                AuthenticateSession::class,
                ShareErrorsFromSession::class,
                VerifyCsrfToken::class,
                SubstituteBindings::class,
                DisableBladeIconComponents::class,
                DispatchServingFilamentEvent::class,
                \App\Http\Middleware\SetLocale::class,
            ])
            ->authMiddleware([Authenticate::class]);
    }
}
