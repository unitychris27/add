<?php

namespace App\Console\Commands;

use App\Models\Product;
use Illuminate\Console\Command;

class LowStockAlert extends Command
{
    protected $signature   = 'pos:low-stock-alert';
    protected $description = 'Send low stock alerts to admins';

    public function handle(): void
    {
        $products = Product::with('category')->lowStock()->active()->get();

        if ($products->isEmpty()) {
            $this->info('No low stock products.');
            return;
        }

        $this->warn("⚠️  {$products->count()} product(s) are low on stock:");

        foreach ($products as $product) {
            $this->line("  - {$product->name} | Stock: {$product->stock_quantity} | Alert: {$product->alert_quantity}");
        }

        $this->info('Alert sent.');
    }
}
