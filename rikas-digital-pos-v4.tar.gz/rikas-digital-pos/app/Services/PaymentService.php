<?php

namespace App\Services;

use App\Models\Setting;
use Illuminate\Http\Client\Response;
use Illuminate\Support\Facades\Http;

class PaymentService
{
    private string $baseUrl = 'https://pay.xdigitex.space/api';

    /**
     * Get the API key for the current branch/store.
     * Each store admin sets their own key in Settings.
     */
    private function getApiKey(?int $branchId = null): string
    {
        $key = $branchId
            ? Setting::get("xdigitex_api_key_branch_{$branchId}")
            : Setting::get('xdigitex_api_key');

        if (!$key) {
            throw new \Exception('Payment API key not configured. Ask your admin to set it in Settings → Payments.');
        }

        return $key;
    }

    private function http(?int $branchId = null): \Illuminate\Http\Client\PendingRequest
    {
        return Http::withHeaders([
            'X-API-Key'    => $this->getApiKey($branchId),
            'Content-Type' => 'application/json',
            'Accept'       => 'application/json',
        ])->timeout(30);
    }

    /**
     * Initiate an STK push to the customer's phone.
     * Works for Kenya (M-Pesa/Airtel) and DRC (Airtel/Orange/Vodacom) automatically
     * — the gateway auto-detects the country from the phone number.
     *
     * @param  string  $phone       International format: +254712345678 or +243812345678
     * @param  float   $amount      Amount in the store's currency
     * @param  string  $currency    KES, CDF, or USD
     * @param  string  $description e.g. "Invoice INV-20240101-0001"
     * @param  int     $branchId    To load the correct store API key
     * @param  string  $invoiceNo   For the callback reference
     */
    public function initiateSTKPush(
        string $phone,
        float $amount,
        string $currency,
        string $description,
        int $branchId,
        string $invoiceNo
    ): array {
        $callbackUrl = config('app.url') . '/api/v1/payments/callback';
        $webhookUrl  = config('app.url') . '/api/v1/payments/webhook';

        $response = $this->http($branchId)->post("{$this->baseUrl}/payments/initiate", [
            'amount'       => round($amount, 2),
            'currency'     => $currency,
            'gateway'      => 'mobile', // auto-detects country from phone number
            'phone'        => $phone,
            'description'  => $description,
            'callback_url' => $callbackUrl . '?invoice=' . $invoiceNo,
            'webhook_url'  => $webhookUrl,
        ]);

        if (!$response->successful()) {
            throw new \Exception('Payment gateway error: ' . $response->body());
        }

        $data = $response->json();

        if (!($data['success'] ?? false)) {
            throw new \Exception('Payment failed: ' . ($data['message'] ?? 'Unknown error'));
        }

        return $data;
    }

    /**
     * Poll payment status — call this every 3 seconds until status is
     * 'completed' or 'failed'.
     */
    public function checkStatus(string $reference, int $branchId): array
    {
        $response = $this->http($branchId)->get("{$this->baseUrl}/payments/{$reference}/status");

        if (!$response->successful()) {
            throw new \Exception('Failed to check payment status.');
        }

        return $response->json();
    }

    /**
     * Get wallet balance for this store's API key.
     */
    public function getBalance(int $branchId): array
    {
        $response = $this->http($branchId)->get("{$this->baseUrl}/balance");
        return $response->json();
    }

    /**
     * List all payments for this store.
     */
    public function listPayments(int $branchId, int $page = 1): array
    {
        $response = $this->http($branchId)->get("{$this->baseUrl}/payments", ['page' => $page]);
        return $response->json();
    }

    /**
     * Convert an amount from one currency to another using stored rates.
     * Rates are stored relative to USD: KES=130, CDF=2350, USD=1
     */
    public static function convertCurrency(float $amount, string $from, string $to): float
    {
        $rates = [
            'USD' => (float) (Setting::get('rate_usd', 1)),
            'KES' => (float) (Setting::get('rate_kes', 130)),
            'CDF' => (float) (Setting::get('rate_cdf', 2350)),
        ];

        if ($from === $to) return $amount;

        // Convert to USD first, then to target
        $inUsd = $amount / ($rates[$from] ?? 1);
        return round($inUsd * ($rates[$to] ?? 1), 2);
    }

    /**
     * Get the currency symbol for display.
     */
    public static function currencySymbol(?string $currency = null): string
    {
        $currency = $currency ?? Setting::get('currency', 'KES');
        return match ($currency) {
            'KES'   => 'KSh',
            'CDF'   => 'FC',
            'USD'   => '$',
            default => $currency,
        };
    }

    /**
     * Format an amount with the correct currency symbol.
     */
    public static function formatAmount(float $amount, ?string $currency = null): string
    {
        $currency = $currency ?? Setting::get('currency', 'KES');
        $symbol   = self::currencySymbol($currency);
        return $symbol . ' ' . number_format($amount, 2);
    }
}
