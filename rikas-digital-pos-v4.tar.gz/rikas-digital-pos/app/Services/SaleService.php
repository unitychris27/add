<?php

namespace App\Services;

use App\Models\Payment;
use App\Models\Product;
use App\Models\Sale;
use App\Models\SaleItem;
use App\Models\User;
use Illuminate\Support\Facades\DB;

class SaleService
{
    public function create(array $data, User $user): Sale
    {
        return DB::transaction(function () use ($data, $user) {
            $subtotal  = 0;
            $taxAmount = 0;
            $items     = [];

            foreach ($data['items'] as $item) {
                $product  = Product::findOrFail($item['product_id']);
                $qty      = $item['quantity'];
                $price    = $item['unit_price'];
                $discount = $item['discount_amount'] ?? 0;
                $tax      = round($price * $qty * ($product->tax_rate / 100), 2);
                $lineTotal = ($price * $qty) - $discount + $tax;

                $subtotal  += ($price * $qty) - $discount;
                $taxAmount += $tax;

                $items[] = [
                    'product'   => $product,
                    'quantity'  => $qty,
                    'unit_price' => $price,
                    'cost_price' => $product->cost_price,
                    'discount_amount' => $discount,
                    'tax_amount' => $tax,
                    'subtotal'  => $lineTotal,
                ];
            }

            $discount = 0;
            if (!empty($data['discount_amount'])) {
                $discount = $data['discount_type'] === 'percentage'
                    ? round($subtotal * $data['discount_amount'] / 100, 2)
                    : $data['discount_amount'];
            }

            $total  = $subtotal + $taxAmount - $discount;
            $paid   = $data['paid_amount'];
            $change = max(0, $paid - $total);

            $sale = Sale::create([
                'uuid'            => $data['uuid'],
                'branch_id'       => $user->branch_id,
                'user_id'         => $user->id,
                'customer_id'     => $data['customer_id'] ?? null,
                'status'          => 'completed',
                'subtotal'        => $subtotal,
                'tax_amount'      => $taxAmount,
                'discount_amount' => $discount,
                'discount_type'   => $data['discount_type'] ?? null,
                'total_amount'    => $total,
                'paid_amount'     => $paid,
                'change_amount'   => $change,
                'payment_method'  => $data['payment_method'],
                'payment_status'  => $paid >= $total ? 'paid' : ($paid > 0 ? 'partial' : 'unpaid'),
                'notes'           => $data['notes'] ?? null,
                'is_synced'       => true,
                'synced_at'       => now(),
            ]);

            foreach ($items as $item) {
                SaleItem::create([
                    'sale_id'         => $sale->id,
                    'product_id'      => $item['product']->id,
                    'product_name'    => $item['product']->name,
                    'product_sku'     => $item['product']->sku,
                    'unit_price'      => $item['unit_price'],
                    'cost_price'      => $item['cost_price'],
                    'quantity'        => $item['quantity'],
                    'discount_amount' => $item['discount_amount'],
                    'tax_amount'      => $item['tax_amount'],
                    'subtotal'        => $item['subtotal'],
                ]);

                // Deduct stock
                if ($item['product']->track_inventory) {
                    $item['product']->decrement('stock_quantity', $item['quantity']);
                }
            }

            // Record payments
            if (!empty($data['payments']) && count($data['payments']) > 1) {
                foreach ($data['payments'] as $p) {
                    Payment::create([
                        'sale_id'   => $sale->id,
                        'method'    => $p['method'],
                        'amount'    => $p['amount'],
                        'reference' => $p['reference'] ?? null,
                        'status'    => 'success',
                        'paid_at'   => now(),
                    ]);
                }
            } else {
                Payment::create([
                    'sale_id'   => $sale->id,
                    'method'    => $data['payment_method'],
                    'amount'    => $paid,
                    'status'    => 'success',
                    'paid_at'   => now(),
                ]);
            }

            activity_log('sale_created', $user->id, "Sale #{$sale->invoice_number} - Total: {$total}");

            return $sale;
        });
    }

    public function bulkSync(array $sales, User $user): array
    {
        $synced  = 0;
        $skipped = 0;
        $failed  = [];

        foreach ($sales as $saleData) {
            try {
                $existing = Sale::where('uuid', $saleData['uuid'])->first();
                if ($existing) {
                    $skipped++;
                    continue;
                }
                $this->create($saleData, $user);
                $synced++;
            } catch (\Exception $e) {
                $failed[] = ['uuid' => $saleData['uuid'] ?? null, 'error' => $e->getMessage()];
            }
        }

        return compact('synced', 'skipped', 'failed');
    }

    public function refund(Sale $sale, array $data, User $user): Sale
    {
        if ($sale->status === 'refunded') {
            throw new \Exception('Sale already refunded.');
        }

        DB::transaction(function () use ($sale, $data, $user) {
            $sale->update(['status' => 'refunded']);

            // Restore stock
            foreach ($sale->items as $item) {
                if ($item->product && $item->product->track_inventory) {
                    $item->product->increment('stock_quantity', $item->quantity);
                }
            }

            activity_log('sale_refunded', $user->id, "Sale #{$sale->invoice_number} refunded. Reason: {$data['reason']}");
        });

        return $sale->fresh();
    }

    public function generateReceiptData(Sale $sale): array
    {
        $sale->load(['items.product', 'payments', 'customer', 'user:id,name', 'branch']);
        $settings = \App\Models\Setting::where('group', 'business')->pluck('value', 'key');

        return [
            'business_name'    => $settings['business_name'] ?? config('app.name'),
            'business_address' => $settings['business_address'] ?? '',
            'business_phone'   => $settings['business_phone'] ?? '',
            'business_email'   => $settings['business_email'] ?? '',
            'receipt_footer'   => $settings['receipt_footer'] ?? 'Thank you for your business!',
            'currency_symbol'  => $settings['currency_symbol'] ?? 'KSh',
            'branch'           => $sale->branch?->only(['name', 'address', 'phone']),
            'invoice_number'   => $sale->invoice_number,
            'date'             => $sale->created_at->format('d/m/Y H:i:s'),
            'cashier'          => $sale->user->name,
            'customer'         => $sale->customer?->only(['name', 'phone']),
            'items'            => $sale->items->map(fn ($i) => [
                'name'     => $i->product_name,
                'qty'      => $i->quantity,
                'price'    => $i->unit_price,
                'subtotal' => $i->subtotal,
            ]),
            'subtotal'         => $sale->subtotal,
            'tax'              => $sale->tax_amount,
            'discount'         => $sale->discount_amount,
            'total'            => $sale->total_amount,
            'paid'             => $sale->paid_amount,
            'change'           => $sale->change_amount,
            'payment_method'   => $sale->payment_method,
            'payments'         => $sale->payments->map(fn ($p) => [
                'method'    => $p->method,
                'amount'    => $p->amount,
                'reference' => $p->reference,
            ]),
        ];
    }
}
