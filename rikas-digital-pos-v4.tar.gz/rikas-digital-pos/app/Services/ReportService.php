<?php

namespace App\Services;

use App\Models\Expense;
use App\Models\Product;
use App\Models\Sale;
use App\Models\User;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\DB;
use Maatwebsite\Excel\Facades\Excel;
use Mpdf\Mpdf;

class ReportService
{
    public function salesReport(array $filters, User $user): array
    {
        $branchId = $user->hasRole('super_admin') ? ($filters['branch_id'] ?? null) : $user->branch_id;
        $groupBy  = $filters['group_by'] ?? 'day';

        $groupExpr = match ($groupBy) {
            'week'  => DB::raw('YEARWEEK(created_at) as period'),
            'month' => DB::raw("DATE_FORMAT(created_at, '%Y-%m') as period"),
            default => DB::raw('DATE(created_at) as period'),
        };

        $sales = Sale::completed()
            ->when($branchId, fn ($q) => $q->where('branch_id', $branchId))
            ->whereBetween('created_at', [$filters['date_from'], $filters['date_to'] . ' 23:59:59'])
            ->select(
                $groupExpr,
                DB::raw('COUNT(*) as transactions'),
                DB::raw('SUM(total_amount) as revenue'),
                DB::raw('SUM(tax_amount) as tax'),
                DB::raw('SUM(discount_amount) as discount')
            )
            ->groupBy('period')
            ->orderBy('period')
            ->get();

        $summary = Sale::completed()
            ->when($branchId, fn ($q) => $q->where('branch_id', $branchId))
            ->whereBetween('created_at', [$filters['date_from'], $filters['date_to'] . ' 23:59:59'])
            ->select(
                DB::raw('COUNT(*) as total_transactions'),
                DB::raw('SUM(total_amount) as total_revenue'),
                DB::raw('SUM(tax_amount) as total_tax'),
                DB::raw('SUM(discount_amount) as total_discount'),
                DB::raw('AVG(total_amount) as avg_transaction')
            )
            ->first();

        $byPaymentMethod = Sale::completed()
            ->when($branchId, fn ($q) => $q->where('branch_id', $branchId))
            ->whereBetween('created_at', [$filters['date_from'], $filters['date_to'] . ' 23:59:59'])
            ->select('payment_method', DB::raw('COUNT(*) as count'), DB::raw('SUM(total_amount) as total'))
            ->groupBy('payment_method')
            ->get();

        return [
            'summary'           => $summary,
            'chart_data'        => $sales,
            'by_payment_method' => $byPaymentMethod,
            'filters'           => $filters,
        ];
    }

    public function expensesReport(array $filters, User $user): array
    {
        $branchId = $user->hasRole('super_admin') ? ($filters['branch_id'] ?? null) : $user->branch_id;

        $expenses = Expense::with(['category:id,name,color'])
            ->where('status', 'approved')
            ->when($branchId, fn ($q) => $q->where('branch_id', $branchId))
            ->whereBetween('expense_date', [$filters['date_from'], $filters['date_to']])
            ->get();

        $byCategory = $expenses->groupBy('expense_category_id')->map(fn ($group) => [
            'category' => $group->first()->category,
            'total'    => $group->sum('amount'),
            'count'    => $group->count(),
        ])->values();

        return [
            'total'       => $expenses->sum('amount'),
            'count'       => $expenses->count(),
            'by_category' => $byCategory,
            'expenses'    => $expenses,
        ];
    }

    public function stockReport(array $filters): array
    {
        $products = Product::with(['category:id,name', 'brand:id,name'])
            ->where('is_active', true)
            ->when($filters['category_id'] ?? null, fn ($q) => $q->where('category_id', $filters['category_id']))
            ->when($filters['low_stock'] ?? false, fn ($q) => $q->lowStock())
            ->get();

        return [
            'products'              => $products,
            'total_products'        => $products->count(),
            'total_cost_value'      => $products->sum(fn ($p) => $p->stock_quantity * $p->cost_price),
            'total_selling_value'   => $products->sum(fn ($p) => $p->stock_quantity * $p->selling_price),
            'low_stock_count'       => $products->filter(fn ($p) => $p->isLowStock())->count(),
            'out_of_stock_count'    => $products->filter(fn ($p) => $p->stock_quantity <= 0)->count(),
        ];
    }

    public function profitLossReport(array $filters, User $user): array
    {
        $branchId = $user->hasRole('super_admin') ? null : $user->branch_id;

        $sales = Sale::completed()
            ->when($branchId, fn ($q) => $q->where('branch_id', $branchId))
            ->whereBetween('created_at', [$filters['date_from'], $filters['date_to'] . ' 23:59:59'])
            ->with('items')
            ->get();

        $totalRevenue  = $sales->sum('total_amount');
        $totalCOGS     = $sales->sum(fn ($s) => $s->items->sum(fn ($i) => $i->cost_price * $i->quantity));
        $grossProfit   = $totalRevenue - $totalCOGS;

        $totalExpenses = Expense::where('status', 'approved')
            ->when($branchId, fn ($q) => $q->where('branch_id', $branchId))
            ->whereBetween('expense_date', [$filters['date_from'], $filters['date_to']])
            ->sum('amount');

        $netProfit = $grossProfit - $totalExpenses;

        return [
            'date_from'       => $filters['date_from'],
            'date_to'         => $filters['date_to'],
            'total_revenue'   => $totalRevenue,
            'total_cogs'      => $totalCOGS,
            'gross_profit'    => $grossProfit,
            'gross_margin'    => $totalRevenue > 0 ? round(($grossProfit / $totalRevenue) * 100, 2) : 0,
            'total_expenses'  => $totalExpenses,
            'net_profit'      => $netProfit,
            'net_margin'      => $totalRevenue > 0 ? round(($netProfit / $totalRevenue) * 100, 2) : 0,
            'transactions'    => $sales->count(),
        ];
    }

    public function export(string $type, string $format, array $filters, User $user): Response
    {
        $data = match ($type) {
            'sales'       => $this->salesReport($filters, $user),
            'expenses'    => $this->expensesReport($filters, $user),
            'stock'       => $this->stockReport($filters),
            'profit_loss' => $this->profitLossReport($filters, $user),
        };

        if ($format === 'pdf') {
            $mpdf = new Mpdf(['mode' => 'utf-8', 'format' => 'A4']);
            $mpdf->WriteHTML(view("reports.{$type}", compact('data'))->render());
            $filename = "report_{$type}_" . now()->format('Y-m-d') . '.pdf';
            return response($mpdf->Output($filename, 'S'), 200, [
                'Content-Type'        => 'application/pdf',
                'Content-Disposition' => "attachment; filename=\"{$filename}\"",
            ]);
        }

        // CSV fallback
        $filename = "report_{$type}_" . now()->format('Y-m-d') . '.csv';
        $csv      = collect($data['chart_data'] ?? $data['products'] ?? [])->toCsv();
        return response($csv, 200, [
            'Content-Type'        => 'text/csv',
            'Content-Disposition' => "attachment; filename=\"{$filename}\"",
        ]);
    }
}
