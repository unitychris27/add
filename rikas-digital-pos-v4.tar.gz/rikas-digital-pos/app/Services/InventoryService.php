<?php

namespace App\Services;

use App\Models\Product;
use Illuminate\Support\Collection;

class InventoryService
{
    public function getLowStockProducts(): Collection
    {
        return Product::with(['category:id,name'])
            ->lowStock()
            ->active()
            ->get();
    }

    public function adjustStock(Product $product, int $adjustment, string $reason, int $userId): void
    {
        $oldQty = $product->stock_quantity;
        $product->increment('stock_quantity', $adjustment);
        $newQty = $product->fresh()->stock_quantity;

        activity_log(
            'stock_adjusted',
            $userId,
            "Stock adjusted for {$product->name}: {$oldQty} → {$newQty} ({$reason})"
        );
    }

    public function getStockValuation(): array
    {
        $products = Product::where('is_active', true)->where('track_inventory', true)->get();

        $totalCostValue    = $products->sum(fn ($p) => $p->stock_quantity * $p->cost_price);
        $totalSellingValue = $products->sum(fn ($p) => $p->stock_quantity * $p->selling_price);

        return [
            'total_products'        => $products->count(),
            'total_cost_value'      => $totalCostValue,
            'total_selling_value'   => $totalSellingValue,
            'potential_profit'      => $totalSellingValue - $totalCostValue,
            'low_stock_count'       => $products->filter(fn ($p) => $p->isLowStock())->count(),
            'out_of_stock_count'    => $products->filter(fn ($p) => $p->stock_quantity <= 0)->count(),
        ];
    }
}
