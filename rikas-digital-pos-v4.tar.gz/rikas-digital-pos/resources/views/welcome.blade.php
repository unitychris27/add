<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>RIKAS DIGITAL POS</title>
    <style>
        body { font-family: sans-serif; display: flex; align-items: center;
               justify-content: center; min-height: 100vh; margin: 0;
               background: #0f172a; color: #f1f5f9; }
        .card { text-align: center; padding: 2rem; }
        h1 { font-size: 2rem; color: #6366f1; margin-bottom: 0.5rem; }
        p { color: #94a3b8; }
        a { display: inline-block; margin-top: 1.5rem; padding: 0.75rem 2rem;
            background: #6366f1; color: white; text-decoration: none;
            border-radius: 0.5rem; font-weight: bold; }
        a:hover { background: #4f46e5; }
    </style>
</head>
<body>
    <div class="card">
        <h1>RIKAS DIGITAL POS</h1>
        <p>Enterprise POS & Business Management System</p>
        <a href="/admin">Go to Admin Panel</a>
    </div>
</body>
</html>
