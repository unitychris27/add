{{-- RIKAS DIGITAL POS Terminal --}}
<div class="h-screen flex flex-col bg-gray-950 text-gray-100 overflow-hidden select-none"
     x-data="posTerminal()"
     @keydown.escape="$wire.showPayment = false; $wire.showReceipt = false">

    {{-- ── TOP BAR ──────────────────────────────────────────────────────── --}}
    <div class="flex items-center justify-between px-4 py-2 bg-gray-900 border-b border-yellow-600/20 shrink-0">
        <div class="flex items-center gap-3">
            <span class="text-yellow-500 font-black text-lg tracking-wide">⚡ RIKAS POS</span>
            <span class="text-gray-500 text-xs">|</span>
            <span class="text-gray-400 text-sm">{{ Auth::user()->branch->name ?? 'Main Branch' }}</span>
        </div>
        <div class="flex items-center gap-4 text-xs text-gray-400">
            <span class="bg-yellow-600/20 text-yellow-400 px-2 py-1 rounded font-bold">{{ $symbol }} {{ $currency }}</span>
            <span>👤 {{ Auth::user()->name }}</span>
            <span x-text="clock" class="font-mono"></span>
        </div>
    </div>

    {{-- ── MAIN AREA ─────────────────────────────────────────────────────── --}}
    <div class="flex flex-1 overflow-hidden">

        {{-- ── LEFT: PRODUCT SEARCH ──────────────────────────────────────── --}}
        <div class="w-1/2 flex flex-col border-r border-gray-800 overflow-hidden">

            {{-- Search bar --}}
            <div class="p-3 bg-gray-900 border-b border-gray-800">
                <div class="relative">
                    <span class="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500">🔍</span>
                    <input wire:model.live.debounce.200ms="search"
                           type="text"
                           placeholder="Scan barcode or search product name..."
                           class="w-full bg-gray-800 border border-gray-700 rounded-lg pl-9 pr-4 py-3 text-sm text-white placeholder-gray-500 focus:outline-none focus:border-yellow-500 focus:ring-1 focus:ring-yellow-500"
                           autofocus>
                    @if($search)
                        <button wire:click="$set('search', '')" class="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-300">✕</button>
                    @endif
                </div>
            </div>

            {{-- Search results --}}
            @if($searchResults)
                <div class="flex-1 overflow-y-auto p-2 grid grid-cols-2 gap-2 content-start">
                    @foreach($searchResults as $product)
                        <button wire:click="addToCart({{ $product['id'] }})"
                                class="bg-gray-800 hover:bg-yellow-600/10 border border-gray-700 hover:border-yellow-500/50 rounded-lg p-3 text-left transition-all group">
                            <div class="font-semibold text-sm text-white group-hover:text-yellow-400 line-clamp-2">{{ $product['name'] }}</div>
                            <div class="mt-2 flex items-center justify-between">
                                <span class="text-yellow-400 font-bold text-base">{{ $symbol }} {{ number_format($product['selling_price'], 2) }}</span>
                                <span class="text-xs text-gray-500 bg-gray-700 px-1.5 py-0.5 rounded">{{ $product['stock_quantity'] }} {{ $product['unit'] ?? 'pcs' }}</span>
                            </div>
                            @if($product['barcode'])
                                <div class="text-xs text-gray-600 mt-1 font-mono">{{ $product['barcode'] }}</div>
                            @endif
                        </button>
                    @endforeach
                </div>
            @else
                <div class="flex-1 flex flex-col items-center justify-center text-gray-600">
                    <div class="text-6xl mb-4">📦</div>
                    <div class="text-lg font-medium">Scan barcode or search</div>
                    <div class="text-sm mt-1">Products appear here as you type</div>
                </div>
            @endif
        </div>

        {{-- ── RIGHT: CART ───────────────────────────────────────────────── --}}
        <div class="w-1/2 flex flex-col overflow-hidden">

            {{-- Cart header --}}
            <div class="px-4 py-3 bg-gray-900 border-b border-gray-800 flex items-center justify-between shrink-0">
                <span class="font-bold text-base">🛒 Cart <span class="text-yellow-500">({{ count($cart) }})</span></span>
                @if(!empty($cart))
                    <button wire:click="newSale"
                            wire:confirm="Clear cart and start new sale?"
                            class="text-xs text-red-400 hover:text-red-300 bg-red-900/20 hover:bg-red-900/40 px-3 py-1 rounded-md transition-all">
                        🗑 Clear
                    </button>
                @endif
            </div>

            {{-- Cart items --}}
            <div class="flex-1 overflow-y-auto">
                @forelse($cart as $key => $item)
                    <div class="flex items-center gap-3 px-4 py-3 border-b border-gray-800/50 hover:bg-gray-800/30 transition-all group">
                        <div class="flex-1 min-w-0">
                            <div class="font-medium text-sm text-white truncate">{{ $item['name'] }}</div>
                            <div class="text-xs text-gray-500 mt-0.5">{{ $symbol }} {{ number_format($item['price'], 2) }} × {{ $item['qty'] }}</div>
                        </div>

                        {{-- Qty controls --}}
                        <div class="flex items-center gap-1.5">
                            <button wire:click="decreaseQty('{{ $key }}')"
                                    class="w-7 h-7 rounded-full bg-gray-700 hover:bg-red-700 text-white text-sm font-bold transition-colors flex items-center justify-center">−</button>
                            <span class="w-8 text-center font-bold text-sm">{{ $item['qty'] }}</span>
                            <button wire:click="increaseQty('{{ $key }}')"
                                    class="w-7 h-7 rounded-full bg-gray-700 hover:bg-green-700 text-white text-sm font-bold transition-colors flex items-center justify-center">+</button>
                        </div>

                        <div class="text-right min-w-[80px]">
                            <div class="font-bold text-yellow-400 text-sm">{{ $symbol }} {{ number_format($item['subtotal'], 2) }}</div>
                        </div>

                        <button wire:click="removeFromCart('{{ $key }}')"
                                class="opacity-0 group-hover:opacity-100 text-red-500 hover:text-red-400 transition-all ml-1">✕</button>
                    </div>
                @empty
                    <div class="flex flex-col items-center justify-center h-full text-gray-600 py-16">
                        <div class="text-5xl mb-3">🛒</div>
                        <div class="text-base font-medium">Cart is empty</div>
                        <div class="text-sm mt-1">Search or scan products to add them</div>
                    </div>
                @endforelse
            </div>

            {{-- Totals + Pay button --}}
            <div class="shrink-0 bg-gray-900 border-t border-gray-800 p-4">
                <div class="space-y-1.5 mb-4">
                    <div class="flex justify-between text-sm text-gray-400">
                        <span>Subtotal</span>
                        <span>{{ $symbol }} {{ number_format($subtotal, 2) }}</span>
                    </div>
                    <div class="flex justify-between text-sm text-gray-400">
                        <span>Tax ({{ $taxRate }}%)</span>
                        <span>{{ $symbol }} {{ number_format($taxAmount, 2) }}</span>
                    </div>
                    @if($discountAmount > 0)
                        <div class="flex justify-between text-sm text-green-400">
                            <span>Discount</span>
                            <span>− {{ $symbol }} {{ number_format($discountAmount, 2) }}</span>
                        </div>
                    @endif
                    <div class="flex justify-between font-black text-lg text-white pt-2 border-t border-gray-700">
                        <span>TOTAL</span>
                        <span class="text-yellow-400">{{ $symbol }} {{ number_format($total, 2) }}</span>
                    </div>
                </div>

                <button wire:click="openPayment"
                        @class(['w-full py-4 rounded-xl font-black text-lg transition-all', 'bg-gradient-to-r from-yellow-600 to-yellow-500 hover:from-yellow-500 hover:to-yellow-400 text-black shadow-lg shadow-yellow-500/30 hover:shadow-yellow-500/50 active:scale-95' => !empty($cart), 'bg-gray-700 text-gray-500 cursor-not-allowed' => empty($cart)])>
                    @if(empty($cart))
                        Add products to cart
                    @else
                        💳 PAY {{ $symbol }} {{ number_format($total, 2) }}
                    @endif
                </button>
            </div>
        </div>
    </div>

    {{-- ══ PAYMENT MODAL ═══════════════════════════════════════════════════ --}}
    @if($showPayment)
        <div class="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <div class="bg-gray-900 rounded-2xl border border-gray-700 w-full max-w-md shadow-2xl">

                {{-- Header --}}
                <div class="flex items-center justify-between p-5 border-b border-gray-800">
                    <h2 class="text-lg font-bold text-white">💳 Payment</h2>
                    <div class="text-right">
                        <div class="text-xs text-gray-400">Total to collect</div>
                        <div class="text-2xl font-black text-yellow-400">{{ $symbol }} {{ number_format($total, 2) }}</div>
                    </div>
                </div>

                {{-- Payment method tabs --}}
                <div class="flex border-b border-gray-800">
                    <button wire:click="$set('paymentMethod', 'cash')"
                            @class(['flex-1 py-3 text-sm font-semibold transition-all', 'bg-yellow-600/20 text-yellow-400 border-b-2 border-yellow-500' => $paymentMethod === 'cash', 'text-gray-500 hover:text-gray-300' => $paymentMethod !== 'cash'])>
                        💵 Cash
                    </button>
                    <button wire:click="$set('paymentMethod', 'mobile_money')"
                            @class(['flex-1 py-3 text-sm font-semibold transition-all', 'bg-yellow-600/20 text-yellow-400 border-b-2 border-yellow-500' => $paymentMethod === 'mobile_money', 'text-gray-500 hover:text-gray-300' => $paymentMethod !== 'mobile_money'])>
                        📱 Mobile Money
                    </button>
                </div>

                <div class="p-5">

                    {{-- CASH --}}
                    @if($paymentMethod === 'cash')
                        <div class="space-y-4">
                            <div>
                                <label class="text-xs text-gray-400 uppercase tracking-wider mb-1.5 block">Cash Received</label>
                                <div class="relative">
                                    <span class="absolute left-3 top-1/2 -translate-y-1/2 text-yellow-500 font-bold text-sm">{{ $symbol }}</span>
                                    <input wire:model.live="cashReceived" type="number" step="0.01"
                                           class="w-full bg-gray-800 border border-gray-600 rounded-lg pl-12 pr-4 py-3 text-xl font-bold text-white focus:outline-none focus:border-yellow-500">
                                </div>
                            </div>

                            @if($cashReceived >= $total)
                                <div class="bg-green-900/30 border border-green-700/50 rounded-lg p-3 flex justify-between items-center">
                                    <span class="text-green-400 font-medium">Change to give back:</span>
                                    <span class="text-green-400 font-black text-xl">{{ $symbol }} {{ number_format($change, 2) }}</span>
                                </div>
                            @endif

                            @if($paymentMessage)
                                <div class="bg-red-900/20 border border-red-700/40 rounded-lg p-3 text-red-400 text-sm">{{ $paymentMessage }}</div>
                            @endif

                            <button wire:click="processCash"
                                    class="w-full py-4 bg-gradient-to-r from-green-600 to-green-500 hover:from-green-500 hover:to-green-400 text-white font-black text-lg rounded-xl transition-all active:scale-95 shadow-lg shadow-green-500/20">
                                ✓ Confirm Cash Payment
                            </button>
                        </div>
                    @endif

                    {{-- MOBILE MONEY --}}
                    @if($paymentMethod === 'mobile_money')
                        <div class="space-y-4">

                            @if(in_array($paymentStatus, ['', 'failed']))
                                <div>
                                    <label class="text-xs text-gray-400 uppercase tracking-wider mb-1.5 block">Customer Phone Number</label>
                                    <input wire:model="customerPhone" type="tel"
                                           placeholder="+254712345678 or +243812345678"
                                           class="w-full bg-gray-800 border border-gray-600 rounded-lg px-4 py-3 text-base text-white placeholder-gray-600 focus:outline-none focus:border-yellow-500">
                                    <div class="text-xs text-gray-500 mt-1">🇰🇪 Kenya: +254... &nbsp;|&nbsp; 🇨🇩 DRC: +243...</div>
                                </div>

                                @if($paymentMessage)
                                    <div class="bg-red-900/20 border border-red-700/40 rounded-lg p-3 text-red-400 text-sm">{{ $paymentMessage }}</div>
                                @endif

                                <button wire:click="sendSTKPush"
                                        class="w-full py-4 bg-gradient-to-r from-blue-600 to-blue-500 hover:from-blue-500 hover:to-blue-400 text-white font-black text-lg rounded-xl transition-all active:scale-95">
                                    📲 Send STK Push
                                </button>
                            @endif

                            @if($paymentStatus === 'processing')
                                <div class="text-center py-6">
                                    <div class="text-4xl mb-3 animate-pulse">📡</div>
                                    <div class="text-yellow-400 font-semibold">Sending payment request...</div>
                                </div>
                            @endif

                            @if($paymentStatus === 'pending')
                                <div class="text-center py-4" wire:poll.3000ms="pollPaymentStatus">
                                    <div class="text-5xl mb-3 animate-bounce">📱</div>
                                    <div class="text-yellow-400 font-bold text-lg mb-1">Waiting for customer...</div>
                                    <div class="text-gray-400 text-sm mb-4">{{ $paymentMessage }}</div>
                                    <div class="flex items-center justify-center gap-2 text-gray-500 text-xs">
                                        <span class="animate-spin">⟳</span>
                                        <span>Checking payment status every 3 seconds...</span>
                                    </div>
                                    <div class="mt-4 bg-blue-900/20 border border-blue-700/30 rounded-lg p-3 text-xs text-blue-300">
                                        Ref: {{ $stkReference }}
                                    </div>
                                </div>
                            @endif

                            @if($paymentStatus === 'completed')
                                <div class="text-center py-6">
                                    <div class="text-6xl mb-3">✅</div>
                                    <div class="text-green-400 font-black text-xl">Payment Confirmed!</div>
                                    <div class="text-gray-400 text-sm mt-2">Generating receipt...</div>
                                </div>
                            @endif
                        </div>
                    @endif
                </div>

                @if(!in_array($paymentStatus, ['processing', 'pending', 'completed']))
                    <div class="px-5 pb-5">
                        <button wire:click="$set('showPayment', false)"
                                class="w-full py-2 text-gray-500 hover:text-gray-300 text-sm transition-colors">
                            Cancel
                        </button>
                    </div>
                @endif
            </div>
        </div>
    @endif

    {{-- ══ RECEIPT MODAL ═══════════════════════════════════════════════════ --}}
    @if($showReceipt && $receiptData)
        <div class="fixed inset-0 bg-black/90 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <div class="bg-white text-gray-900 rounded-xl w-full max-w-sm shadow-2xl overflow-hidden">

                {{-- Receipt content (printable) --}}
                <div id="receipt-print" class="p-6 font-mono text-xs">
                    <div class="text-center mb-4">
                        <div class="font-black text-xl tracking-widest">{{ strtoupper($receiptData['branch']) }}</div>
                        @if($receiptData['branch_address'])
                            <div class="text-gray-500 text-xs">{{ $receiptData['branch_address'] }}</div>
                        @endif
                        <div class="border-b-2 border-dashed border-gray-300 mt-3 mb-3"></div>
                    </div>

                    <div class="space-y-1 mb-3 text-xs text-gray-600">
                        <div class="flex justify-between"><span>Invoice:</span><span class="font-bold">{{ $receiptData['invoice_no'] }}</span></div>
                        <div class="flex justify-between"><span>Date:</span><span>{{ $receiptData['date'] }}</span></div>
                        <div class="flex justify-between"><span>Cashier:</span><span>{{ $receiptData['cashier'] }}</span></div>
                        <div class="flex justify-between"><span>Customer:</span><span>{{ $receiptData['customer'] }}</span></div>
                    </div>

                    <div class="border-b border-dashed border-gray-300 mb-3"></div>

                    {{-- Items --}}
                    <table class="w-full text-xs mb-3">
                        <thead>
                            <tr class="text-gray-500 border-b border-gray-200">
                                <th class="text-left pb-1">Item</th>
                                <th class="text-center pb-1">Qty</th>
                                <th class="text-right pb-1">Price</th>
                                <th class="text-right pb-1">Total</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($receiptData['items'] as $item)
                                <tr class="border-b border-gray-100">
                                    <td class="py-1 pr-1 font-medium">{{ $item['name'] }}</td>
                                    <td class="text-center py-1">{{ $item['qty'] }}</td>
                                    <td class="text-right py-1">{{ $receiptData['symbol'] }} {{ number_format($item['price'], 2) }}</td>
                                    <td class="text-right py-1 font-bold">{{ $receiptData['symbol'] }} {{ number_format($item['subtotal'], 2) }}</td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>

                    <div class="space-y-1 text-xs">
                        <div class="flex justify-between text-gray-500"><span>Subtotal</span><span>{{ $receiptData['symbol'] }} {{ number_format($receiptData['subtotal'], 2) }}</span></div>
                        <div class="flex justify-between text-gray-500"><span>Tax ({{ $receiptData['tax_rate'] }}%)</span><span>{{ $receiptData['symbol'] }} {{ number_format($receiptData['tax_amount'], 2) }}</span></div>
                        @if($receiptData['discount'] > 0)
                            <div class="flex justify-between text-green-600"><span>Discount</span><span>-{{ $receiptData['symbol'] }} {{ number_format($receiptData['discount'], 2) }}</span></div>
                        @endif
                        <div class="flex justify-between font-black text-base border-t border-gray-300 pt-1 mt-1">
                            <span>TOTAL</span>
                            <span>{{ $receiptData['symbol'] }} {{ number_format($receiptData['total'], 2) }}</span>
                        </div>
                    </div>

                    <div class="border-b border-dashed border-gray-300 my-3"></div>

                    <div class="text-xs space-y-1 text-gray-600">
                        <div class="flex justify-between">
                            <span>Paid via</span>
                            <span class="font-bold">{{ $receiptData['payment_method'] === 'cash' ? '💵 Cash' : '📱 Mobile Money' }}</span>
                        </div>
                        @if($receiptData['payment_method'] === 'cash')
                            <div class="flex justify-between"><span>Cash received</span><span>{{ $receiptData['symbol'] }} {{ number_format($receiptData['cash_received'], 2) }}</span></div>
                            <div class="flex justify-between font-bold"><span>Change</span><span>{{ $receiptData['symbol'] }} {{ number_format($receiptData['change'], 2) }}</span></div>
                        @else
                            <div class="flex justify-between"><span>Reference</span><span class="font-mono text-xs">{{ substr($receiptData['reference'] ?? '', 0, 20) }}</span></div>
                        @endif
                    </div>

                    <div class="border-b border-dashed border-gray-300 my-3"></div>

                    <div class="text-center text-gray-500 text-xs">
                        <div class="font-bold text-gray-700 text-sm mb-1">Thank you for shopping with us!</div>
                        <div>Served by: {{ $receiptData['cashier'] }}</div>
                        <div class="mt-1">{{ config('app.name') }}</div>
                    </div>
                </div>

                {{-- Receipt actions --}}
                <div class="bg-gray-50 border-t border-gray-200 p-4 flex gap-3">
                    <button onclick="printReceipt()"
                            class="flex-1 py-3 bg-gray-900 hover:bg-gray-700 text-white font-bold rounded-lg transition-colors text-sm">
                        🖨 Print Receipt
                    </button>
                    <button wire:click="newSale"
                            class="flex-1 py-3 bg-gradient-to-r from-yellow-600 to-yellow-500 text-black font-bold rounded-lg transition-all text-sm">
                        ✚ New Sale
                    </button>
                </div>
            </div>
        </div>
    @endif
</div>

@push('scripts')
<script>
function posTerminal() {
    return {
        clock: '',
        init() {
            setInterval(() => {
                const now = new Date();
                this.clock = now.toLocaleTimeString('en-GB');
            }, 1000);
        }
    }
}

function printReceipt() {
    const el = document.getElementById('receipt-print');
    if (!el) return;
    const w = window.open('', '', 'width=400,height=700');
    w.document.write(`
        <html><head><title>Receipt</title>
        <style>body{font-family:monospace;font-size:12px;margin:0;padding:16px;} *{box-sizing:border-box;} table{width:100%;border-collapse:collapse;} td,th{padding:2px 4px;}</style>
        </head><body>` + el.innerHTML + `</body></html>`);
    w.document.close();
    w.focus();
    setTimeout(() => { w.print(); w.close(); }, 500);
}
</script>
@endpush
