<x-filament-panels::page>
    <div class="-mx-4 -my-6 md:-mx-6 md:-my-8" style="height: calc(100vh - 64px)">
        @livewire('p-o-s-terminal')
    </div>
</x-filament-panels::page>
