<x-filament-panels::page>
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        @foreach($this->getStats() as $stat)
            <div class="bg-white dark:bg-gray-800 rounded-xl shadow p-6">
                <p class="text-sm text-gray-500 dark:text-gray-400">{{ $stat->getLabel() }}</p>
                <p class="text-2xl font-bold text-gray-900 dark:text-white mt-1">{{ $stat->getValue() }}</p>
                @if($stat->getDescription())
                    <p class="text-xs text-gray-400 mt-1">{{ $stat->getDescription() }}</p>
                @endif
            </div>
        @endforeach
    </div>

    <x-filament-widgets::widgets
        :widgets="$this->getWidgets()"
        :columns="$this->getColumns()"
    />
</x-filament-panels::page>
