<x-filament-panels::page>
    {{-- Balance card --}}
    <div class="mb-6">
        @if($balanceError)
            <div class="bg-red-900/20 border border-red-700/40 rounded-xl p-4 text-red-400">
                <div class="font-semibold mb-1">⚠ Could not load balance</div>
                <div class="text-sm">{{ $balanceError }}</div>
                <div class="text-xs mt-2 text-red-500">Make sure your Xdigitex Pay API key is set in Payment Settings.</div>
            </div>
        @elseif($balance)
            <div class="grid grid-cols-3 gap-4">
                <div class="bg-gradient-to-br from-yellow-900/40 to-yellow-800/20 border border-yellow-600/30 rounded-xl p-5">
                    <div class="text-yellow-400/70 text-xs uppercase tracking-wider mb-1">Available Balance</div>
                    <div class="text-3xl font-black text-yellow-400">{{ $balance['currency'] ?? '' }} {{ number_format($balance['available_balance'] ?? 0, 2) }}</div>
                </div>
                <div class="bg-gray-800/40 border border-gray-700/40 rounded-xl p-5">
                    <div class="text-gray-400 text-xs uppercase tracking-wider mb-1">Total Balance</div>
                    <div class="text-2xl font-bold text-gray-200">{{ number_format($balance['balance'] ?? 0, 2) }}</div>
                </div>
                <div class="bg-gray-800/40 border border-gray-700/40 rounded-xl p-5">
                    <div class="text-gray-400 text-xs uppercase tracking-wider mb-1">Locked</div>
                    <div class="text-2xl font-bold text-orange-400">{{ number_format($balance['locked_balance'] ?? 0, 2) }}</div>
                </div>
            </div>
        @else
            <div class="bg-gray-800/40 border border-gray-700 rounded-xl p-6 text-center text-gray-500">
                <div class="text-3xl mb-2">💳</div>
                <div>Loading balance...</div>
            </div>
        @endif
    </div>

    {{-- Fee notice --}}
    <div class="mb-4 bg-blue-900/20 border border-blue-700/30 rounded-lg p-3 flex items-start gap-3">
        <span class="text-blue-400 text-lg mt-0.5">ℹ</span>
        <div class="text-sm text-blue-300">
            <span class="font-semibold">Withdrawal fee: 2.5%</span> — deducted from your wallet at the time of withdrawal.
            Funds arrive via mobile money within minutes. Supported: M-Pesa (Kenya), Airtel/Orange/Vodacom (DRC).
        </div>
    </div>

    <form wire:submit="withdraw">
        {{ $this->form }}
        <div class="mt-6 flex gap-3">
            <x-filament::button type="submit" color="warning" icon="heroicon-o-arrow-down-tray" size="lg">
                Submit Withdrawal
            </x-filament::button>
            <x-filament::button type="button" color="gray" wire:click="loadBalance" icon="heroicon-o-arrow-path">
                Refresh Balance
            </x-filament::button>
        </div>
    </form>
</x-filament-panels::page>
