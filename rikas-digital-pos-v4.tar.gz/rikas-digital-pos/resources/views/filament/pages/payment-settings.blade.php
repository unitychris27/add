<x-filament-panels::page>
    <x-filament::section>
        <div class="mb-4 p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg border border-blue-200 dark:border-blue-800">
            <h3 class="font-semibold text-blue-800 dark:text-blue-200 mb-1">How STK Push works</h3>
            <ol class="text-sm text-blue-700 dark:text-blue-300 space-y-1 list-decimal list-inside">
                <li>Cashier adds items to cart and hits <strong>Pay</strong></li>
                <li>Cashier enters customer's phone number (e.g. +254712345678 for Kenya, +243812345678 for DRC)</li>
                <li>Customer receives a <strong>payment prompt</strong> on their phone</li>
                <li>Customer enters their <strong>PIN</strong> to confirm</li>
                <li>POS detects payment → <strong>receipt prints automatically</strong></li>
            </ol>
        </div>
    </x-filament::section>

    <form wire:submit="save">
        {{ $this->form }}

        <div class="mt-6">
            <x-filament::button type="submit" size="lg">
                Save Settings
            </x-filament::button>
        </div>
    </form>
</x-filament-panels::page>
