<x-filament-panels::page>
    <form wire:submit="generate">
        {{ $this->form }}
        <div class="mt-4 flex gap-3">
            <x-filament::button type="submit" color="primary" icon="heroicon-o-chart-bar">
                Generate Report
            </x-filament::button>
        </div>
    </form>

    @if(!empty($results))
        <div class="mt-8">
            {{-- Header --}}
            <div class="flex items-center justify-between mb-4">
                <h2 class="text-xl font-bold text-gray-100">{{ $results['title'] }}</h2>
                <button onclick="window.print()"
                        class="flex items-center gap-2 px-4 py-2 bg-gray-700 hover:bg-gray-600 text-gray-200 rounded-lg text-sm transition-colors">
                    🖨 Print Report
                </button>
            </div>

            {{-- Summary totals --}}
            @if(!empty($results['totals']))
                <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                    @foreach($results['totals'] as $label => $value)
                        <div class="bg-yellow-600/10 border border-yellow-600/30 rounded-xl p-4">
                            <div class="text-yellow-400/70 text-xs uppercase tracking-wider mb-1">{{ $label }}</div>
                            <div class="text-yellow-300 font-black text-lg">{{ $value }}</div>
                        </div>
                    @endforeach
                </div>
            @endif

            {{-- Data table --}}
            @if(!empty($results['rows']))
                <div class="overflow-x-auto rounded-xl border border-gray-700">
                    <table class="w-full text-sm text-left">
                        <thead class="bg-gray-800 text-gray-400 uppercase text-xs">
                            <tr>
                                @foreach($results['headers'] as $h)
                                    <th class="px-4 py-3">{{ $h }}</th>
                                @endforeach
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-800">
                            @foreach($results['rows'] as $row)
                                <tr class="bg-gray-900/50 hover:bg-gray-800/50 transition-colors">
                                    @foreach($row as $i => $cell)
                                        <td class="px-4 py-3 @if($i === 0) font-medium text-white @else text-gray-300 @endif">
                                            {{ $cell }}
                                        </td>
                                    @endforeach
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
                <div class="text-gray-500 text-xs mt-2">{{ count($results['rows']) }} rows</div>
            @else
                <div class="text-center py-12 text-gray-500">No data found for the selected period.</div>
            @endif
        </div>
    @endif
</x-filament-panels::page>
