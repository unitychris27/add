<div class="flex items-center gap-1" x-data>
    @php $locale = app()->getLocale(); @endphp

    <a href="{{ route('language.switch', 'en') }}"
       title="English"
       class="inline-flex items-center gap-1 px-2 py-1 rounded-md text-xs font-semibold transition-all duration-200
              {{ $locale === 'en'
                  ? 'bg-gradient-to-r from-yellow-600 to-yellow-500 text-black shadow shadow-yellow-500/30'
                  : 'text-gray-400 hover:text-yellow-400 hover:bg-white/5' }}">
        <span class="text-sm leading-none">🇬🇧</span>
        <span class="hidden sm:inline">EN</span>
    </a>

    <span class="text-gray-600 text-xs">|</span>

    <a href="{{ route('language.switch', 'fr') }}"
       title="Français"
       class="inline-flex items-center gap-1 px-2 py-1 rounded-md text-xs font-semibold transition-all duration-200
              {{ $locale === 'fr'
                  ? 'bg-gradient-to-r from-yellow-600 to-yellow-500 text-black shadow shadow-yellow-500/30'
                  : 'text-gray-400 hover:text-yellow-400 hover:bg-white/5' }}">
        <span class="text-sm leading-none">🇫🇷</span>
        <span class="hidden sm:inline">FR</span>
    </a>
</div>
