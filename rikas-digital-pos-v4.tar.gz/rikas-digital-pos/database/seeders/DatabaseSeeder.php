<?php

namespace Database\Seeders;

use App\Models\Category;
use App\Models\ExpenseCategory;
use App\Models\Setting;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        $this->call([RolesSeeder::class]);

        // Default expense categories
        $expenseCategories = [
            ['name' => 'Rent', 'color' => '#ef4444'],
            ['name' => 'Utilities', 'color' => '#f59e0b'],
            ['name' => 'Salaries', 'color' => '#3b82f6'],
            ['name' => 'Transport', 'color' => '#10b981'],
            ['name' => 'Miscellaneous', 'color' => '#6b7280'],
            ['name' => 'Marketing', 'color' => '#8b5cf6'],
            ['name' => 'Supplies', 'color' => '#06b6d4'],
        ];

        foreach ($expenseCategories as $cat) {
            ExpenseCategory::firstOrCreate(['name' => $cat['name']], $cat);
        }

        // Default product categories
        $productCategories = [
            'Beverages', 'Food & Snacks', 'Electronics', 'Clothing',
            'Personal Care', 'Cleaning Supplies', 'Stationery', 'General',
        ];

        foreach ($productCategories as $cat) {
            Category::firstOrCreate(
                ['name' => $cat],
                ['slug' => \Illuminate\Support\Str::slug($cat), 'is_active' => true]
            );
        }

        // Default system settings
        $settings = [
            ['key' => 'business_name',    'value' => 'RIKAS DIGITAL POS',  'group' => 'business', 'type' => 'string',  'label' => 'Business Name'],
            ['key' => 'business_address', 'value' => 'Nairobi, Kenya',       'group' => 'business', 'type' => 'string',  'label' => 'Business Address'],
            ['key' => 'business_phone',   'value' => '+254700000000',         'group' => 'business', 'type' => 'string',  'label' => 'Business Phone'],
            ['key' => 'business_email',   'value' => 'info@rikasdpos.com',    'group' => 'business', 'type' => 'string',  'label' => 'Business Email'],
            ['key' => 'currency',         'value' => 'KES',                   'group' => 'business', 'type' => 'string',  'label' => 'Currency'],
            ['key' => 'currency_symbol',  'value' => 'KSh',                   'group' => 'business', 'type' => 'string',  'label' => 'Currency Symbol'],
            ['key' => 'tax_rate',         'value' => '16',                    'group' => 'business', 'type' => 'integer', 'label' => 'Default Tax Rate (%)'],
            ['key' => 'receipt_footer',   'value' => 'Thank you for shopping with us!', 'group' => 'receipt', 'type' => 'string', 'label' => 'Receipt Footer'],
            ['key' => 'print_logo',       'value' => '1',                     'group' => 'receipt', 'type' => 'boolean', 'label' => 'Print Logo'],
            ['key' => 'print_qr',         'value' => '1',                     'group' => 'receipt', 'type' => 'boolean', 'label' => 'Print QR Code'],
            ['key' => 'low_stock_alert',  'value' => '1',                     'group' => 'alerts',  'type' => 'boolean', 'label' => 'Low Stock Alerts'],
        ];

        foreach ($settings as $setting) {
            Setting::firstOrCreate(['key' => $setting['key']], $setting);
        }

        $this->command->info('✅ Default data seeded successfully!');
    }
}
