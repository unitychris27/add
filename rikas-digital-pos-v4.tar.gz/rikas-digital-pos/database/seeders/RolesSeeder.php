<?php

namespace Database\Seeders;

use App\Models\Branch;
use App\Models\User;
use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;

class RolesSeeder extends Seeder
{
    public function run(): void
    {
        // Reset cached roles and permissions
        app()[\Spatie\Permission\PermissionRegistrar::class]->forgetCachedPermissions();

        // Define all permissions
        $permissions = [
            // Products
            'view-products', 'create-products', 'edit-products', 'delete-products',
            // Sales
            'view-sales', 'create-sales', 'refund-sales', 'view-all-sales',
            // Purchases
            'view-purchases', 'create-purchases', 'edit-purchases',
            // Expenses
            'view-expenses', 'create-expenses', 'approve-expenses',
            // Losses
            'view-losses', 'create-losses', 'approve-losses',
            // Reports
            'view-reports', 'export-reports',
            // Users
            'manage-users',
            // Settings
            'manage-settings',
            // Branches
            'manage-branches',
            // Customers
            'view-customers', 'manage-customers',
        ];

        foreach ($permissions as $permission) {
            Permission::firstOrCreate(['name' => $permission]);
        }

        // SUPER ADMIN — everything
        $superAdmin = Role::firstOrCreate(['name' => 'super_admin']);
        $superAdmin->syncPermissions($permissions);

        // MANAGER — most things, no user management
        $manager = Role::firstOrCreate(['name' => 'manager']);
        $manager->syncPermissions([
            'view-products', 'create-products', 'edit-products',
            'view-sales', 'create-sales', 'refund-sales', 'view-all-sales',
            'view-purchases', 'create-purchases', 'edit-purchases',
            'view-expenses', 'create-expenses', 'approve-expenses',
            'view-losses', 'create-losses', 'approve-losses',
            'view-reports', 'export-reports',
            'view-customers', 'manage-customers',
        ]);

        // ASSOCIATE / CASHIER — create sales and expenses only
        $associate = Role::firstOrCreate(['name' => 'associate']);
        $associate->syncPermissions([
            'view-products',
            'view-sales', 'create-sales',
            'view-expenses', 'create-expenses',
            'view-customers', 'manage-customers',
        ]);

        // Create default branch and super admin user
        $branch = Branch::firstOrCreate(
            ['code' => 'HQ'],
            [
                'name'         => 'Main Branch',
                'address'      => 'Nairobi, Kenya',
                'phone'        => '+254700000000',
                'email'        => 'info@rikasdpos.com',
                'manager_name' => 'Admin',
                'is_active'    => true,
            ]
        );

        $admin = User::firstOrCreate(
            ['email' => 'admin@rikasdpos.com'],
            [
                'name'       => 'Super Admin',
                'password'   => bcrypt('Admin@1234'),
                'branch_id'  => $branch->id,
                'is_active'  => true,
            ]
        );

        $admin->assignRole('super_admin');

        $this->command->info('✅ Roles, permissions, and default admin created.');
        $this->command->info('   Admin Email: admin@rikasdpos.com');
        $this->command->info('   Admin Password: Admin@1234');
        $this->command->warn('   ⚠️  Change the admin password immediately after first login!');
    }
}
