<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('payments', function (Blueprint $table) {
            $table->id();
            $table->foreignId('sale_id')->constrained()->cascadeOnDelete();
            $table->string('method')->comment('cash, mpesa, card, bank_transfer');
            $table->decimal('amount', 12, 2);
            $table->string('reference')->nullable()->comment('M-Pesa code, card ref, etc.');
            $table->string('status')->default('success')->comment('success, failed, pending');
            $table->json('metadata')->nullable()->comment('Transaction data from payment gateway');
            $table->timestamp('paid_at')->nullable();
            $table->timestamps();
            $table->index('sale_id');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('payments');
    }
};
