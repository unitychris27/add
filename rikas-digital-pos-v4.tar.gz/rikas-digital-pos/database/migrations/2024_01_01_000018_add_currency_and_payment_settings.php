<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use App\Models\Setting;

return new class extends Migration
{
    public function up(): void
    {
        // Add payment_reference column to payments table
        Schema::table('payments', function (Blueprint $table) {
            if (!Schema::hasColumn('payments', 'payment_reference')) {
                $table->string('payment_reference')->nullable()->after('reference')
                    ->comment('Xdigitex Pay TX reference');
                $table->string('phone')->nullable()->after('payment_reference')
                    ->comment('Customer phone used for STK push');
            }
        });

        // Seed currency and payment settings
        $settings = [
            ['key' => 'currency',        'value' => 'KES',  'group' => 'business',  'type' => 'string',  'label' => 'Active Currency'],
            ['key' => 'currency_symbol', 'value' => 'KSh',  'group' => 'business',  'type' => 'string',  'label' => 'Currency Symbol'],
            ['key' => 'rate_usd',        'value' => '1',    'group' => 'currency',  'type' => 'integer', 'label' => 'USD Rate (base)'],
            ['key' => 'rate_kes',        'value' => '130',  'group' => 'currency',  'type' => 'integer', 'label' => 'KES per USD'],
            ['key' => 'rate_cdf',        'value' => '2350', 'group' => 'currency',  'type' => 'integer', 'label' => 'CDF per USD'],
            ['key' => 'xdigitex_api_key','value' => '',     'group' => 'payments',  'type' => 'string',  'label' => 'Xdigitex Pay API Key (default)'],
            ['key' => 'payment_gateway', 'value' => 'mobile','group' => 'payments', 'type' => 'string',  'label' => 'Default Payment Gateway'],
        ];

        foreach ($settings as $setting) {
            \DB::table('settings')->insertOrIgnore($setting + ['created_at' => now(), 'updated_at' => now()]);
        }
    }

    public function down(): void
    {
        Schema::table('payments', function (Blueprint $table) {
            $table->dropColumn(['payment_reference', 'phone']);
        });
    }
};
