<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::table('customers', function (Blueprint $table) {
            if (!Schema::hasColumn('customers', 'company')) {
                $table->string('company')->nullable();
            }
            if (!Schema::hasColumn('customers', 'tax_number')) {
                $table->string('tax_number', 100)->nullable();
            }
            if (!Schema::hasColumn('customers', 'type')) {
                $table->enum('type', ['retail', 'wholesale'])->default('retail');
            }
            if (!Schema::hasColumn('customers', 'city')) {
                $table->string('city', 100)->nullable();
            }
            if (!Schema::hasColumn('customers', 'country')) {
                $table->string('country', 100)->nullable();
            }
            if (!Schema::hasColumn('customers', 'credit_limit')) {
                $table->decimal('credit_limit', 12, 2)->default(0);
            }
        });
    }

    public function down(): void {}
};
