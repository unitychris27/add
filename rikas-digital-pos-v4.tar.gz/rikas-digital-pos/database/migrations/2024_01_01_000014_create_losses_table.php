<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('losses', function (Blueprint $table) {
            $table->id();
            $table->foreignId('branch_id')->constrained();
            $table->foreignId('user_id')->constrained()->comment('Reported by');
            $table->foreignId('product_id')->constrained();
            $table->foreignId('approved_by')->nullable()->constrained('users')->nullOnDelete();
            $table->string('type')->comment('damaged, missing, expired, theft');
            $table->integer('quantity');
            $table->decimal('unit_cost', 12, 2);
            $table->decimal('total_loss', 12, 2);
            $table->text('reason')->nullable();
            $table->string('attachment')->nullable();
            $table->string('status')->default('pending')->comment('pending, approved, rejected');
            $table->date('loss_date');
            $table->timestamp('approved_at')->nullable();
            $table->softDeletes();
            $table->timestamps();
            $table->index(['branch_id', 'loss_date']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('losses');
    }
};
