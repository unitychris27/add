<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('sales', function (Blueprint $table) {
            $table->id();
            $table->uuid('uuid')->unique()->comment('For offline sync deduplication');
            $table->foreignId('branch_id')->constrained();
            $table->foreignId('user_id')->constrained()->comment('Cashier');
            $table->foreignId('customer_id')->nullable()->constrained()->nullOnDelete();
            $table->string('invoice_number')->unique();
            $table->string('status')->default('completed')
                ->comment('completed, draft, suspended, refunded, partially_refunded');
            $table->decimal('subtotal', 12, 2);
            $table->decimal('tax_amount', 12, 2)->default(0);
            $table->decimal('discount_amount', 12, 2)->default(0);
            $table->string('discount_type')->nullable()->comment('fixed, percentage');
            $table->decimal('total_amount', 12, 2);
            $table->decimal('paid_amount', 12, 2)->default(0);
            $table->decimal('change_amount', 12, 2)->default(0);
            $table->string('payment_method')->default('cash')
                ->comment('cash, mpesa, card, bank_transfer, mixed');
            $table->string('payment_status')->default('paid')
                ->comment('paid, partial, unpaid');
            $table->text('notes')->nullable();
            $table->boolean('is_synced')->default(true);
            $table->timestamp('synced_at')->nullable();
            $table->softDeletes();
            $table->timestamps();
            $table->index(['branch_id', 'status', 'created_at']);
            $table->index(['user_id', 'created_at']);
            $table->index('invoice_number');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('sales');
    }
};
