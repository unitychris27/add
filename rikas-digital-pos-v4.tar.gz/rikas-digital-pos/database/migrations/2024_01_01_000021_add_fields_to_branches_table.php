<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::table('branches', function (Blueprint $table) {
            if (!Schema::hasColumn('branches', 'xdigitex_api_key')) {
                $table->string('xdigitex_api_key', 500)->nullable()->after('address');
            }
            if (!Schema::hasColumn('branches', 'code')) {
                $table->string('code', 20)->nullable()->after('name');
            }
            if (!Schema::hasColumn('branches', 'city')) {
                $table->string('city', 100)->nullable();
            }
            if (!Schema::hasColumn('branches', 'country')) {
                $table->string('country', 100)->nullable();
            }
        });
    }

    public function down(): void {}
};
