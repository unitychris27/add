# RIKAS DIGITAL POS

> A complete production-ready POS & Business Management System built with Laravel 11 + FilamentPHP.

---

## Features

- **Multi-branch** support
- **3 user roles**: Super Admin, Manager, Associate/Cashier
- **Full POS module** — barcode scanning, cart, discounts, tax, receipts
- **Inventory management** — stock tracking, low-stock alerts, bulk import
- **Purchase management** — supplier orders, stock auto-update
- **Expense management** — categories, approvals, tracking
- **Loss management** — damaged/expired/missing stock
- **Reporting** — sales, P&L, stock, expenses (PDF/Excel/CSV)
- **REST API** — versioned, Sanctum auth, ready for Flutter app
- **Offline sync** — UUID deduplication for offline POS terminals
- **FilamentPHP Admin Panel** — modern dark/light dashboard

---

## Requirements

- PHP 8.2+
- MySQL 8.0+
- Composer
- Apache with mod_rewrite enabled

---

## cPanel Deployment Guide

### Step 1 — Prepare your cPanel hosting

1. Log in to cPanel
2. Go to **MySQL Databases** → create a new database and user, assign all privileges
3. Note the database name, username, and password

### Step 2 — Upload the project

**Option A: Via File Manager (easiest)**
1. Compress the `rikas-digital-pos` folder to a `.zip`
2. In cPanel → File Manager, upload the zip to `/home/yourusername/`
3. Extract it there (not inside `public_html`)

**Option B: Via FTP (faster)**
- Use FileZilla: upload the entire `rikas-digital-pos` folder to `/home/yourusername/rikas-digital-pos/`

**Option C: Via SSH/Git (best)**
```bash
ssh yourusername@yourserver.com
cd ~
git clone https://github.com/yourusername/rikas-digital-pos.git
```

Your final structure should look like:
```
/home/yourusername/
├── rikas-digital-pos/   ← Project lives here
└── public_html/         ← Web root
```

### Step 3 — Link public/ to public_html

**Option A — Subdomain (recommended)**
1. In cPanel → **Subdomains**, create `pos.yourdomain.com`
2. Set the document root to: `/home/yourusername/rikas-digital-pos/public`
3. Done — no file editing needed.

**Option B — Main domain**
Copy the contents of `rikas-digital-pos/public/` into `public_html/`, then edit `public_html/index.php`:
```php
// Change these two lines:
require __DIR__.'/../rikas-digital-pos/vendor/autoload.php';
$app = require_once __DIR__.'/../rikas-digital-pos/bootstrap/app.php';
```

### Step 4 — Configure environment

```bash
cd ~/rikas-digital-pos
cp .env.example .env
```

Edit `.env` with your real values:
```env
APP_URL=https://pos.yourdomain.com
DB_DATABASE=your_cpanel_db_name
DB_USERNAME=your_cpanel_db_user
DB_PASSWORD=your_cpanel_db_password
```

### Step 5 — Install dependencies (via SSH or cPanel Terminal)

```bash
cd ~/rikas-digital-pos

# Install PHP dependencies
composer install --no-dev --optimize-autoloader

# Generate application key
php artisan key:generate

# Run database migrations
php artisan migrate --force

# Seed default data (roles, admin user, categories, settings)
php artisan db:seed --class=DatabaseSeeder

# Create storage symlink
php artisan storage:link

# Cache for production
php artisan config:cache
php artisan route:cache
php artisan view:cache
```

### Step 6 — Set folder permissions

```bash
chmod -R 755 ~/rikas-digital-pos
chmod -R 775 ~/rikas-digital-pos/storage
chmod -R 775 ~/rikas-digital-pos/bootstrap/cache
```

### Step 7 — Set up cron job (for scheduler)

In cPanel → **Cron Jobs**, add:
```
* * * * * php /home/yourusername/rikas-digital-pos/artisan schedule:run >> /dev/null 2>&1
```

### Step 8 — Set up queue worker

Add a second cron job for queues:
```
*/5 * * * * php /home/yourusername/rikas-digital-pos/artisan queue:work --stop-when-empty >> /dev/null 2>&1
```

---

## Default Admin Credentials

After seeding, log in at `https://pos.yourdomain.com/admin`:
- **Email**: `admin@rikasdpos.com`
- **Password**: `Admin@1234`

> ⚠️ **Change this password immediately after first login!**

---

## API Documentation

The REST API base URL is: `https://pos.yourdomain.com/api/v1`

### Authentication

```http
POST /api/v1/auth/login
Content-Type: application/json

{
  "email": "admin@rikasdpos.com",
  "password": "Admin@1234",
  "device_name": "POS Terminal 1"
}
```

Response:
```json
{
  "success": true,
  "token": "1|abc123...",
  "user": {
    "id": 1,
    "name": "Super Admin",
    "roles": ["super_admin"],
    "permissions": [...],
    "branch": { "id": 1, "name": "Main Branch", "code": "HQ" }
  }
}
```

Use the token in all subsequent requests:
```http
Authorization: Bearer 1|abc123...
```

### Key Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/v1/auth/login` | Login |
| POST | `/api/v1/auth/logout` | Logout |
| GET | `/api/v1/auth/me` | Current user |
| GET | `/api/v1/dashboard/summary` | Dashboard stats |
| GET | `/api/v1/products` | List products |
| POST | `/api/v1/products/scan` | Scan barcode |
| POST | `/api/v1/sales` | Create sale |
| POST | `/api/v1/sales/bulk-sync` | Offline sync |
| GET | `/api/v1/sales/{id}/receipt` | Receipt data |
| GET | `/api/v1/sync/pull` | Pull updated data |
| GET | `/api/v1/reports/sales` | Sales report |
| GET | `/api/v1/reports/profit-loss` | P&L report |
| GET | `/api/v1/reports/export?format=pdf` | Export report |

### Offline Sync

For POS terminals that work offline, use the bulk sync endpoint:

```json
POST /api/v1/sales/bulk-sync
{
  "sales": [
    {
      "uuid": "550e8400-e29b-41d4-a716-446655440000",
      "items": [...],
      "payment_method": "cash",
      "paid_amount": 500
    }
  ]
}
```

UUIDs ensure idempotent sync — the same sale sent twice is only stored once.

---

## Project Structure

```
rikas-digital-pos/
├── app/
│   ├── Filament/          # Admin panel resources & pages
│   ├── Helpers/           # Global helper functions
│   ├── Http/
│   │   └── Controllers/Api/V1/   # All API controllers
│   ├── Models/            # Eloquent models (17 models)
│   ├── Repositories/      # Repository pattern (interface + implementation)
│   └── Services/          # Business logic services
├── database/
│   ├── migrations/        # 17 database migrations
│   └── seeders/           # Roles, permissions, defaults
├── routes/
│   ├── api.php            # All API routes (versioned)
│   └── web.php            # Web routes (admin redirect)
├── public/
│   ├── .htaccess          # Apache config + security headers
│   └── index.php          # Entry point
├── .env.example           # Environment template
└── composer.json          # PHP dependencies
```

---

## Security Checklist

- [ ] Change default admin password
- [ ] Set `APP_DEBUG=false` in production
- [ ] Set a strong `APP_KEY` (`php artisan key:generate`)
- [ ] Restrict database user permissions (no DROP privilege in production)
- [ ] Enable HTTPS — the `.htaccess` auto-redirects HTTP → HTTPS
- [ ] Set up regular database backups via cPanel
- [ ] Rotate API tokens periodically
- [ ] Keep PHP and composer packages updated
- [ ] Review rate limiting settings in `routes/api.php`
- [ ] Remove `APP_DEBUG` and telescope routes in production

---

## M-Pesa Integration

Add to your `.env`:
```env
MPESA_ENV=production
MPESA_CONSUMER_KEY=your_key
MPESA_CONSUMER_SECRET=your_secret
MPESA_SHORTCODE=your_till_or_paybill
MPESA_PASSKEY=your_passkey
MPESA_CALLBACK_URL=https://pos.yourdomain.com/api/v1/payments/mpesa/callback
```

Register on [Safaricom Daraja](https://developer.safaricom.co.ke/) to get credentials.

---

## Troubleshooting

**500 Error after deployment**
```bash
php artisan config:clear
php artisan cache:clear
chmod -R 775 storage bootstrap/cache
```

**Migration fails**
- Ensure DB credentials in `.env` are correct
- Check PHP version: `php -v` (must be 8.2+)

**Storage images not showing**
```bash
php artisan storage:link
```

**Composer not found on cPanel**
```bash
/usr/local/bin/composer install --no-dev
```

---

## Support

System: **RIKAS DIGITAL POS v1.0**
Stack: Laravel 11 + FilamentPHP 3 + Spatie Permissions + Laravel Sanctum
